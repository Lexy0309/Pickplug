<?php
mysql_connect("localhost", "archis6z_spark", "vish*456") or die ("Oops! Server not connected"); // connect to the host
mysql_select_db("archis6z_paypal") or die ("Oops! DB not connected"); // select the database
?>
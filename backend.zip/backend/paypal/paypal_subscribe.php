<?php

        $this_script = 'http://'.$_SERVER['HTTP_HOST'];
        $IS_SANDBOX = 0;

        $userid = "";
        $amount = "";
        $item_number = "";
        $item_name = "";
        $item_id = "";
        $product_id = "";

      if(isset($_GET["user_id"]) && isset($_GET["amount"]) && isset($_GET["item_name"]) && isset($_GET["item_id"]) && isset($_GET["item_id"]) && isset($_GET["subs_type"]) ) {

            $userid         = $_GET["user_id"];
            $amount         = $_GET["amount"];
            $item_name      = $_GET["item_name"];
            $product_id     = $_GET["product_id"];
            $item_id        = $_GET["item_id"];
            $subs_type      = $_GET["subs_type"];
      }     

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title></title>
<style>
.as_wrapper{
	margin:0px auto;
	width:320px;
	font-family:Arial;
	color:#333;
	font-size:14px;
	text-align : center;
}
.as_country_container{
	padding:20px;
	border:2px dashed #17A3F7;
	margin-bottom:10px;
}
</style>
</head>

<body>
<div class="as_wrapper">
    
    <?php
         if ($subs_type == "yearly"){
    ?>
        <h1>To purchase "All Sport Yearly" subscription please click to subscribe button.</h1><br><br>
    <?php
         }else{
    ?>
        <h1>To purchase "All Sport Monthly" subscription please click to subscribe button.</h1><br><br>
    <?php
         }
    ?>
    
    
    <?php
        if ($IS_SANDBOX){
    ?>
        
    <?php
         if ($subs_type == "yearly"){
    ?>
    
    <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
    <input type="hidden" name="cmd" value="_s-xclick">
    <input type="hidden" name="hosted_button_id" value="CZXPLLK7FBCML">
    <input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
    <img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">


    <?php
         }else{
    ?>
    
        <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="8JS5PZYGGGWJW">
        <input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
        <img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
        
    <?php
         }
    ?>
    

    <?php
        }else{
    ?>
    
    <?php
         if ($subs_type == "yearly"){
    ?>
    
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="QXRZFUBY3VEJ8">
        <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
        <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
        

    
    <?php
         }else{
    ?>
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
        <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
        <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="ZGZN7EVHTYN8G">
    
    <?php
         }
    ?>

    <?php
        }
    ?>

    <input type="hidden" name="invoice" value="<?php echo date("His").rand(1234, 9632); ?>" />
    <input type="hidden" name="custom" value="<?php echo $product_id."#:#".$userid ?>">
    <input type="hidden" name="return" value="<?php  echo $this_script.'/app/paypal/paypal.php?action=success'?>">
    <input type="hidden" name="cancel_return" value="<?php echo  $this_script.'/app/paypal/paypal.php?action=cancel'?>">
    <input type="hidden" name="notify_url" value="<?php echo $this_script.'/app/paypal/paypal.php?action=ipn'?>">
    
    
            

    </form>
</div>

</body>
</html>

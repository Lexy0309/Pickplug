<?php

        $userid = "";
        $amount = "";
        $item_number = "";
        $item_name = "";
        $item_id = "";
        $product_id = "";

      if(isset($_GET["user_id"]) && isset($_GET["amount"]) && isset($_GET["item_name"]) && isset($_GET["item_id"]) && isset($_GET["item_id"]) ) {

            $userid         = $_GET["user_id"];
            $amount         = $_GET["amount"];
            $item_name      = $_GET["item_name"];
            $product_id     = $_GET["product_id"];
            $item_id        = $_GET["item_id"];
      }     

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title></title>
<style>
.as_wrapper{
	margin:0 auto;
	width:500px;
	font-family:Arial;
	color:#333;
	font-size:14px;
}
.as_country_container{
	padding:20px;
	border:2px dashed #17A3F7;
	margin-bottom:10px;
}
</style>
</head>

<body>
<div class="as_wrapper" style="display: none;">
    <form action="paypal.php" method="post" id="form_paypal"> 
            <input type="hidden" name="action" value="process"/>
            <input type="hidden" name="cmd" value="_cart" /> <?php // use _cart for cart checkout ?>
            <input type="hidden" name="currency_code" value="USD" />
            <input type="hidden" name="invoice" value="<?php echo date("His").rand(1234, 9632); ?>" />
            <input type="hidden" name="item_id" value="<?php echo $item_id ?>">
            <input type="hidden" name="item_name" value="<?php echo $item_name; ?>">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <input type="hidden" name="user_id" value="<?php echo $userid; ?>">
            <input type="hidden" name="amount" value="<?php echo $amount; ?>">
    </form>
   
</div>

<div class="as_wrapper">
	Wait redirecting...
</div>
<?php
    if($userid != "" && $amount != "" && $item_name != "" && $item_id != ""){
?>
<script type="text/javascript">
      document.getElementById("form_paypal").submit(); 
</script>
<?php
}
?>
</body>
</html>
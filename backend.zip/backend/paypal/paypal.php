<?php
include("../admin/includes/common.php");
require_once(SITEADMININCLUDEPATH."common-functions.php");
include(SITEADMININCLUDEPATH."api-functions.php");


//define('EMAIL_ADD', PAYMENT_EMAIL); // define any notification email
// define('EMAIL_ADD', 'picks@pickplug.com'); // picks@pickplug.com //archiveinfotechjpr@gmail.com
define('EMAIL_ADD', 'payments@pickplug.com');
define('PAYPAL_EMAIL_ADD', 'payments@pickplug.com');
// define('PAYPAL_EMAIL_ADD', 'pickplugsales@gmail.com'); // picks@pickplug.com //pickplugsales-facilitator@gmail.com

require_once("paypal_class.php");
$p 				= new paypal_class(); // paypal class
$p->admin_mail 	= EMAIL_ADD; // set notification email
$action 		= $_REQUEST["action"];


switch($action){
	case "process": // case process insert the form data in DB and process to the paypal
	
		$this_script = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		
		$p->add_field('business', PAYPAL_EMAIL_ADD); // Call the facilitator eaccount
		$p->add_field('cmd', $_POST["cmd"]); // cmd should be _cart for cart checkout
		$p->add_field('upload', '1');
		$p->add_field('return', $this_script.'?action=success'); // return URL after the transaction got over
		$p->add_field('cancel_return', $this_script.'?action=cancel'); // cancel URL if the trasaction was  
		$p->add_field('notify_url', $this_script.'?action=ipn'); // Notify URL which received IPN (Instant 

		
		$p->add_field('currency_code', $_POST["currency_code"]);
		$p->add_field('invoice', $_POST["invoice"]);
		$p->add_field('item_name_1', $_POST["item_name"]);
		$p->add_field('item_number_1', "1");
		$p->add_field('quantity_1', 1);
		$p->add_field('credits',0);
		$p->add_field('amount_1', $_POST["amount"]);

		/*need this funciton*/	
		$dataUser 			= getUserDetailsById($_POST["user_id"]);
		/*need this funciton*/	

        $p->add_field('custom', $_POST["product_id"]."#:#".$_POST["user_id"]);
        
		$p->add_field('user_id', $_POST["user_id"]);
		$p->add_field('first_name', $dataUser["FullName"]);
		$p->add_field('last_name', $dataUser["FullName"]);
		$p->add_field('address1', "");
		$p->add_field('city', "");
		$p->add_field('state',"");
		$p->add_field('country', "");
		$p->add_field('zip', "");
		$p->add_field('email', $dataUser["Email"]);
		$p->submit_paypal_post(); // POST it to paypal
		break;

	case "success": // success case to show the user payment got success
		echo '<title>Payment Done Successfully</title>';
		echo '<style>.as_wrapper{
				font-family:Arial;
				color:#333;
				font-size:12px;
				width:280px;
				margin:0 auto;
				text-align:center;
			}

				a{
				background-image: -moz-linear-gradient(center top , transparent, rgba(0, 0, 0, 0.2)), url("images/bg02.png");
				transition: background-color 0.2s ease-in-out 0s;
				position: relative;
				display: inline-block;
				background-color: rgba(85, 66, 48, 0.9);
				border-radius: 8px;
				box-shadow: 0px 0px 0px 1px rgba(0, 0, 0, 0.35) inset, 0px 2px 1px 0px rgba(255, 255, 255, 0.35) inset;
				text-shadow: -1px -1px 0px rgba(0, 0, 0, 0.5);
				color: #FFF !important;
				text-decoration: none;
				text-transform: uppercase;
				font-weight: 800;
				font-size: 0.95em;
				letter-spacing: 0.075em;
				padding:10px;
				outline: 0px none;
				border: 0px none;
				white-space: nowrap;
				cursor: pointer;
}

				</style>
				';
		echo '<div class="as_wrapper">';
		echo "<h1>Thank you for your payment. Your transaction has been completed, and a receipt for your purchase has been emailed to you. You may log in to your account at www.paypal.com to view details of this transaction.</h1>";
		//echo '<h4>Use this below URL in paypal sandbox IPN Handler URL to complete the transaction</h4>';
		//echo '<h3>http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?action=ipn</h3>';
		echo '</div>';
		break;

	case "cancel": // case cancel to show user the transaction was cancelled
		echo '<style>.as_wrapper{
				font-family:Arial;
				color:#333;
				font-size:12px;
				width:280px;
				margin:0 auto;
				text-align:center;
				}

				a{
				background-image: -moz-linear-gradient(center top , transparent, rgba(0, 0, 0, 0.2)), url("images/bg02.png");
				transition: background-color 0.2s ease-in-out 0s;
				position: relative;
				display: inline-block;
				background-color: rgba(85, 66, 48, 0.9);
				border-radius: 8px;
				box-shadow: 0px 0px 0px 1px rgba(0, 0, 0, 0.35) inset, 0px 2px 1px 0px rgba(255, 255, 255, 0.35) inset;
				text-shadow: -1px -1px 0px rgba(0, 0, 0, 0.5);
				color: #FFF !important;
				text-decoration: none;
				text-transform: uppercase;
				font-weight: 800;
				font-size: 0.95em;
				letter-spacing: 0.075em;
				padding:10px;
				outline: 0px none;
				border: 0px none;
				white-space: nowrap;
				cursor: pointer;
}

				</style>
				';
		echo '<div class="as_wrapper">';
		echo "<h1>Transaction Cancelled</h1>";
		echo '</div>';
		break;

	case "ipn": 
	// IPN case to receive payment information. this case will not displayed in browser. This is server to server communication. PayPal will send the transactions each and every details to this case in secured POST menthod by server to server.
	
		$trasaction_type = $_POST["txn_type"];
		
		$trasaction_id  =   $_POST["txn_id"];
		$log_array		=   print_r($_POST, TRUE);
		$id 	        =  insertPaypalLog($trasaction_id,$log_array);
		
		if ($trasaction_type == "subscr_cancel"){
		    $subscriptionId = $_POST["subscr_id"];
		    $customData     = explode("#:#",$_POST["custom"]);
    		$userId			= $customData[1];
    		$productId		= $customData[0];
        		
        	cancelSubscription($userId,$productId,$subscriptionId);

		}else if ($trasaction_type == "subscr_eot"){
		    $subscriptionId = $_POST["subscr_id"];
		    $customData     = explode("#:#",$_POST["custom"]);
    		$userId			= $customData[1];
    		$productId		= $customData[0];
    		updateSubscriptionExpiryPeriod($userId,$productId,$subscriptionId);
		}else{
		    if ($trasaction_type == "cart" || $trasaction_type == "subscr_payment"){
    		    
        		$payment_status = strtolower($_POST["payment_status"]);
        		$invoice		= $_POST["invoice"];
        		$customData     = explode("#:#",$_POST["custom"]);
        		$userId			= $customData[1];
        		$productId		= $customData[0];
        		$subscriptionId = "";
        		$payemnt_type  = "Paypal";
        		
        		if ($trasaction_type == "subscr_payment") {
        		    $subscriptionId = $_POST["subscr_id"];
        		}
  
        		if ($p->validate_ipn()){ // validate the IPN, do the others stuffs here as per your app logic
        			if ($payment_status=="completed" || $payment_status=="Completed") {
        			    
        			    $arr = array();
                    	$arr['PurchasedDate'] 		    = date('Y-m-d');//$_REQUEST['date'];
                    	$arr['ProductId'] 				= $productId;
                    	$arr['User'] 				    = $userId;
                    	$arr['Pick'] 				    = 0;//$_REQUEST['pick'];
                    	$arr['TransactionID'] 		    = $trasaction_id;
                    	$arr['payment_type'] 		    = $payemnt_type;
                    	$arr['subscription_id'] 		= $subscriptionId;
                        
                        if ($subscriptionId != ''){
                            if (isTransactionAlreadyExistsForPaypal($subscriptionId,$productId,$userId) == '0'){
                            $ResultArray =  addsubscription($arr,'' ); 
                            }
                        }else{
                            if (isTransactionAlreadyExists($userId,$productId) == '0'){
                            $ResultArray =  addsubscription($arr,'' ); 
                            }
                        }    
    
                    	
        			}
        		} 
    		}
		}
		
		
		
		
		
    

		break;
}
?>
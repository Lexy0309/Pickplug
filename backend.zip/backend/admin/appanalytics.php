<?php
 include("includes/common.php");
 
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."subscription-functions.php");
 include(SITEADMININCLUDEPATH."api-functions.php");
 
 checkLogin();
 $current_year = (int)date('Y');
 $current_month = (int)date('m');
 $current_day = (int)date('d');
//  var_dump($current_day);
//  exit();
 $total_users = getUserAppLog('total')[0]['total'];
 $last_monthly_counts = getUserAppLog('monthly', $current_year-1);
 $current_day_counts = getUserAppLog('day', $current_year, $current_month, $current_day)[0]['total'];
 $current_month_counts = getUserAppLog('daily', $current_year, $current_month);
 $last_monthly_users = [];
 foreach($last_monthly_counts as $last_monthly_count){
     
     array_push($last_monthly_users, $last_monthly_count['count_user']);
 }


if ($current_month == 1){
    $last_daily_counts = getUserAppLog('daily', $current_year-1, 12);
} else{
    $last_daily_counts = getUserAppLog('daily', $current_year, $current_month-1);
}

$last_daily_users = [];
 foreach($last_daily_counts as $last_daily_count){
     
     array_push($last_daily_users, $last_daily_count['count_user']);
 }
 $current_month_users = [];
 foreach($current_month_counts as $current_month_count){
     array_push($current_month_users, $current_month_count['count_user']);
 }

 $color = array("#2ecc71", "#3498db",  "#95a5a6",  "#9b59b6",  "#f1c40f", "#e74c3c", "#34495e", "#878BB6", "#4ACAB4",  "#FFEA88");

 for($num1 = 0 ; $num1 < 12; $num1++){
    $label1[$num1] = $num1 + 1;
    $dataPoints1[$num1]= $last_monthly_users[$num1]*1;
 }

 for($num2 = 0 ; $num2 < count($last_daily_users); $num2++){
    $label2[$num2] = $num2 + 1;
    $dataPoints2[$num2]= $last_daily_users[$num2]*1;
 }
 for($num3 = 0 ; $num3 < count($current_month_users); $num3++){
    $label3[$num3] = $num3 + 1;
    $dataPoints3[$num3]= $current_month_users[$num3]*1;
 }

 
?>
<html>
<head>
        <meta charset="utf-8" />
        <!-- <script src= "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script> -->
        <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js'></script>
        <style>
            .column {
                width: 50% !important;
                overflow: visible;
                display: inline-block;
            }
            div[role="main"] {
                width: 100%;
            }
        </style>
    </head>
<div class="span10 pull-left">
    <div class="row" id="fight-wrapper">
   
        <div class="span">	
            <?php
            if(!empty($strMessage)) { ?>
            <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
            <?php } ?>
            <div class = "total users"> 
                <h3> Total Users: <?php echo($total_users);?></h3>
            </div>
            <div class = "current day users"> 
                <h3> Active Users today: <?php echo($current_day_counts);?></h3>
            </div>
            <br><br>
            <div class = "chart">
                <div class="column">
                    <h2> Active Users in this month</h2>
                    <canvas id="current_month_chart" height="450" width="800"></canvas>
                </div>
                <br>
                <div class="column">
                    <h2> Active Users in <?php echo($current_year - 1);?>  </h2>
                    <canvas id="monthly_chart" height="450" width="800"></canvas>
                </div>
                <br>
                <div class="column">
                    <h2> Active Users in <?php echo(date("F", strtotime("last month"))); ?> , <?php echo($current_year);?> </h2>
                    <canvas id="daily_chart" height="450" width="800"></canvas>
                </div>
                
                
            </div>

       </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js'></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>
<script>
	function cancelsubscription(trid, user, sid)
	{
		if(confirm("Are you sure want to cancel subscription?")){
			window.location.href = "<?php echo $global_config["SiteGlobalAdminPath"];?>usersubscriptions.php?trid="+trid+"&user="+user+"&sid="+sid;
		}
	}
</script>


<script>
$(document).ready(function(){
    var current_month_user_Data = {
        labels :  <?php echo json_encode($label3); ?>,
        datasets : [
            {
                fillColor : "rgba(172,194,132,0.4)",
                strokeColor : "#ACC26D",
                pointColor : "#fff",
                pointStrokeColor : "#9DB86D",
                data :  <?php echo json_encode($dataPoints3, JSON_NUMERIC_CHECK); ?>
            }
        ]
    }
    var line_Options = {
        title: {
            display: true,
            text: 'This month users'
        }
    }
    var current_month_chart = document.getElementById('current_month_chart').getContext('2d');
    new Chart(current_month_chart).Bar(current_month_user_Data, line_Options);

    var last_monthly_user_Data = {
        labels :  <?php echo json_encode($label1); ?>,
        datasets : [
            {
                fillColor : "rgba(172,194,132,0.4)",
                strokeColor : "#ACC26D",
                pointColor : "#fff",
                pointStrokeColor : "#9DB86D",
                data :  <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
            }
        ]
    }
    var line_Options = {
        title: {
            display: true,
            text: 'Monthly users'
        }
    }
    var monthly_chart = document.getElementById('monthly_chart').getContext('2d');
    new Chart(monthly_chart).Line(last_monthly_user_Data, line_Options);

   var last_daily_user_Data = {
        labels :  <?php echo json_encode($label2); ?>,
        datasets : [
            {
                fillColor : "rgba(172,194,132,0.4)",
                strokeColor : "#ACC26D",
                pointColor : "#fff",
                pointStrokeColor : "#9DB86D",
                data :  <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
            }
        ]
    }
    var line_Options = {
        title: {
            display: true,
            text: 'Daily users'
        }
    }
    var daily_chart = document.getElementById('daily_chart').getContext('2d');
    new Chart(daily_chart).Bar(last_daily_user_Data, line_Options);

  
 })
  </script>
</html>
<?php
	function doSendMessage($data) {
		$strTodayDate	=	date('Y-m-d');
		$message		=	$data;
		$sql = "INSERT INTO tbl_messages SET Message = '" .$message . "', AddedDate = '".$strTodayDate."'";
		$strMessageID = mysql_query($sql);
		return $strMessageID;
	}
	
	
	
	
	function doSendAndroid($message) {
		$apiKey = "AIzaSyAoFMll5RYWsyABFu23_SNfUrLXbYGfM04";
		// TODO Here, list all the regId of the database
		$selectRegId = "SELECT * FROM tbl_deviceids where device = 'andoroid'";
		$result = SelectQry($selectRegId);
		
			$regID = array();
			foreach($result as $res) {
				$regID[] = $res['regId'];
			}


		   $registrationIDs = $regID;
	
			$url = 'https://android.googleapis.com/gcm/send';
			
			$fields = array(
							'registration_ids'  => $registrationIDs,
							'data'              => array( "message" => $message ),
							);
			
			$headers = array(
								'Authorization: key=' . $apiKey,
								'Content-Type: application/json'
							);
			
			// Open connection
			$ch = curl_init();
			
			// Set the url, number of POST vars, POST data
			curl_setopt( $ch, CURLOPT_URL, $url );
			
			curl_setopt( $ch, CURLOPT_POST, true );
			curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			
			curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );
			
			// Execute post
			$result = curl_exec($ch);
			
			// Close connection
			curl_close($ch);
			
			$resAry = json_decode($result);
			//print '<pre>'; print_r($resAry->results); print '</pre>';
			$responseAry = $resAry->results;
			$combine = @array_combine($registrationIDs,$responseAry); 
			//echo '<pre>'; print_r($combine);
			return $combine;
		} 
		
		
			
	function UpdateMessageStatus($strIdent) {
		mysql_query("UPDATE tbl_messages SET Status = 'Completed' WHERE Ident = '".(int)$strIdent."'");
	}
					
	function doGetAllUserDetails() {
		$query = mysql_query("SELECT * FROM tbl_apns_devices");
		while($arr = mysql_fetch_array($query)) {
			$user_data[] = $arr["devicetoken"];
			$user_data['type'][] = $arr["type"];
		}
		return $user_data;
	}
	
	function DataMessageCnt($strMessageID,$type) {
		//echo "SELECT count(*) as TotalCnt from tbl_messages_device Where MessageId = '".$strMessageID."' AND Status = 'Completed'" ;
		$query = mysql_query("SELECT count(*) as TotalCnt from tbl_messages_device Where MessageId = '".$strMessageID."' AND Status = 'Completed' AND deviceType = '".$type."' ");
		$results = mysql_fetch_array($query);
		return $results[0]['TotalCnt'];
	}
	
	function DataExistsMessage($Message){
		$sql = "SELECT Ident from tbl_messages Where Message = '".$Message."'";
		$result = mysql_query($sql);
		$results = mysql_fetch_array($result);
		if($results)
			return $results[0]['Ident'];
		else
			return 0;	
	}
	
	function DataExistsSendMessage($strMessageID,$deviceToken){
		$query = mysql_query("SELECT count(*) as TotalCnt from tbl_messages_device Where MessageId = '".$strMessageID."' AND Devicetoken = '".$deviceToken."' AND Status = 'Completed'");
		$results = mysql_fetch_array($result);
		return $results[0]['TotalCnt'];
	}
			
	function InsertMessageDevices($strDeviceToken,$strMessageID,$type) {
		$strTodayDate	=	date('Y-m-d');
		mysql_query("INSERT INTO tbl_messages_device SET MessageId = '" .$strMessageID . "', Devicetoken = '".$strDeviceToken."', Status = 'Completed', SendDate = '".$strTodayDate."', deviceType = '".$type."'");
	}
	
	function doSendNotificationMessage($usersAry,$message,$type='') {
		$absPath = '/home3/propicks/public_html/app/admin/push/';
		if($type==''){
			$type ='pro';
		}
		if(!empty($message)){
			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
		
			$ctx = stream_context_create();
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			if($type == 'dev') {
				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			} else {
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
			
			for($i=0;$i<count($usersAry);$i++){
				$deviceToken = $usersAry[$i]['devicetoken'];
				$payload = json_encode($body);
				$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
				//print $payload;
				//print $deviceToken."<BR>";
				$res = fwrite($fp, $msg, strlen($msg));
			}
			
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			fclose($fp);
			}
			//echo $msg;
		
	}	
	
		
	function doSendNotificationMessageOld($deviceToken,$message) {
		//echo $messageView; exit;
		//echo  ABSPATH.'api/push/apnspro.pem';
		if(!empty($deviceToken) && !empty($message)){
			$pass = 'tenerife';
			$message = str_replace("+", " ",stripslashes($message));
			
		
			//$badge = '';	
			$sound = 'default';
			
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
		
			//if($messageView=="normal") {
				//$body['aps']['content-available'] = "";
			//} else {
				$body['aps']['content-available'] = "1";
			//}

			if ($badge)
				$body['aps']['badge'] = $badge;
		
			if ($sound)
				$body['aps']['sound'] = $sound;
				
							
			$ctx = stream_context_create();
				stream_context_set_option($ctx, 'ssl', 'local_cert', '/opt/lampp/htdocs/up4boxing/api/push/apnspro.pem');
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
		
			// assume the private key passphase was removed.
			// stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
		
			//$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			// for production change the server to ssl://gateway.push.apple.com:2195
			
			
			//echo $fp; exit;	
		
			if (!$fp) {
				print "Failed to connect $err $errstr\n";
				return;
			}
			else {
				print "Connection OK\n";
			}
		    
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
		
			//print $payload;
		
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
        		$msg = 'Message not delivered' . PHP_EOL;
   			} else {
		        $msg = 'Message successfully delivered' . PHP_EOL;
		    }
			global $j;
			$j++;
			fclose($fp);
		
			stream_context_set_option($ctx, 'ssl', 'verify_peer', false); 
			//if($type == 'dev') {
				//$fp = stream_socket_client('ssl://feedback.sandbox.push.apple.com:2196', $error,$errorString, 100, (STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT), $ctx);
			//} else {
				$fp = stream_socket_client('ssl://feedback.push.apple.com:2196', $error,$errorString, 100, (STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT), $ctx);
			//}
	
		}
	}	
	
	function doSendAndroidNotification($message) {
		$apiKey = "AIzaSyAoFMll5RYWsyABFu23_SNfUrLXbYGfM04";
		// TODO Here, list all the regId of the database
		$selectRegId = "SELECT * FROM tbl_apns_andriod";
		$result = SelectQry($selectRegId);
		
			$regID = array();
			foreach($result as $res) {
				$regID[] = $res['regId'];
			}
		   $registrationIDs = $regID;
	
			$url = 'https://android.googleapis.com/gcm/send';
			
			$fields = array(
							'registration_ids'  => $registrationIDs,
							'data'              => array( "message" => $message ),
							);
			
			$headers = array(
								'Authorization: key=' . $apiKey,
								'Content-Type: application/json'
							);
			
			// Open connection
			$ch = curl_init();
			
			// Set the url, number of POST vars, POST data
			curl_setopt( $ch, CURLOPT_URL, $url );
			
			curl_setopt( $ch, CURLOPT_POST, true );
			curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			
			curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );
			
			// Execute post
			$result = curl_exec($ch);
			
			// Close connection
			curl_close($ch);
			
			$resAry = json_decode($result);
			//print '<pre>'; print_r($resAry->results); print '</pre>';
			$responseAry = $resAry->results;
			$combine = @array_combine($registrationIDs,$responseAry); 
			//echo '<pre>'; print_r($combine);
			return $combine;
		} 

	
	function doSendNotificationMessageNew($deviceToken,$type='',$message='') {
		$absPath = '/home3/propicks/public_html/app/admin/push/';
		if($type==''){
			$type ='pro';
		}
		if(!empty($message)){
			//echo $deviceToken;
			//echo '<br />';
			//echo $message;
			//echo $type;
			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
			$ctx = stream_context_create();
				//stream_context_set_option($ctx, 'ssl', 'local_cert', ABSPATH.'api/push/apnspro.pem');
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			if($type == 'dev') {
				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			} else {
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
			//print $payload;
			//print $deviceToken."<BR>";
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			fclose($fp);
			}
			//echo $msg;
	}	
	
	function doSendNotificationMessageCron($deviceToken,$type='',$message='') {
		$absPath = '/home3/propicks/public_html/app/admin/push/';
		if($type==''){
			$type ='pro';
		}
		if(!empty($message)){
			//echo $deviceToken;
			//echo '<br />';
			//echo $message;
			//echo $type;
			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
			$ctx = stream_context_create();
				//stream_context_set_option($ctx, 'ssl', 'local_cert', ABSPATH.'api/push/apnspro.pem');
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			if($type == 'dev') {
				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			} else {
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
			/*if (!$fp) {
					print "Failed to connect $err $errstr\n";
					return;
			}else {
					print "Connection OK\n";
			}*/
			
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
			//print $payload;
			//print $deviceToken."<BR>";
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			fclose($fp);
			}
	
		
	}		


	function pushTest($deviceToken,$message,$type=''){
		$absPath ='/home3/propicks/public_html/app/admin/push/';
		if($type==''){
			$type = 'dev';
		}
		if(!empty($message)){

			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
			$ctx = stream_context_create();
				//stream_context_set_option($ctx, 'ssl', 'local_cert', ABSPATH.'api/push/apnspro.pem');
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			
			if($type == 'dev') {

				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	

			} else {

				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
	
			if (!$fp) {
					print "Failed to connect $err $errstr\n";
					return;
			}else {
					print "Connection OK\n";
			}
			
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
			print $msg; echo '<br>'; 
			//print $payload;
			//print $deviceToken."<BR>";
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			
			print $msg;

			fclose($fp);
			}
	}

	function sendandroidpushnotifications($title, $message)
	{
		$content = array(
			"en" => $message
			);

		$fields = array(
			'app_id' => "6b9ea59d-a204-4350-81ef-79b3d84181be",
			'included_segments' => array('All'),
			'data' => array("title" => $title),
			'large_icon' =>"http://propicksapp.com/app/Icon.png",
			'contents' => $content
		);

		$fields = json_encode($fields);
		

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
												'Authorization: Basic MmVlODJjOTctZTcwZC00OGQ5LTlmYTctM2IxOGNlZWY1YTU5'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

		$response = curl_exec($ch);
		
		curl_close($ch);

		return $response;
	}
	
	
	
	
	function send_push_message_iphone($arrDeviceToken,$strMsg,$puskKeyIphone,$title){
	 		$msg = array
			(
			    'title'	=> $title,
				'body' 	=> $strMsg,
				'sound'		=> "default"
			);
			$fields = array
			(
				'registration_ids' 	=> $arrDeviceToken,
				'notification'			=> $msg,
				'priority'      =>'high'
			);
			$headers = array
			(
				'Authorization: key='.$puskKeyIphone,
				'Content-Type: application/json'
			);
			$ch = curl_init();
			curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
			curl_setopt( $ch,CURLOPT_POST, true );
			curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
			curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode($fields));
			$result = curl_exec($ch );
			curl_close( $ch );

	}
	
	
	function send_android_push_message_android($registatoin_ids, $message,$key,$title) {
		// include config
	
		$puskKey	=	$key;
	
		//echo GOOGLE_API_KEY;
	
		// Set POST variables
		//$url = 'https://android.googleapis.com/gcm/send';
		$url = 'https://fcm.googleapis.com/fcm/send';
	
	    $arrMessage['message']	=	$message;
	    $arrMessage['title']	=	$title;
	    
	    
		$fields = array(
				'registration_ids' => $registatoin_ids,
				'data' => $arrMessage,
		);
	
		$headers = array(
				'Authorization: key=' . $puskKey,
				'Content-Type: application/json'
		);
		// Open connection
		$ch = curl_init();
	
		// Set the url, number of POST vars, POST data
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Disabling SSL Certificate support temporarly
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	
		// Execute post
		$result = curl_exec($ch);
		curl_close($ch);
	}
	
	


    function sendiospushnotifications($title, $message)
	{
		$apiKey = "AAAAeAbUsVs:APA91bFHld_8XrnrvWBXYU47V5SWPrB3vnJF-mA2ZPFXgSb9ncNC3by8UuoR-peSSns6UrqkLEOJlH31CltJS3pcC_7tSavdyGv2EvH_igW1FftWPQt5x9T036XNAyb4lsl_CTY2R2OzE6ZSjaCyzW6ph98yica3Bw";
		
		$qry = 'SELECT * FROM tbl_deviceids WHERE deviceid != "null"';
		$results = SelectQry($qry);
		$registrationIds = array();
		 
		foreach($results as $s){
		    
		    if($s["device"] == "ios"){
		       $registrationIdIos[] = $s["deviceid"];        
		    }else if ($s["device"] == "android"){
		       $registrationIdAndroid[] = $s["deviceid"];    
		    }
		}
		         
		
		if(count($registrationIdAndroid) > 0){
		    send_android_push_message_android($registrationIdAndroid, $message,$apiKey,$title);
		}
	
		if(count($registrationIdIos) > 0){
		    send_push_message_iphone($registrationIdIos,$message,$apiKey,$title);
		}
		
	
	}


?>

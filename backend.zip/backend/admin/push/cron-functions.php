<?php
	function doGetAllUserPickDeviceDetails($uid){
		$sql="SELECT * FROM `tbl_apns_devices` WHERE `user` = '".$uid."'";
		$result=SelectQry($sql);
		return $result;
	}
	
	function doGetPickUserDetails($tbl_name) {
		$sql="SELECT * FROM `".$tbl_name."` WHERE `pick_push` = 'on'";
		$result = SelectQry($sql);
		return $result;
	}
	
	function doGetTodayPickDetails($tbl_name,$strtoday) {
		$sql="SELECT * FROM `".$tbl_name."` WHERE `PickDate` LIKE '".$strtoday."%'";
		$result=SelectQry($sql);
		return $result;
	}
	
	function doSendMail($mailid){
	   $to = $mailid;
	   $subject = "Giazz Sports - Pick Available";
	   $message = "<b>Pick is available for today.</b>";
	   //$message .= "<h1>This is headline.</h1>";
	   $header = "From: ragu@oclocksolutions.com \r\n";
	   $header .= "MIME-Version: 1.0\r\n";
	   $header .= "Content-type: text/html\r\n";
	   $retval = mail ($to,$subject,$message,$header);
	   return $retval;
	}
?>
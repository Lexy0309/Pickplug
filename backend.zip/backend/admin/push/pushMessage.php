<?php
	include("../includes/common.php");
 	include('pushFunctions.php');
 
 function SelectQry($Qry) {
		global $qryArrays;
		$qryArrays[] = $Qry;
		$result  = mysql_query($Qry) or die ("QUERY Error:".$Qry."<br>".mysql_error());
		$numrows = mysql_num_rows($result);		
		if ($numrows == 0){			
			return;
		} else {
		   $row = array(); 
		   $record = array();
		   while ($row = mysql_fetch_array($result)){ 
			$record[] = $row; 
		   }		
		}		
		return MakeStripSlashes($record);
	}
	/*$type 		 = 'dev';
	$message 	 = 'giazzasports push test by ragu';
	//$deviceToken = '344eafc93f8910a2f51efe821528bde71842a738735f7bd23b51cd3134cff862';
	
	$deviceToken = 'f022b4d0d499708f6c30dc0121750343625c41126a43af7808629dae26a05f62';
	
	if($_REQUEST['type']){
	$type = $_REQUEST['type'];
	}
	
	if($_REQUEST['message']){
	$message = $_REQUEST['message'];
	}
	
	if($_REQUEST['deviceToken']){
	$deviceToken = $_REQUEST['deviceToken'];
	}
	
	pushTest($deviceToken,$message,$type);*/
	$message ="Here my sample";
	doSendAndroidNotification($message);
		
?>
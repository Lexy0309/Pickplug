<?php
include("../includes/common.php");
include(SITEADMININCLUDEPATH."main-tables.php");
include(SITEADMININCLUDEPATH."common-functions.php");
if(isset($_REQUEST['regId']) && $_REQUEST['regId'] != '') {
	$UserId    = getUserIdFromSession($_REQUEST['sessionid']);
	$AddedDate = date("Y-m-d H:i:s");
	$sql = "Select count(*) as cnt from tbl_apns_andriod where regId = '".$_REQUEST['regId']."'";
	$checkDuplicate = Selectqry($sql);
	if($checkDuplicate[0]['cnt']==0){
		$sql = "Insert into tbl_apns_andriod (`regId`,`appName`,`DeviceName`,`UserId`,`AddedDate`,`ModifiedDate`) Values ('".$_REQUEST['regId']."','".$_REQUEST['appname']."','".$_REQUEST['devicename']."','".$UserId."','".$AddedDate."','".$AddedDate."')";
		ExecuteQry($sql);
		$insertId = mysql_insert_id();
		if($insertId){
			$ResultArray = array("success"=>true, "message"=>"Device registered successfully");
		} else {
			$ResultArray = array("success"=>false, "message"=>"Insertion error");
		}
	} else {
		$ResultArray = array("success"=>false, "message"=>"Already inserted");
	}
} else {
	$ResultArray = array("success"=>false, "message"=>"No devices entered");
}
displayResult($ResultArray);

function getUserIdFromSession($session){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE session='".$session."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
			return $results[0]['Id'];
		}else{
			return 0;
		}
	}
?>
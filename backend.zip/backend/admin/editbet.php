<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."bet-functions.php");
 checkLogin();
 global $table_config;
 $SportId = base64_decode($_REQUEST['id']);// Get Userid from URL
 
if(isset($_POST['Submit']))
{
if(!empty($_FILES['file_File']['name'])) 
{
	@$strImageProperties = getimagesize($_FILES["file_File"]["tmp_name"]);
	if($strImageProperties[0]>=$BetimgWidth && $strImageProperties[1]>=$BetimgHeight)
	{
		$strGalleryCount = CheckDataExists($table_config["bet"], 'BetName', $_POST['bet_BetName'],$Field='Id',$SportId);
		if($strGalleryCount==0)
		{
			$ary['bet_Country']     = $_POST['bet_Country'];
			$ary['bet_BetName']     = $_POST['bet_BetName'];
			$ary['bet_BetWebsite']  = $_POST['bet_BetWebsite'];
			$ary['bet_Description'] = $_POST['bet_Description'];
			$ary['bet_ModifiedDate']= date('Y-m-d H:i:s');
			$strUserId	= updateSportsDetails($ary,"bet_",$table_config["bet"],$SportId,$_FILES);	
			if(!empty($strUserId))
			{
				$strMessage="Bet Details updated successfully";
				$strMessageClass="success";
				unset($_POST);
			}	
		} 
		else 
		{
			$strMessage="Bet Name already exists";
			$strMessageClass="error";
		}
	}
	
	else 
	{
		$strMessage="Uploaded image greater than ".$BetimgWidth." X ".$BetimgHeight." pixels";
		$strMessageClass="error";
	}	
}

else
{
	$strGalleryCount = CheckDataExists($table_config["bet"], 'BetName', $_POST['bet_BetName'],$Field='Id',$SportId);
	if($strGalleryCount==0)
	{
		$ary['bet_Country']     = $_POST['bet_Country'];
		$ary['bet_BetName']     = $_POST['bet_BetName'];
		$ary['bet_BetWebsite']  = $_POST['bet_BetWebsite'];
		$ary['bet_Description'] = $_POST['bet_Description'];
		$ary['bet_ModifiedDate']= date('Y-m-d H:i:s');
		
		$strUserId	= updateSportsDetails($ary,"bet_",$table_config["bet"],$SportId,$_FILES);	
		
		if(!empty($strUserId))
		{
			$strMessage="Bet details updated successfully";
			$strMessageClass="success";
			unset($_POST);
		}	
	} 
	else
	{
		$strMessage="Bet Name already exists";
		$strMessageClass="error";
	}
}
}  
	
	$arrUser = GetRecordsValuesById($table_config["bet"],$SportId);
	
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="editBet" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Edit Bet</legend>
		
		 <div class="control-group">
          <label class="control-label" for="bet_Country">Country*</label>
          <div class="controls">
		  <select name="bet_Country" id="bet_Country">
				<option selected="selected" value=""> -- Country -- </option>
				<?php foreach($countrylist as $key=>$country){ 
					if($arrUser['Country']==$key) { $sel="Selected"; } else { $sel="";}
				?>
					<option value="<?php echo $key; ?>" <?php echo $sel; ?>><?php echo $country; ?></option>
				<?php } ?>	
			</select>
          </div>
        </div>
        <div class="control-group">
          <label class="control-label" for="bet_BetName">Bet Name*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="bet_BetName" name="bet_BetName"  rel="popover" value="<?php echo $arrUser['BetName'];?>" />
          </div>
        </div>
       
		        
		<div class="control-group">
			<label class="control-label" for="bet_BetLogo">Bet Logo</label>
			<div class="controls">
				<input type="file" id="file_File" name="file_File"  size="74">
				<span class="help-block">Uploaded image greater than <?php echo $BetimgWidth; ?> X <?php echo $BetimgHeight; ?> pixels</span> 
				<?php if($arrUser['BetLogo']!="" && file_exists(UPLOADLOCALPATH."bet/".$arrUser['BetLogo'])) { ?>
				&nbsp;			
				<a data-toggle="lightbox" href="#demoLightbox" style="margin:10px 0 0;float:left;">
				<img src="<?php echo SITEGLOBALUPLOADPATH;?>bet/<?php  echo $arrUser['BetLogo'];?>" alt="" />
				</a>	
				
				<div id="demoLightbox" class="lightbox hide fade"  tabindex="-1" role="dialog" aria-hidden="true">
					<div class='lightbox-header'>
						<button type="button" class="close" data-dismiss="lightbox" aria-hidden="true">&times;</button>
					</div>
					<div class='lightbox-content'>
						<img src="<?php echo SITEGLOBALUPLOADPATH;?>bet/<?php  echo $arrUser['BetLogo'];?>" width="" height="" alt=""/>
					</div>
				</div>	
				<?php } ?>	
			</div>
		</div>
		
		<div class="control-group">
          <label class="control-label" for="bet_BetWebsite">Bet Website*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="bet_BetWebsite" name="bet_BetWebsite"  rel="popover" value="<?php echo $arrUser['BetWebsite'];?>" />
          </div>
        </div>
		
		<div class="control-group">
			<label class="control-label" for="bet_Description">Description</label>
			<div class="controls">
				<textarea name="bet_Description" id="bet_Description" style="width:530px !important; height:150px !important;"><?php echo $arrUser['Description'];?></textarea>
			</div>
		</div>
		 
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listbets.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/wysihtml5-0.3.0.js"></script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-wysihtml5.js"></script>
<script>
	$('#bet_Description').wysihtml5();
</script>
<script type="text/javascript">
	  $(document).ready(function(){
					 
			$("#editBet").validate({
				rules:{
					bet_Country:"required",
					bet_BetName:"required",
					bet_BetWebsite:"required"
				},
				messages:{
					bet_Country:"Choose Country",
					bet_BetName:"Enter Bet Name",
					bet_BetWebsite:"Enter Website"
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
</script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-lightbox.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."weeks-functions.php");
 checkLogin();
 global $table_config;
/*if($_POST['hdAction']=='weeks'){
	printArray($_POST);
}
*/

if(isset($_POST['Submit'])){
	 $weekId	= insertWeekDetails($table_config["week"],$_POST);	
	 if($weekId==1){
		 $strMessage="Week details updated successfully";
		 $strMessageClass="success";
		 unset($_POST);
	 }
}
$strWeek = array();
for($m=1;$m<=22;$m++) {
	$strWeek[] = getWeeksDetails($table_config["week"],$m);
	
}
?>
<div class="span10 pull-left" style="vertical-align:top">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="week" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Add Weeks</legend>
        <div class="control-group">
        	<div class="controls">
            	<span class="help-block" style="width:60%;">Start Date <span style="margin-left:30%;">End Date</span></span> 
            </div>
        </div>
		<div class="control-group">
          <label class="control-label" for="pick_PickDate">Week1*</label>
          <div class="controls">
            <?php /*?><input type="text"  class="input-large" id="week1_start_date" name="week1_start_date"  rel="popover" <?php if(empty($_POST['week1_start_date'])) { ?>value="<?php echo $strWeek['week1startdate']; ?>"<?php } else { ?>value="<?php echo $_POST['week1_start_date']; ?>" <?php } ?> /><?php */?>
           
			<div class="input-append" style="height:30px;">
				<input style="width:182px;" class="date-picker" id="foo" type="text" name="week1_start_date" <?php if(empty($_POST['week1_start_date'])) { ?>value="<?php echo $strWeek[0]['startdate']; ?>"<?php } else { ?>value="<?php echo $_POST['week1_start_date']; ?>" <?php } ?> />
				<label for="foo" class="add-on"><i class="icon-calendar"></i></label>
			</div>
		   
		    <input type="text"  class="input-large" id="week1_end_date" name="week1_end_date"  rel="popover" <?php if(empty($_POST['week1_end_date'])) { ?>value="<?php echo $strWeek[0]['enddate']; ?>"<?php } else { ?>value="<?php echo $_POST['week1_end_date']; ?>" <?php } ?> onclick="javascript:getEndDates();" />
           <!-- <span class="help-block" style="width:60%;">Start Date <span style="margin-left:30%;">End Date</span></span> -->
           <input type="hidden" name="hdAction" value="weeks" />
           <input type="button" value="Get Weeks" name="weeks" onclick="getEndDate();" />
          </div>
        </div>
		
		<!--<label>Date</label>
		<div class="input-append">
			<input class="date-picker" id="foo" type="text" />
			<label for="foo" class="add-on"><i class="icon-calendar"></i></label>
		</div>-->
		
		<?php //$i = 1; 
			for($i=2;$i<18;$i++) { 
			$j = $i-1;
			
			$_POST['week'.$i.'_start_date'] = date('Y-m-d', strtotime('+1 day', strtotime($_POST['week'.$j.'_end_date'])));
			$_POST['week'.$i.'_end_date'] = date('Y-m-d', strtotime('+6 days', strtotime($_POST['week'.$i.'_start_date'])));
			
			
			$startdate = $_POST['week'.$i.'_start_date'];
			$enddate   = $_POST['week'.$i.'_end_date'];
			?>
				<div class="control-group">
				  <label class="control-label" for="pick_PickDate">Week<?php echo $i; ?></label>
				  <div class="controls">
					<input type="text"  class="input-large" id="week<?php echo $i;?>_start_date" name="week<?php echo $i;?>_start_date"  rel="popover" <?php if(empty($_POST['week1_start_date']) && empty($_POST['week1_end_date'])) {  ?>value="<?php echo $strWeek[$j]['startdate']; ?>"<?php } else { ?>value="<?php echo $startdate; ?>" <?php } ?> readonly="readonly" />
					<input type="text"  class="input-large" id="week<?php echo $i;?>_end_date" name="week<?php echo $i;?>_end_date"  rel="popover" <?php if(empty($_POST['week1_start_date']) && empty($_POST['week1_end_date'])) {  ?>value="<?php echo $strWeek[$j]['enddate']; ?>"<?php } else { ?>value="<?php echo $enddate; ?>" <?php } ?> readonly="readonly" />
				   <!-- <span class="help-block" style="width:60%;">Start Date <span style="margin-left:30%;">End Date</span></span> -->
				   <input type="hidden" name="hdAction" value="weeks" />
				  </div>
				</div>
			<?php  } $i++; ?>
		<div class="control-group">
		  <label class="control-label" for="pick_PickDate">Wild Card</label>
		  <div class="controls">
			<div class="input-append"><input style="width:182px;" class="date-picker1" type="text" id="wildcard_start_date" name="wildcard_start_date" <?php if(empty($_POST['wildcard_start_date'])) { ?>value="<?php echo $strWeek[17]['startdate']; ?>" <?php } else { ?> value="<?php echo $_POST['wildcard_start_date']; ?>"<?php } ?>/>
				<div class="add-on datepicker-trigger"><i class="icon-calendar"></i></div>
			</div>
		
			<div class="input-append"><input  style="width:182px;" class="date-picker2" type="text" id="wildcard_end_date" name="wildcard_end_date" <?php if(empty($_POST['wildcard_end_date'])) { ?>value="<?php echo $strWeek[17]['enddate']; ?>" <?php } else { ?> value="<?php echo $_POST['wildcard_end_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger2"><i class="icon-calendar"></i></div>
			</div>
			
		  </div>
		</div>
		
		<!--<div class="input-append"><input class="date-picker1" type="text" />
			<div class="add-on datepicker-trigger"><i class="icon-calendar"></i></div>
		</div>-->
		
		<div class="control-group">
		  <label class="control-label" for="pick_PickDate">Divisional</label>
		  <div class="controls">
			<div class="input-append"><input style="width:182px;" class="date-picker3" type="text" id="divisional_start_date" name="divisional_start_date" <?php if(empty($_POST['divisional_start_date'])) { ?>value="<?php echo $strWeek[18]['startdate']; ?>" <?php } else { ?> value="<?php echo $_POST['divisional_start_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger3"><i class="icon-calendar"></i></div>
			</div>
		
			<div class="input-append"><input  style="width:182px;" class="date-picker4" type="text" id="divisional_end_date" name="divisional_end_date" <?php if(empty($_POST['divisional_end_date'])) { ?>value="<?php echo $strWeek[18]['enddate']; ?>" <?php } else { ?> value="<?php echo $_POST['divisional_end_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger4"><i class="icon-calendar"></i></div>
			</div>
		 
		  </div>
		</div>
		
		<div class="control-group">
		  <label class="control-label" for="pick_PickDate">Championship</label>
		  <div class="controls">
			<div class="input-append"><input style="width:182px;" class="date-picker5" type="text" id="championship_start_date" name="championship_start_date" <?php if(empty($_POST['championship_start_date'])) { ?>value="<?php echo $strWeek[19]['startdate']; ?>" <?php } else { ?> value="<?php echo $_POST['championship_start_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger5"><i class="icon-calendar"></i></div>
			</div>
		
			<div class="input-append"><input  style="width:182px;" class="date-picker6" type="text" id="championship_end_date" name="championship_end_date" <?php if(empty($_POST['championship_end_date'])) { ?>value="<?php echo $strWeek[19]['enddate']; ?>" <?php } else { ?> value="<?php echo $_POST['championship_end_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger6"><i class="icon-calendar"></i></div>
			</div>
		  
		  </div>
		</div>
		
		<div class="control-group">
		  <label class="control-label" for="pick_PickDate">Pro Bowl</label>
		  <div class="controls">
			<div class="input-append"><input style="width:182px;" class="date-picker7" type="text" id="probowl_start_date" name="probowl_start_date" <?php if(empty($_POST['probowl_start_date'])) { ?>value="<?php echo $strWeek[20]['startdate']; ?>" <?php } else { ?> value="<?php echo $_POST['probowl_start_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger7"><i class="icon-calendar"></i></div>
			</div>
		
			<div class="input-append"><input  style="width:182px;" class="date-picker8" type="text" id="probowl_end_date" name="probowl_end_date" <?php if(empty($_POST['probowl_end_date'])) { ?>value="<?php echo $strWeek[20]['enddate']; ?>" <?php } else { ?> value="<?php echo $_POST['probowl_end_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger8"><i class="icon-calendar"></i></div>
			</div>
		 
		  </div>
		</div>
		
		<div class="control-group">
		  <label class="control-label" for="pick_PickDate">Super Bowl</label>
		  <div class="controls">
			<div class="input-append"><input style="width:182px;" class="date-picker9" type="text" id="superbowl_start_date" name="superbowl_start_date" <?php if(empty($_POST['superbowl_start_date'])) { ?>value="<?php echo $strWeek[21]['startdate']; ?>" <?php } else { ?> value="<?php echo $_POST['superbowl_start_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger9"><i class="icon-calendar"></i></div>
			</div>
		
			<div class="input-append"><input  style="width:182px;" class="date-picker10" type="text" id="superbowl_end_date" name="superbowl_end_date" <?php if(empty($_POST['superbowl_end_date'])) { ?>value="<?php echo $strWeek[21]['enddate']; ?>" <?php } else { ?> value="<?php echo $_POST['superbowl_end_date']; ?>"<?php } ?> />
				<div class="add-on datepicker-trigger10"><i class="icon-calendar"></i></div>
			</div>
		  </div>
		</div>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" onclick="javascript:history.go(-1);">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
	  $(document).ready(function(){
	  		$(".date-picker").datepicker({
                 format: 'yyyy-mm-dd'           
            });
	  		$(".wildcard-append .date-picker").datepicker({
                 format: 'yyyy-mm-dd'           
            });
	  		$('#week1_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
			$(".date-picker").datepicker();
			$(".datepicker-trigger").on("click", function() {
				$(".date-picker1").datepicker("show");
			});
			
			$(".datepicker-trigger2").on("click", function() {
				$(".date-picker2").datepicker("show");
			});
			
			$(".datepicker-trigger3").on("click", function() {
				$(".date-picker3").datepicker("show");
			});
			
			$(".datepicker-trigger4").on("click", function() {
				$(".date-picker4").datepicker("show");
			});
			
			
			$(".datepicker-trigger5").on("click", function() {
				$(".date-picker5").datepicker("show");
			});
			
			$(".datepicker-trigger6").on("click", function() {
				$(".date-picker6").datepicker("show");
			});
			
			$(".datepicker-trigger7").on("click", function() {
				$(".date-picker7").datepicker("show");
			});
			
			$(".datepicker-trigger8").on("click", function() {
				$(".date-picker8").datepicker("show");
			});
			
			$(".datepicker-trigger9").on("click", function() {
				$(".date-picker9").datepicker("show");
			});
			
			$(".datepicker-trigger10").on("click", function() {
				$(".date-picker10").datepicker("show");
			});

	  		$('#wildcard_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#wildcard_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#divisional_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#divisional_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#championship_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#championship_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#probowl_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#probowl_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#superbowl_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#superbowl_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
			$("#week").validate({
				rules:{
					week1_start_date:"required",
					
				},
				messages:{
					week1_start_date:"*",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
		
		function getEndDate()
		{
		startdate = document.getElementById('foo').value;  
		var xmlhttp;
		if (window.XMLHttpRequest)
		  {// code for IE7+, Firefox, Chrome, Opera, Safari
		  xmlhttp=new XMLHttpRequest();
		  }
		else
		  {// code for IE6, IE5
		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		xmlhttp.onreadystatechange=function()
		  {
		  if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
			document.getElementById("week1_end_date").value=xmlhttp.responseText;
			document.getElementById('week').submit();
			}
		  }
		xmlhttp.open("GET","enddate.php?start="+startdate,true); 
		xmlhttp.send(); //return false;
		//document.getElementById('week').submit();
		}
		
		function getEndDates()
		{
		startdate = document.getElementById('foo').value;  
		var xmlhttp;
		if (window.XMLHttpRequest)
		  {// code for IE7+, Firefox, Chrome, Opera, Safari
		  xmlhttp=new XMLHttpRequest();
		  }
		else
		  {// code for IE6, IE5
		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		xmlhttp.onreadystatechange=function()
		  {
		  if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
			document.getElementById("week1_end_date").value=xmlhttp.responseText;
			}
		  }
		xmlhttp.open("GET","enddate.php?start="+startdate,true);
		xmlhttp.send();
		}
		
		function getWeeks(){
			document.getElementById('week').submit();
		}
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

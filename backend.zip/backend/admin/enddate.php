<?php
	$startdate = $_GET['start'];
	$enddatedate = strtotime(date("Y-m-d", strtotime($startdate)) . " +1 week");
	echo date("Y-m-d", $enddatedate); 
?>
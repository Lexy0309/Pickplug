<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."team-functions.php");
 checkLogin();
 global $table_config;
 
	if(isset($_POST['Submit'])){
		if($_FILES) {
			@$strImageProperties = getimagesize($_FILES["file_File"]["tmp_name"]);
			if($strImageProperties[0]>=$TeamimgWidth && $strImageProperties[1]>=$TeamimgHeight)  {
				$strBannerCount = CheckDataExists($table_config["team"],'TeamName',$_POST['team_TeamName']);
				if($strBannerCount==0){
					$ary['team_TeamName']  = $_POST['team_TeamName'];
					$ary['team_Status'] 	= $_POST['team_Status'];

					
					$BannerId	= insertTeamsDetails($ary,"team_",$table_config["team"],$_FILES);	
					if(!empty($BannerId)){
						$strMessage="Team Detail added successfully";
						$strMessageClass="success";
						unset($_POST);
					}	
				} else {
				   $strMessage="Team Name already exists";
				   $strMessageClass="error";
				} 
			} else {
				$strMessage="Uploaded image greater than ".$TeamimgWidth." X ".$TeamimgHeight." pixels";
				$strMessageClass="error";
			}	
		}
	}
?>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addSport" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Add Team</legend>
        
        <div class="control-group">
          <label class="control-label" for="team_TeamName">Team Name*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="team_TeamName" name="team_TeamName"  rel="popover" value="<?php echo $_POST['team_TeamName'];?>" />
          </div>
        </div>
		
		<div class="control-group">
        	<label class="control-label" for="team_TeamIcon">Team Icon</label>
			<div class="controls">
				<input type="file" id="file_File" name="file_File"  size="74">
				<span class="help-block">Uploaded image greater than <?php echo $TeamimgWidth; ?> X <?php echo $TeamimgHeight; ?> pixels</span> 
			</div>
        </div>
        
		<div class="control-group">
			<label class="control-label" for="team_Status">Status</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="team_Status" id="team_Status_Active"  value="Active" checked="checked"   /> Active
				</label>
				<label class="radio">
					<input type="radio" name="team_Status" id="team_Status_Inactive" value="Inactive" /> Inactive
				</label>
			</div>
        </div>       
		
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listteam.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
					 
			$("#addSport").validate({
				rules:{
					sport_SportName:"required",
				},
				messages:{
					sport_SportName:"Enter the Sport Name",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

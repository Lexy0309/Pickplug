<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."team-functions.php");
 checkLogin();
 global $table_config;
 $SportId = base64_decode($_REQUEST['id']);// Get Userid from URL
 
	if(isset($_POST['Submit'])){
		if(!empty($_FILES['file_File']['name'])) {
				@$strImageProperties = getimagesize($_FILES["file_File"]["tmp_name"]);
			    if($strImageProperties[0]>=$TeamimgWidth && $strImageProperties[1]>=$TeamimgHeight)  {
				$strGalleryCount = CheckDataExists($table_config["team"], 'TeamName', $_POST['team_TeamName'],$Field='Id',$SportId);
				if($strGalleryCount==0){
					$ary['team_TeamName']  = $_POST['team_TeamName'];
					$ary['team_Status'] 	= $_POST['team_Status'];
					$ary['team_ModifiedDate'] 	= date('Y-m-d H:i:s');

								
					$strUserId	= updateSportsDetails($ary,"team_",$table_config["team"],$SportId,$_FILES);	
					
					if(!empty($strUserId)){
						$strMessage="Team Details updated successfully";
						$strMessageClass="success";
						unset($_POST);
					}	
				} else {
				   $strMessage="Team Name already exists";
				   $strMessageClass="error";
				}
				}else {
				$strMessage="Uploaded image greater than ".$TeamimgWidth." X ".$TeamimgHeight." pixels";
				$strMessageClass="error";
			}
			
		}else {
			$strGalleryCount = CheckDataExists($table_config["team"], 'TeamName', $_POST['team_TeamName'],$Field='Id',$SportId);
			if($strGalleryCount==0){
				    $ary['team_TeamName']  = $_POST['team_TeamName'];
					$ary['team_Status'] 	= $_POST['team_Status'];
					$ary['team_ModifiedDate'] 	= date('Y-m-d H:i:s');
							
					$strUserId	= updateSportsDetails($ary,"team_",$table_config["team"],$SportId,$_FILES);	
				
				if(!empty($strUserId)){
					$strMessage="Team details updated successfully";
					$strMessageClass="success";
					unset($_POST);
				}	
			} else {
			   $strMessage="Team Name already exists";
			   $strMessageClass="error";
			}
		}
	} 
	
	$arrUser = GetRecordsValuesById($table_config["team"],$SportId);
	
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="editHere" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Edit Sport</legend>
        
        <div class="control-group">
          <label class="control-label" for="sport_SportName">SportName *</label>
          <div class="controls">
		  	  <input type="text"  class="input-xxlarge" id="team_TeamName" name="team_TeamName"  rel="popover" value="<?php echo $arrUser['TeamName'];?>" />
          </div>
        </div>
		        
		<div class="control-group">
			<label class="control-label" for="user_Photo">Sport Icon</label>
			<div class="controls">
				<input type="file" id="file_File" name="file_File"  size="74">
				 <span class="help-block">Uploaded image greater than <?php echo $TeamimgWidth; ?> X <?php echo $TeamimgHeight; ?> pixels</span> 
				<?php if($arrUser['TeamIcon']!="" && file_exists(UPLOADLOCALPATH."team/thumb/".$arrUser['thumb'])) { ?>
				&nbsp;			
				<a data-toggle="lightbox" href="#demoLightbox" style="margin:10px 0 0;float:left;">
				<img src="<?php echo SITEGLOBALUPLOADPATH;?>team/<?php  echo $arrUser['thumb'];?>" width="65" height="65" alt="" />
				</a>	
				
				<div id="demoLightbox" class="lightbox hide fade"  tabindex="-1" role="dialog" aria-hidden="true">
					<div class='lightbox-header'>
						<button type="button" class="close" data-dismiss="lightbox" aria-hidden="true">&times;</button>
					</div>
					<div class='lightbox-content'>
						<img src="<?php echo SITEGLOBALUPLOADPATH;?>team/<?php  echo $arrUser['thumb'];?>" width="" height="" alt=""/>
					</div>
				</div>	
				<?php } ?>	
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label" for="sport_Status">Status</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="team_Status" id="team_Status_Active"  value="Active"  <?php if($arrUser['Status']=="Active") { ?>checked="checked" <?php } ?>   /> Active
				</label>
				<label class="radio">
					<input type="radio" name="team_Status" id="team_Status_Inactive" value="Inactive" <?php if($arrUser['Status']=="Inactive") { ?>checked="checked" <?php } ?> /> Inactive
				</label>
			</div>
        </div>      
	  
        
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listteam.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
	  		
			$("#editHere").validate({
				rules:{
					sport_SportName:"required",
				},
				messages:{
					sport_SportName:"Enter Sport Name",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
			//called when key is pressed in textbox
			$("#user_PhoneNumber").keypress(function (e) {
				//if the letter is not digit then display error and don't type anything
				if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				//display error message
					$("#errmsg").html("Digits Only").show().fadeOut("slow");
					return false;
				}
			});
		});
	  </script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-lightbox.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

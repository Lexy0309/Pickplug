<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."subscription-functions.php");
 include(SITEADMININCLUDEPATH."api-functions.php");
 checkLogin();

 $userlogs = getuserlogs();
	
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
   
    <div class="span">
	
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
	  
      
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Device Make</th>
						<th>Device Model</th>
						<th>OS Version</th>
						<th>Engine</th>
						<th>Username</th>
						<th>Subscription</th>
						<th>Log Date</th>
          </tr>
        </thead>
        <?php if($userlogs) {
		$i=1;
		foreach($userlogs as $log) {
					
					$userdetails = getUserDetails($log["user"]);
					$subscription = getsubscriptiondetailsbyuser($log["user"]);
					
		?>
        <tbody>
          <tr>
						<td width="10%"><?php echo $log['devicemake'];?></td>
						<td width="10%"><?php echo $log['devicemodel'];?></td>
						<td width="10%"><?php echo $log['deviceos'];?></td>
						<td width="10%"><?php echo $log['devicebrowser'];?></td>
            <td width="20%"><?php echo ($userdetails['FullName']!='(null)')?$userdetails['FullName']:$userdetails['Email'];?></td>
						<td width="10%"><?php echo $subscription;?></td>
						<td width="10%"><?php echo date("Y-m-d G:i:s", $log['updatedon']);?></td>
          </tr>
        </tbody>
        <?php $i++; } } else { ?>
        <tr>
          <td colspan="7" align="center"><p style="color:red; text-align:center;">No records found</p></td>
        </tr>
        <?php } ?>
      </table>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>
<script>
	function cancelsubscription(trid, user, sid)
	{
		if(confirm("Are you sure want to cancel subscription?")){
			window.location.href = "<?php echo $global_config["SiteGlobalAdminPath"];?>usersubscriptions.php?trid="+trid+"&user="+user+"&sid="+sid;
		}
	}
</script>




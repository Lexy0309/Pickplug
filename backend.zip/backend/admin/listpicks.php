<?php

 include("includes/common.php");

 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');

 include(SITEADMINTEMPLATEPATH."header.php");

 include(SITEADMININCLUDEPATH."picks-functions.php");

 checkLogin();

	if($_REQUEST['op']=='delete' && !empty($_REQUEST['id'])) {

		//$deleteid = doDeleteRecord($_REQUEST['id'],$table_config["picks"]);
		$deleteid = doDeleteRecordByStatuses($_REQUEST['id'],$table_config["picks"]);

		if($deleteid) {

			$strMessage="Select Record Deleted Successfully";

			$strMessageClass="success";

		}

	}

	

	$targetpage=basename($_SERVER['SCRIPT_FILENAME']);

	$where=" Status='Active' AND IsDeleted='No'";

	if(isset($_GET['key'])){

		$where.=" AND Title like '%".trim($_GET['key'])."%'";

		$targetpage.="?key=".trim($_GET['key'])."";

	} else {

		$targetpage.="?";

	}

	if(!empty($_REQUEST['search_by_SportName'])) {
		$where.=" AND SportName = '".$_REQUEST['search_by_SportName']."'";
	}
	if(!empty($_REQUEST['search_by_PickStatus'])) {
		$where.=" AND PickStatus = '".$_REQUEST['search_by_PickStatus']."'";
	}
	
	$arrSportName = getSportName($table_config["sport"]);
	$totSportCount = count($arrSportName );
	

	$total_pages=GetTotalRecordsCount($table_config["picks"],$where);

	 

	$searchArray["pagename"]    = basename($_SERVER['SCRIPT_FILENAME']);

 	$searchArray["tablename"]   = $table_config["sport"];

 	$searchArray["searchfield"] = "TeamName";

	$searchArray["where"]		= $where;

	

	include($global_config["SiteAdminIncludePath"]."page-calculation.php");



	$arrFieldSet = '*';	

	$orderBy = " ORDER BY Id DESC ";

	$arrUsers  = GetAllRecordsValues($table_config["picks"],$arrFieldSet,$start,$limit,$where,$orderBy);

	include(SITEADMININCLUDEPATH."pagination.php");

?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php

	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
     	 <div class="add"> <a href="<?php echo SITEGLOBALADMINPATH;?>addpicks.php">
        <button type="button" class="btn">Add Picks</button>
        </a> </div>
        
        <div class="search_frame" style="float:right;">
		  <form name="Search" id="Search" method="post" action="listpicks.php">
		  	<select name="search_by_PickStatus" id="search_by_PickStatus" onChange="javascript:document.Search.submit()">
				<option value="">Search by Pick Status</option>
				<option value="Win" <?php if($_REQUEST['search_by_PickStatus']== 'Win') { ?> selected="selected" <?php } ?>> Win </option>
				<option value="Lose" <?php if($_REQUEST['search_by_PickStatus']== 'Lose') { ?> selected="selected" <?php } ?>> Lose </option>
				<option value="Pending" <?php if($_REQUEST['search_by_PickStatus']== 'Pending') { ?> selected="selected" <?php } ?>> Pending </option>
			</select>
			<select name="search_by_SportName" id="search_by_SportName" onChange="javascript:document.Search.submit()">
				<option value="">Search by Sport Name</option>
				<?php foreach($arrSportName as $sportsName) { ?>		
				 	<option value="<?php echo $sportsName['Id']; ?>" <?php if($_REQUEST['search_by_SportName']==$sportsName['Id']) { ?> selected="selected" <?php } ?>>
				        <?php echo $sportsName['SportName']; ?></option>
				<?php } ?>
			</select>
		  </form>
      </div>
      
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Sport Name</th>
            <th>Visiting Team</th>
            <th>Home Team</th>
            <th>Pick Date</th>
            <th style="text-align:center">Added Date</th>
            <th style="text-align:center;">Action</th>
          </tr>
        </thead>
        <?php if($arrUsers) {

		$i=1;

		foreach($arrUsers as $arrUser) {

			$sportname=GetAllDetailsById($table_config["sport"],$arrUser['SportName']); //Get Sport Name

			$teamname=GetAllDetailsById($table_config["team"],$arrUser['VisitingTeam']);//Get Visiting & Home Team nameHomeTeam

			$hometeam=GetAllDetailsById($table_config["team"],$arrUser['HomeTeam']);//Get Visiting & Home Team name

		?>
        <tbody>
          <tr>
            <td width="15%"><?php echo $sportname['SportName'];?></td>
            <td width="12%"><?php echo $teamname['TeamName'];?></td>
            <td width="12%"><?php echo $hometeam['TeamName'];?></td>
            <?php if($sportname['SportName']=='NFL') { 
				 $pickweek=GetAllDetailsById($table_config["week"],$arrUser['NflPick']);
			?>
            <td width="15%"><?php echo $pickweek['name']; ?></td>
            <?php } else { ?>
            <td width="15%"><?php echo $arrUser['PickDate'];?></td>
            <?php } ?>
            <td align="center" width="15%" style="text-align:center"><?php echo date("M j, Y - h:i a",strtotime($arrUser['AddedDate']));?></td>
            <td align="center" style="text-align:center;" width="5%"><a href="<?php echo SITEGLOBALADMINPATH.'editpicks.php?id='.base64_encode($arrUser['Id']); ?>" ><img src="images/edit.gif" alt="edit" title="edit"/></a>&nbsp;&nbsp; <a href="<?php echo SITEGLOBALADMINPATH.'listpicks.php?op=delete&id='.$arrUser['Id'];?>" onClick="return confirm('Are you sure want to delete?');"><img src="images/delete.gif" alt="delete" title="delete" /></a><br />
            </td>
          </tr>
        </tbody>
        <?php $i++; } } else { ?>
        <tr>
          <td colspan="6" align="center"><p style="color:red; text-align:center;">No records found</p></td>
        </tr>
        <?php } ?>
      </table>
      <?php if($total_pages>$global_config["PageLimit"]){?>
      <?php print $pagination;?>
      <?php } ?>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."team-functions.php");
 checkLogin();
 global $table_config;

if(isset($_POST['Submit'])) {
	$filename=$_FILES["file_File"]["tmp_name"];
	if($_FILES["file_File"]["size"] > 0)
	{
		$file = fopen($filename, "r");
		$csvdata  = array();
		$i = 0;
		while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE) {
			if($i > 0) {
				$csvdata[] = $emapData;
			}
			$i++;
		}
		fclose($file);
	}
	if(count($csvdata)>=1){
		for($i=0;$i<count($csvdata);$i++){
			$strCount = CheckDataExists($table_config["user"], 'Email', $csvdata[$i][2]);
			if($strCount==0) {
				$ary['user_FullName']        = $csvdata[$i][1];
				$ary['user_Email']           = $csvdata[$i][2];
				$ary['user_Password']        = $csvdata[$i][3];
				$ary['user_PhoneNumber'] 	 = $csvdata[$i][4];
				$ary['user_Birthday'] 		 = $csvdata[$i][5];
				$ary['user_Gender'] 		 = $csvdata[$i][6];
				$strUserId	= addUserDetails($ary,"user_",$table_config["user"],$UserId,$_FILES);	
			}else{
				$ary['user_FullName']        = $csvdata[$i][1];
				$ary['user_Email']           = $csvdata[$i][2];
				$ary['user_Password']        = $csvdata[$i][3];
				$ary['user_PhoneNumber'] 	 = $csvdata[$i][4];
				$ary['user_Birthday'] 		 = $csvdata[$i][5];
				$ary['user_Gender'] 		 = $csvdata[$i][6];
				$strUserId	= updateUserDetailsByEmail($ary,"user_",$table_config["user"],$ary['user_Email']);	
			}
			$strMessage="User details Imported successfully";
			$strMessageClass="success";
	}

	}else {

		$strMessage="Please Choose Import user";
		$strMessageClass="error";	 

	}
}

?>

<div class="span10 pull-left">

  <div class="row" id="fight-wrapper">

    <div class="span">

      <?php

 if(!empty($strMessage)) { ?>

      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>

      <?php } ?>

      <form class="form-horizontal well" id="importUserForm" method="post" enctype="multipart/form-data">

        <fieldset>

        <legend>Import User</legend>

        

      

		

		<div class="control-group">

        	<label class="control-label" for="team_TeamIcon">Import User</label>

			<div class="controls">

				<input type="file" id="file_File" name="file_File"  size="74">

			</div>

        </div>

        

		    

		

        <div class="form-actions">

          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>

          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listuser.php">Cancel</a>

        </div>

        </fieldset>

      </form>

    </div>

  </div>

</div>



<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>


<?php

	function getLoginDetails($username,$password) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["user"]." WHERE Username='".$username."' AND Password='".$password."' AND Published='Yes' AND IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			$ResultArray = array("status"=>"success","message"=>"Login Success");

		} else {

			$ResultArray = array("status"=>"failed","message"=>"Invalid username and password");

		}

		return $ResultArray;

	}



	function getUserDetails($userId) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["member"]." WHERE Id='".$userId."'";

		$results=SelectQry($sql);

		

		if(count($results>=1)){

		  $user['Id']				 = $results[0]['Id'];

		  $user['UserName']			 = $results[0]['UserName'];

		  $user['Password'] 		 = $results[0]['Password'];

		  $user['FacebookId'] 		 = $results[0]['FacebookId'];

		  $user['Email'] 	 		 = $results[0]['Email'];

		  $user['SessionId']		 = $results[0]['SessionId'];

		}

		return $user;

	}



	function insertLoginDetails($objArray,$Prefix,$type='') {

		global $table_config,$global_config;

		$strEmailCheckUser = CheckDataExists($table_config["member"],'Email', $objArray['userEmail']);

		

		if($strEmailCheckUser == 0){

			$counter = 0;

			foreach($objArray as $key=>$value){

				$pos = strpos($key, $Prefix);

				if (!is_integer($pos)) {

				}else{

					$key = str_replace($Prefix,"",$key);

					$insertArray[$counter]["Field"] = $key;

					$insertArray[$counter]["Value"] = stripslashes($value);

					$counter++;

				}

			}

			

			$insert_id = doInsert($table_config["member"],$insertArray);

			if($insert_id) {

				$user 		 = getUserDetails($insert_id);

				$ResultArray = array("status"=>"success","message"=>"user details inserted successfully","type"=>$type,"user"=>$user);

			}

		} else {

			$ResultArray = array("status"=>"failed","message"=>"Eamil Address already exit");

		}	

		return $ResultArray;	

	}



	function checkLoginDetails($username,$password,$facebookid,$email='',$strfbimage='') {

		global $table_config,$global_config;

		if(!empty($email) && !empty($password)) {

			$sql="SELECT * FROM ".$table_config["member"]." WHERE Email='".$email."' AND Password='".$password."' AND Published='Yes' AND IsDeleted='No'";

		} else if (!empty($facebookid)) {

			$sql="SELECT * FROM ".$table_config["member"]." WHERE FacebookId='".$facebookid."' AND Published='Yes' AND IsDeleted='No'";

		}

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			$sessionId        =  md5(uniqid(microtime()));

			if(!empty($facebookid)){	

				$updatesql = "UPDATE ".$table_config["member"]." SET `SessionId` = '".$sessionId."'  WHERE `Id` = '".$results[0]['Id']."'";	

			} else {			

				$updatesql = "UPDATE ".$table_config["member"]." SET `SessionId` = '".$sessionId."'  WHERE `Id` = '".$results[0]['Id']."'";

			}	

			mysql_query($updatesql);

			

			if(empty($facebookid)){

				$type="Normal";

			} else {

				$type="Facebook";

			}

			$userDetails = getUserDetails($results[0]['Id']);

			

			$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>$type,"user"=>$userDetails);

		} else {

			$ResultArray = array("status"=>"failed","message"=>"Invalid Login details");

		}

		return $ResultArray;

	}

	

	function checkNewLoginDetails($username,$password,$facebookid,$email='',$strfbimage='') {

		global $table_config,$global_config;

		if(preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email)){

			if(!empty($email)) {

				 $sql="SELECT * FROM ".$table_config["member"]." WHERE Email='".$email."' AND Published='Yes' AND IsDeleted='No'";

			} else if (!empty($facebookid)) {

				$sql="SELECT * FROM ".$table_config["member"]." WHERE FacebookId='".$facebookid."' AND Published='Yes' AND IsDeleted='No'";

			}

			$results=SelectQry($sql);

			

			if(count($results) > 0) {

				$sessionId        =  md5(uniqid(microtime()));

				if(!empty($facebookid)){	

					$updatesql = "UPDATE ".$table_config["member"]." SET `SessionId` = '".$sessionId."'  WHERE `Id` = '".$results[0]['Id']."'";	

				} else {			

					$updatesql = "UPDATE ".$table_config["member"]." SET `SessionId` = '".$sessionId."'  WHERE `Id` = '".$results[0]['Id']."'";

				}	

				mysql_query($updatesql);

				

				if(empty($facebookid)){

					$type="Normal";

				} else {

					$type="Facebook";

				}

				$userDetails = getUserDetails($results[0]['Id']);

				

				$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>$type,"user"=>$userDetails);

			} else {

				$sessionId =  md5(uniqid(microtime()));

				$addedDate = date('Y-m-d H:i:s');

				$strEmailCheckUser = CheckDataExists($table_config["member"],'Email', $email);

				if($strEmailCheckUser == 0){

					$sql = "Insert into ".$table_config["member"]." ( `UserName`, `Email`, `FacebookId`, `SessionId`, `AddedDate` ) Values ('".$username."', '".$email."', '".$facebookid."', '".$sessionId."', '".$addedDate."')";

					mysql_query($sql);

					$lastInsertId = mysql_insert_id();

					

					if(empty($facebookid)){

						$type="Normal";

					} else {

						$type="Facebook";

					}

					

					$userDetailsNew = getUserDetails($lastInsertId);

					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>$type,"user"=>$userDetailsNew);

				} else {

					$ResultArray = array("status"=>"failed","message"=>"Eamil Address already exit");

				}

				//$ResultArray = array("status"=>"failed","message"=>"Invalid Login details");

			}

		} else {

			$ResultArray = array("status"=>"failed","message"=>"Email Address is not valid");

		}

		return $ResultArray;

	}

	

	function checkUserById($tbl_name,$Id){

		$sql="SELECT * from ".$tbl_name." where Id='".$Id."'";

		$result=SelectQry($sql);

		

		if($result) {

			return 1;

		} else {

			return 0;

		}

	}



	function checkUserBySessionId($tbl_name,$Id){

		$sql="SELECT * from ".$tbl_name." where SessionId='".$Id."'";

		$result=SelectQry($sql);

		return $result;

	}



	function getGlobalSettingsValue() {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["settings"];

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	  	   = $result['Id'];

				if($result['URLShortening'] == 'Enable'){

					$strUrlShortening = 'Yes';

				} else {

					$strUrlShortening = 'No';

				}

				if($strUrlShortening == 'Yes'){

					$username	   = $result['BitlyUsername'];

					$password 	   = $result['BitlyPassword'];

				} else {

					$username	   = '';

					$password 	   = '';

				}

				$ResultArray[] = array('Id'=>$id,'URLShortening'=>$strUrlShortening,'Bit ly Username'=>$username,'Bit ly Password'=>$password);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}



	function getGalleryCategoriesDetails($objArray) {

		global $table_config,$global_config;

		if(isset($objArray['id'])) {

			$sql="SELECT * FROM ".$table_config["gallerycategory"]." WHERE Id = '".$objArray['id']."' AND IsDeleted='No'";

		} else {

			$sql="SELECT * FROM ".$table_config["gallerycategory"]." WHERE IsDeleted='No'";

		}

		

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id = $result['Id'];

				$Category = $result['CategoryName'];

				$AddedDate = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"Category"=>$Category,"AddedDate"=>$AddedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}



	function getGalleryDetails($objArray) {

		global $table_config,$global_config;

		if(isset($objArray['GalleryId'])) {

			$sql="SELECT * FROM ".$table_config["gallery"]."  WHERE Id = '".$objArray['GalleryId']."' AND Published ='Yes' AND IsDeleted='No'";

		} else if(isset($objArray['CategoryId'])) {

			$sql="SELECT * FROM ".$table_config["gallery"]."  WHERE CategoryId = '".$objArray['CategoryId']."' AND Published ='Yes' AND IsDeleted='No'";

		} else {	

			$sql="SELECT * FROM ".$table_config["gallery"]." WHERE IsDeleted='No' AND Published ='Yes'";

		}

		

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$CategoryId 	= $result['CategoryId'];

				$OrginalImage	= SITEGLOBALUPLOADPATH.'gallery/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'gallery/thumb/'.$result['thumb'];

				$AddedDate 		= $result['Addeddate'];

				$ResultArray[] = array("Id"=>$id,"CategoryId"=>$CategoryId,"OrginalImage"=>$OrginalImage,"ThumbImage"=>$ThumbImage,"AddedDate"=>$AddedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}



	function getVideoCategoriesDetails($objArray,$parent_id='') {

		global $table_config,$global_config;

		if($parent_id){

			$sql="SELECT * FROM ".$table_config["videocategory"]." WHERE ParentId = '".$parent_id."' AND IsDeleted='No'";

		}else{

			$sql="SELECT * FROM ".$table_config["videocategory"]." WHERE IsDeleted='No' AND ParentId = '0'";

		}

		

		$results=SelectQry($sql);

		foreach($results as $result) {

			$id		  = $result['Id'];

			$ParentId = $result['ParentId'];

			$Category = $result['CategoryName'];

			$AddedDate = $result['AddedDate'];

			$res[] = array("Id"=>$id,"ParentId"=>$ParentId,"Category"=>$Category,"AddedDate"=>$AddedDate);

		}

		return $res;

	}

	

	function getVideoDetailsNew($objArray) {

		global $table_config,$global_config;

		if(isset($objArray['CategoryId']) && isset($objArray['SubCategory'])) {

			$sql="SELECT * FROM ".$table_config["videocategory"]."  WHERE ParentId = '".$objArray['CategoryId']."' AND Id = '".$objArray['SubCategory']."'";

		}

		$results=SelectQry($sql);

		if(count($results) > 0) {

			$VideoLink 		= $results[0]['PlayList'];

			$url 			= explode('=',$VideoLink);

			$results        = get_youtubeVideos($url[1]);

			$CategoryId 	= $objArray['CategoryId'];

			$SubCategory 	= $objArray['SubCategory'];

 		}

		

		$i=0;

		if(count($results) > 0) {

			foreach($results as $result) {

			    $i++;

				$id					= $i;	

				$VideoTitle 		=  $result->{'title'}->{'$t'};

				$VideoDescription 	=  replace(strip_tags($result->{'media$group'}->{'media$description'}->{'$t'}));

				$VideoDescription   =  preg_replace("/[\t\s]+/", " ", trim($VideoDescription));

				$VideoReview	 	=  $result->{'yt$statistics'}->{'viewCount'};

				$VideoPostedDate	=  $result->{'published'}->{'$t'};

				$VideoAuthor		=  $result->{'author'}[0]->{'name'}->{'$t'}; 

				$VideoThumbnailUrl	=  $result->{'media$group'}->{'media$thumbnail'}[0]->{'url'};

				$VideoLink 			=  $result->{'link'}[0]->{'href'};

				$ResultArray[] = array("Id"=>$id,"CategoryId"=>$CategoryId,"SubCategory"=>$SubCategory, /*"VideoName"=>$VideoName,*/ "VideoLink"=>$VideoLink,"VideoTitle"=>$VideoTitle,"VideoDescription"=>$VideoDescription,"VideoReview"=>$VideoReview,"VideoPostedDate"=>date('d F Y',strtotime($VideoPostedDate)),"VideoAuthor"=>$VideoAuthor,"VideoThumbnailUrl"=>$VideoThumbnailUrl);

				

			}		

		} else {

			$ResultArray = array("message"=>"No videos found");

		}

		return $ResultArray;

	}

	



	function getVideoDetails($objArray) {

		global $table_config,$global_config;

		if(isset($objArray['CategoryId']) && isset($objArray['SubCategory'])) {

			$sql="SELECT * FROM ".$table_config["video"]."  WHERE CategoryId = '".$objArray['CategoryId']."' AND SubCategory = '".$objArray['SubCategory']."' AND Published ='Yes' AND IsDeleted='No'";

		}else if(isset($objArray['SubCategory'])) {

			$sql="SELECT * FROM ".$table_config["video"]."  WHERE SubCategory = '".$objArray['SubCategory']."' AND Published ='Yes' AND IsDeleted='No'";

		} else if(isset($objArray['CategoryId'])) {

			$sql="SELECT * FROM ".$table_config["video"]."  WHERE CategoryId = '".$objArray['CategoryId']."' AND Published ='Yes' AND IsDeleted='No'";

		} else {	

			$sql="SELECT * FROM ".$table_config["video"]." WHERE IsDeleted='No' AND Published ='Yes'";

		}

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$CategoryId 	= $result['CategoryId'];

				$SubCategory 	= $result['SubCategory'];

				$VideoName 		= $result['VideoName'];

				$VideoLink 		= $result['VideoLink'];

				$AddedDate 		= $result['AddedDate'];

				$url 			= explode('=',$VideoLink);

				$youtube 		= get_youtube($url[1]);

				$author 		= $youtube->{'author'};

				$thum 			= $youtube->{'media$group'}->{'media$thumbnail'};

				$VideoTitle 		=  $youtube->{'title'}->{'$t'};

				$VideoDescription 	=  replace(strip_tags($youtube->{'media$group'}->{'media$description'}->{'$t'}));

				$VideoDescription   =  preg_replace("/[\t\s]+/", " ", trim($VideoDescription));

				$VideoReview	 	=  $youtube->{'yt$statistics'}->{'viewCount'};

				$VideoPostedDate	=  $youtube->{'published'}->{'$t'};

				$VideoAuthor		=  $author[0]->name->{'$t'};

				$VideoThumbnailUrl	=  $thum[0]->{'url'};

				$ResultArray[] = array("Id"=>$id,"CategoryId"=>$CategoryId,"SubCategory"=>$SubCategory, /*"VideoName"=>$VideoName,*/ "VideoLink"=>$VideoLink,"VideoTitle"=>$VideoTitle,"VideoDescription"=>$VideoDescription,"VideoReview"=>$VideoReview,"VideoPostedDate"=>date('d F Y',strtotime($VideoPostedDate)),"VideoAuthor"=>$VideoAuthor,"VideoThumbnailUrl"=>$VideoThumbnailUrl,"AddedDate"=>$AddedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No videos found");

		}

		return $ResultArray;

	}

	

	function getBannerDetails($objArray) {

		global $table_config,$global_config;

		if(isset($objArray['BannerId'])) {

			$sql="SELECT * FROM ".$table_config["banner"]."  WHERE Ident = '".$objArray['BannerId']."' AND Published ='Yes' AND IsDeleted='No'";

		} else {	

			$sql="SELECT * FROM ".$table_config["banner"]." WHERE IsDeleted='No' AND Published ='Yes'";

		}

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Ident'];

				$BannerImage 	= SITEGLOBALUPLOADPATH.'banner/'.$result['BannerImage'];

				$BannerText 	= $result['BannerText'];

				$BannerLink 	= $result['BannerLink'];

				$AddedDate 		= $result['AddedDate'];

				if($result['BannerText']!=''){

					$type		= 'Text';

				} else if($result['BannerLink']!=''){

					$type		= 'Link';

				}	else {

					$type		= '';

				}

				

				$strBannerDetailsByText = getBannerDetailsByText($BannerText);

				$contentId    = $strBannerDetailsByText[0]['Id'];

			

				$ResultArray[] = array("Id"=>$id,"BannerImage"=>$BannerImage, "BannerText"=>$BannerText, "BannerLink"=>$BannerLink, "AddedDate"=>$AddedDate,"Type"=>$type,"ContentId"=>$contentId);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}	



	function getContentCategoriesDetails($type) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["contentcategory"]." WHERE Type = '".$type."' and IsDeleted='No' and ParentId = '0'";

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$parentId  	   = $result['ParentId'];

				$Type   	   = $result['Type'];

				$categoryName  = $result['CategoryName'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"Type"=>$Type,"Category"=>$categoryName,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	/*function getContentDetailsByCategory($contenttype='',$categoryId=''){

		global $table_config,$global_config;

		if($contenttype!='' && $categoryId!=''){

			$where = "And B.Type = '".$contenttype."' And B.Id= '".$categoryId."'";

		} elseif($categoryId!=''){	

			$where = "And B.Id= '".$categoryId."'";

		} elseif($contenttype!='' ){	

			$where = "And B.Type = '".$contenttype."'";

		} else {

			$where = '';

		}

		

		$sql="SELECT A.*,B.* FROM ".$table_config["content"]." as A, ".$table_config["contentcategory"]." as B WHERE A.IsDeleted='No' ".$where." group by B.Id ";

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$Type   	   = $result['Type'];

				$categoryName  = $result['CategoryName'];

				$ResultArray[] = array("Id"=>$id,"Type"=>$Type,"CategoryName"=>$categoryName);

			}

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	} */

	

	function getContentDetailsById($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){

			$where = "CategoryId = '".$categoryId."' AND ";

		} else {

			$where ="";

		}



		$sql="SELECT * FROM ".$table_config["content"]." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$ResultArray[]  = array("Id"=>$id,"Category"=>$title);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getContentDetails($contentType,$categoryId='') {

		global $table_config,$global_config;

		if($contentType!='' && $categoryId!=''){

			$where = "And ContentType = '".$contentType."' And Id= '".$categoryId."'";

		} elseif($categoryId!=''){	

			$where = "And Id= '".$categoryId."'";

		} elseif($contentType!='' ){	

			$where = "And ContentType = '".$contentType."'";

		} else {

			$where = '';

		}



		$sql="SELECT * FROM ".$table_config["content"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'content/'.$result['Image'];



				



				$ThumbImage 	= SITEGLOBALUPLOADPATH.'content/thumb/thumb_'.$result['Image'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	/*function getContentDetails($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){

			$where = "CategoryId = '".$categoryId."' AND ";

		} else {

			$where ="";

		}



		$sql="SELECT * FROM ".$table_config["content"]." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				$description 	= $result['Description'];

				$image 			= SITEGLOBALUPLOADPATH.'content/'.$result['Image'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"Description"=>$description,"OrginalImage"=>$image,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}*/



	function getCategoryName($parentId){

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["videocategory"]." WHERE Id = '".$parentId."' AND IsDeleted='No'";

		$results=SelectQry($sql);

		return $results;

	}

	function getMenuDetails() {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["menu"]." WHERE IsDeleted='No' AND Published ='Yes' ORDER BY Position";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Ident'];

				$Type 			= $result['Type'];

				$Image 			= SITEGLOBALUPLOADPATH.'menu/'.$result['Image'];

				$AddedDate 		= $result['Addeddate'];

				

				$ResultArray[] = array("Ident"=>$id,"MenuImage"=>$Image, "Type"=>$Type,"AddedDate"=>$AddedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getsettings($objArray) {



		global $table_config,$global_config;



		$sql="SELECT * FROM ".$table_config["sitesettings"]." WHERE Id = '1'";



		$results=SelectQry($sql);



		if(count($results) > 0) {



			foreach($results as $result) {



				$ResultArray1[] = array("Ident"=>$result['Id'],"LiveStreamingURL"=>$result['live_streaming_url']);



			}



		}



		return $ResultArray1;



	}	

	function getAllDetails($objArray) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["sitesettings"]." WHERE Id = '1'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$ResultArray1[] = array("Ident"=>$result['Id'],"Live Streaming URL"=>$result['live_streaming_url']);

			}

		}

		

		$sqlMenu="SELECT * FROM ".$table_config["menu"]." WHERE IsDeleted='No' AND Published ='Yes' ORDER BY Position";

		$resultsMenu=SelectQry($sqlMenu);

		if(count($resultsMenu) > 0) {

			foreach($resultsMenu as $resultMenu) {

				$id 			= $resultMenu['Ident'];

				$Type 			= $resultMenu['Type'];

				$Image 			= SITEGLOBALUPLOADPATH.'menu/'.$resultMenu['Image'];

				$AddedDate 		= $resultMenu['Addeddate'];



				



				if($id==8){



					$contentId    = getAboutContentText();



				}else{



					$contentId    ='';



				}

				

				$ResultArray2[] = array("Ident"=>$id,"MenuImage"=>$Image, "Type"=>$Type,"AddedDate"=>$AddedDate,"ContentId"=>$contentId);

			}		

		} 

		

		if(isset($objArray['BannerId'])) {

			$sqlBanner="SELECT * FROM ".$table_config["banner"]."  WHERE Id = '".$objArray['BannerId']."' AND Published ='Yes' AND IsDeleted='No'";

		} else {	

			$sqlBanner="SELECT * FROM ".$table_config["banner"]." WHERE IsDeleted='No' AND Published ='Yes'";

		}

		$resultsBanner=SelectQry($sqlBanner);

		

		if(count($resultsBanner) > 0) {

			foreach($resultsBanner as $resultBanner) {

				$id 			= $resultBanner['Ident'];

				$BannerImage 	= SITEGLOBALUPLOADPATH.'banner/'.$resultBanner['BannerImage'];

				$BannerText 	= $resultBanner['BannerText'];

				$BannerLink 	= $resultBanner['BannerLink'];

				$AddedDate 		= $resultBanner['AddedDate'];

				if($resultBanner['BannerText']!=''){

					$type		= 'Text';

				} else if($resultBanner['BannerLink']!=''){

					$type		= 'Link';

				}	else {

					$type		= '';

				}

				

				$strBannerDetailsByText = getBannerDetailsByText($resultBanner['BannerText']);

				$contentId    = $strBannerDetailsByText[0]['Id'];

				$ResultArray3[] = array("Id"=>$id,"BannerImage"=>$BannerImage, "BannerText"=>$BannerText, "BannerLink"=>$BannerLink, "AddedDate"=>$AddedDate,"Type"=>$type,"ContentId"=>$contentId);

			}		

		} 

		

		$resAry = array();

		$resAry1 = array();

		$resAry2 = array();

		$resAry3 = array();

		

		$resAry1["Settings"]  = $ResultArray1;

		$resAry2["Menu"]      = $ResultArray2;

		$resAry3["Banner"]    = $ResultArray3;

		

		$resAry	= array_merge($resAry1,$resAry2,$resAry3);

		return $resAry;

	}



	



	function getAboutContentText(){



			$sql = "SELECT Id FROM `tbl_content` where ContentType='About' ORDER BY `Id` DESC LIMIT 0,1";



			$results=SelectQry($sql);



			return $results[0]['Id'];



	}

	function getSponsorsDetails($tbl_name) {

		$sql="SELECT * FROM ".$tbl_name." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$OrginalImage	= SITEGLOBALUPLOADPATH.'sponsors/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'sponsors/thumb/'.$result['thumb'];

				$content 		= replace(str_replace("<br />", "",$result['Content']));

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$OrginalImage,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getSponsorsDetailsById($tbl_name,$Id){

		$sql="SELECT * FROM ".$tbl_name." WHERE Id = '".$Id."' and IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$OrginalImage	= SITEGLOBALUPLOADPATH.'sponsors/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'sponsors/crop/crop_'.$result['Image'];



				$content 		= replace(str_replace("<br />", "",$result['Content']));

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"Title"=>$title,"SubTitle"=>$subTitle,"Image"=>$OrginalImage,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}

		} else{

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}



	



	/* ---------------- Windows ------------------ */



	



	function getGalleryCategoriesDetailsByWin($categoryId=''){



		global $table_config,$global_config;



		if(!empty($categoryId)) {



			$sql="SELECT * FROM ".$table_config["gallerycategory"]." WHERE Id = '".$categoryId."' AND IsDeleted='No'";



		} else {



			$sql="SELECT * FROM ".$table_config["gallerycategory"]." WHERE IsDeleted='No'";



		}



		$results=SelectQry($sql);



		if(count($results) > 0) {



			foreach($results as $result) {



				$id = $result['Id'];



				$Category = $result['CategoryName'];



				$AddedDate = $result['AddedDate'];



				$ResultArray[] = array("Id"=>$id,"Category"=>$Category,"AddedDate"=>$AddedDate);



			}		



		} else {



			$ResultArray[] = array("message"=>"No records found");



		}



		return $ResultArray;	



	}



	function getGalleryDetailsByWin($id){



		global $table_config,$global_config;



		$sql="SELECT * FROM ".$table_config["gallery"]." WHERE IsDeleted='No' AND CategoryId = '".$id."'";



		$results=SelectQry($sql);



		if(count($results) > 0) {



			foreach($results as $result) {



				$id 			= $result['Id'];



				$categoryId		= $result['CategoryId'];



				$GalleryName	= $result['GalleryName'];



				$OrginalImage	= SITEGLOBALUPLOADPATH.'gallery/'.$result['Image'];



				$ThumbImage 	= SITEGLOBALUPLOADPATH.'gallery/crop/crop_'.$result['Image'];



				$Addeddate		= $result['Addeddate'];



				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"OrginalImage"=>$OrginalImage,"ThumbImage"=>$ThumbImage,"Addeddate"=>$Addeddate);



			}		



		} else {



			$ResultArray[] = array("message"=>"No records found");



		}



		return $ResultArray;



	}



	function getVideoCategoriesDetailsByWin(){



		global $table_config,$global_config;



		$sql="SELECT * FROM ".$table_config["videocategory"]." WHERE IsDeleted='No' and ParentId = '0'";



		$results=SelectQry($sql);



		if(count($results) > 0) {



			foreach($results as $result) {



				$Id 		= $result['Id'];



				$ParentId	= $result['ParentId'];



				$Category	= $result['CategoryName'];



				$AddedDate	= $result['AddedDate'];



				$ResultArray[]  = array("Id"=>$Id,"ParentId"=>$ParentId,"Category"=>$Category,"AddedDate"=>$AddedDate);



			}



		} else {



			$ResultArray[] = array("message"=>"No records found");



		}



		return $ResultArray;



	}



	function getVideoDetailsByWin($ParentId,$subCategory){



		global $table_config,$global_config;



		if(!empty($ParentId) && !empty($subCategory)){



			$sql="SELECT * FROM ".$table_config["videocategory"]." WHERE IsDeleted='No' and ParentId = '".$ParentId."' AND Id = '".$subCategory."'";



		} else if(!empty($ParentId)){ 



			$sql="SELECT * FROM ".$table_config["videocategory"]." WHERE IsDeleted='No' and ParentId = '".$ParentId."'";



		}



		$results=SelectQry($sql);



		if(count($results) > 0) {



			foreach($results as $result) {



				//printArray($result); exit;



				$Id 		= $result['Id'];



				$ParentId	= $result['ParentId'];



				$Category	= $result['CategoryName'];



				$AddedDate	= $result['AddedDate'];



				$ResultArray[]  = array("Id"=>$Id,"ParentId"=>$ParentId,"Category"=>$Category,"AddedDate"=>$AddedDate);



			}



		} else {



			$ResultArray[] = array("message"=>"No records found");



		}



		return $ResultArray;



	}



	function getVideosCategorySubCategoriesDetailsByWin($categoryId,$subCategory){



		global $table_config,$global_config;



		if($categoryId!='' && $subCategory!='') {



			$sql="SELECT * FROM ".$table_config["videocategory"]."  WHERE ParentId = '".$categoryId."' AND Id = '".$subCategory."'";  



			$results=SelectQry($sql);



			if(count($results) > 0) {



				$VideoLink 		= $results[0]['PlayList'];



				$url 			= explode('=',$VideoLink);



				$youResults     = get_youtubeVideos($url[1]);



				$CategoryId 	= $categoryId;



				$SubCategory 	= $subCategory;



			}



			$i=0;



			if(count($youResults) > 0) {



				foreach($youResults as $youtubeResult) {



					$i++;



					$id					=  $i;	



					$VideoTitle 		=  $youtubeResult->{'title'}->{'$t'};



					$VideoDescription 	=  replace(strip_tags($youtubeResult->{'media$group'}->{'media$description'}->{'$t'}));



					$VideoDescription   =  preg_replace("/[\t\s]+/", " ", trim($VideoDescription));



					$VideoReview	 	=  $youtubeResult->{'yt$statistics'}->{'viewCount'};



					$VideoPostedDate	=  $youtubeResult->{'published'}->{'$t'};



					$VideoAuthor		=  $youtubeResult->{'author'}[0]->{'name'}->{'$t'}; 



					$VideoThumbnailUrl	=  $youtubeResult->{'media$group'}->{'media$thumbnail'}[0]->{'url'};



					$VideoLink 			=  $youtubeResult->{'link'}[0]->{'href'};



					$ResultArray[] 		= array("Id"=>$id,"CategoryId"=>$CategoryId,"SubCategory"=>$SubCategory, /*"VideoName"=>$VideoName,*/ "VideoLink"=>$VideoLink,"VideoTitle"=>$VideoTitle,"VideoDescription"=>$VideoDescription,"VideoReview"=>$VideoReview,"VideoPostedDate"=>date('d F Y',strtotime($VideoPostedDate)),"VideoAuthor"=>$VideoAuthor,"VideoThumbnailUrl"=>$VideoThumbnailUrl);



				}	



			} else {



				$ResultArray = array('null');



			}



		} 



		return $ResultArray;



	}

	function getContentCategoriesDetailsByWin($type) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["contentcategory"]." WHERE Type = '".$type."' and IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$parentId  	   = $result['ParentId'];

				$Type   	   = $result['Type'];

				$categoryName  = $result['CategoryName'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"Type"=>$Type,"Category"=>$categoryName,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getContentDetailsByIdByWin($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){

			$where = "CategoryId = '".$categoryId."' AND ";

		} else {

			$where ="";

		}

		$sql="SELECT * FROM ".$table_config["content"]." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$ResultArray[]  = array("Id"=>$id,"Category"=>$title);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getContentDetailsByWin($contentType,$categoryId='') {

		global $table_config,$global_config;

		if($contentType!='' && $categoryId!=''){

			$where = "And ContentType = '".$contentType."' And Id= '".$categoryId."'";

		} elseif($categoryId!=''){	

			$where = "And Id= '".$categoryId."'";

		} elseif($contentType!='' ){	

			$where = "And ContentType = '".$contentType."'";

		} else {

			$where = '';

		}

		$sql="SELECT * FROM ".$table_config["content"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$OrginalImage	= SITEGLOBALUPLOADPATH.'content/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'content/thumb/'.$result['thumb'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//,"Description"=>$description

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$OrginalImage,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getAboutDetailsByWin($tbl_name,$Id='') {

		$where = " ContentType = 'About'";

		$sql="SELECT * FROM ".$tbl_name." WHERE ".$where." AND IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'content/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'content/thumb/thumb_'.$result['Image'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//,"Description"=>$description

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getSponsorsDetailsByWin($tbl_name,$Id) {

		if(!empty($Id)){

			$where = " Id = '".$Id."' AND";

		} else {

			$where = "";

		}

		$sql="SELECT * FROM ".$tbl_name." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'sponsors/'.$result['Image'];

				$thumb 			= SITEGLOBALUPLOADPATH.'sponsors/thumb/'.$result['thumb'];

				$content 		= replace(str_replace("<br />", "",$result['Content']));

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$thumb,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getScheduleContentCategoriesDetailsByWin($Type,$Id=''){

		global $table_config,$global_config;

		if($Type!='' && $Id!=''){

			$where = "And ContentType = '".$Type."' And Id= '".$Id."'";

		} else {

			$where = "And ContentType = '".$Type."'";

		}

		$sql="SELECT * FROM ".$table_config["content"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'content/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'content/thumb/'.$result['thumb'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//,"Description"=>$description

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getBannerDetailsByText($text){

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["content"]." WHERE Title = '".$text."' AND IsDeleted='No'";

		$results=SelectQry($sql);

		return $results;

	}

	function getContentDetailsByCategoryId($contentType,$contentName) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["contentcategory"]." WHERE Type = '".$contentType."' and CategoryType = '".$contentName."' and IsDeleted='No' and ParentId = '1'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$contentType	= $result['Type'];

				$categoryType	= $result['CategoryType'];

				$categoryName   = $result['CategoryName'];

				$ResultArray[]  = array("Id"=>$id,"ContentType"=>$contentType,"Type"=>$categoryType,"CategoryName"=>$categoryName);

			}

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getContentDetailsByCategoryType($contentType,$contentName){

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["contentcategory"]." WHERE Type = '".$contentType."' and CategoryName = '".$contentName."' and IsDeleted='No'";

		$strresults=SelectQry($sql);

		$strCategoryType = $strresults[0]['Id'];

		if($strCategoryType){

			$sql="SELECT * FROM ".$table_config["content"]." WHERE CategoryId = '".$strCategoryType."' and IsDeleted='No'";

			$results=SelectQry($sql);

			if(count($results) > 0) {

				foreach($results as $result) {

					$id 			= $result['Id'];

					$title 			= $result['Title'];

					$ResultArray[]  = array("Id"=>$id,"Category"=>$title);

				}	

			} else {

				$ResultArray[] = array("message"=>"No records found");

			}

		}

		return $ResultArray;

	}

	

	/* Highlights */

	function getHighlightsCategoriesDetails() {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE IsDeleted='No' and ParentId = '0'";

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$parentId  	   = $result['ParentId'];

				$Type   	   = $result['ContentType'];

				$categoryName  = $result['ContentName'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"ContentType"=>$Type,"Category"=>$categoryName,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getHighlightDetailsById($categoryId='') {



		global $table_config,$global_config;



		if($categoryId!=''){



			$where = "ParentId = '".$categoryId."' AND ";



		} else {



			$where ="";



		}



		$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$catId 			= $result['ParentId'];

				$title 			= $result['ContentName'];

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$catId,"Category"=>$title);

			}		

		} else {



			$ResultArray[] = array("message"=>"No records found");



		}



		return $ResultArray;

	}

	

	function getHighlightsContentDetails($strId) {

		global $table_config,$global_config;

		if($strId!=''){	

			$where = " AND Id= '".$strId."'";

		}

		$sql="SELECT * FROM ".$table_config["highlight"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'highlights/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'highlights/crop/crop_'.$result['Image'];

				$content 		= str_replace('<br>','\n',replace(strip_tags($result['Content'],'<br>')));

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	

	function getHighlightsDetails($strId) {

		global $table_config,$global_config;



		if($strId!=''){	



			$where = " AND CategoryType= '".$strId."'";



		}



		$sql="SELECT * FROM ".$table_config["highlight"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'highlights/'.$result['Image'];



				



				$ThumbImage 	= SITEGLOBALUPLOADPATH.'highlights/crop/crop_'.$result['Image'];

				$content 		= str_replace('<br>','\n',replace(strip_tags($result['Content'],'<br>')));

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getHighlightsCategoriesDetailsByWin() {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE IsDeleted='No' and ParentId = '0'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$parentId  	   = $result['ParentId'];

				$Type   	   = $result['ContentType'];

				$categoryName  = $result['ContentName'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"ContentType"=>$Type,"Category"=>$categoryName,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getHighlightsDetailsByIdByWin($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){

			$where = "CategoryId = '".$categoryId."' AND ";

		} else {

			$where ="";

		}

		$sql="SELECT * FROM ".$table_config["highlight"]." WHERE ".$where." IsDeleted='No' group by CategoryType";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE Id = '".$result['CategoryId']."' and IsDeleted='No'";

				$Category=SelectQry($sql);

				$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE Id = '".$result['CategoryType']."' and IsDeleted='No'";

				$subCategory=SelectQry($sql);

				$ResultArray[]  = array("Id"=>$id,"Category"=>$Category[0]['ContentName'],"SubCategory"=>$subCategory[0]['ContentName']);

			}		

		} else {

			$ResultArray = array('null');

		}

		return $ResultArray;

	}



	



	function getHighlightsDetailsByWin1($categoryid='',$ParentCategory='') {



		global $table_config,$global_config;



		$where = "And CategoryId = '".$ParentCategory."' and CategoryType = '".$categoryid."'";	



		$sql="SELECT * FROM ".$table_config["highlight"]." WHERE IsDeleted='No' ".$where."";



		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'highlights/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'highlights/thumb/thumb_'.$result['Image'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//,"Description"=>$description

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array('null');

		}

		return $ResultArray;

	}



	

	function getHighlightsDetailsByWin($categoryid='',$subCategory='') {

		global $table_config,$global_config;

		

		$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE ContentName = '".$categoryid."' and IsDeleted='No'";

		$category=SelectQry($sql);

		$sql="SELECT * FROM ".$table_config["highlightcategory"]." WHERE ContentName = '".$subCategory."' and CategoryType = '".$categoryid."' and IsDeleted='No'";

		$subcategory=SelectQry($sql); 

		

		$where = "And CategoryId = '".$category[0]['Id']."' and CategoryType = '".$subcategory[0]['Id']."'";	

		$sql="SELECT * FROM ".$table_config["highlight"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'highlights/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'highlights/thumb/thumb_'.$result['Image'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//,"Description"=>$description

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getDesignersCategoriesDetails() {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE IsDeleted='No' and ParentId = '0'";

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$parentId  	   = $result['ParentId'];

				$Type   	   = $result['ContentType'];

				$categoryName  = $result['ContentName'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"ContentType"=>$Type,"ContentName"=>$categoryName,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getDesignersDetailsById($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){	

			$where = "And CategoryId= '".$categoryId."'";

		} else {

			$where = '';

		}



		$sql="SELECT * FROM ".$table_config["designers"]." WHERE IsDeleted='No' ".$where.""; 

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				$description 	= replace($result['Description']);

				$OrginalImage	= SITEGLOBALUPLOADPATH.'designers/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'designers/thumb/'.$result['thumb'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"Description"=>$description,"OrginalImage"=>$OrginalImage,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getHighlightDetailsByCategoryId($categoryId=''){

		global $table_config,$global_config;

		if($categoryId!=''){	

			$where = "And CategoryType= '".$categoryId."'";

		} else {

			$where = '';

		}

		$sql="SELECT * FROM ".$table_config["highlight"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryType'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'highlights/'.$result['Image'];



				$ThumbImage 	= SITEGLOBALUPLOADPATH.'highlights/thumb/thumb_'.$result['Image'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}

		} else{

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getContentCategoriesDetailsByContent($type) {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["contentcategory"]." WHERE Type = '".$type."' and IsDeleted='No'";

		$results=SelectQry($sql);

		

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$Type   	   = $result['Type'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"Type"=>$Type,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getContentDetailsByContentId() {

		global $table_config,$global_config;



		$sql="SELECT * FROM ".$table_config["content"]." WHERE CategoryId = '".$categoryId."' AND IsDeleted='No'";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$ResultArray[]  = array("Id"=>$id,"Category"=>$title);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getDesignersDetailsByCatId($categoryId='') {



		global $table_config,$global_config;



		if($categoryId!=''){



			$where = "ParentId = '".$categoryId."' AND ";



		} else {



			$where ="";



		}



		$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE ".$where." IsDeleted='No'";

		$results=SelectQry($sql);



		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$catId 			= $result['ParentId'];

				$title 			= $result['ContentName'];

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$catId,"Category"=>$title);

			}		

		} else {



			$ResultArray[] = array("message"=>"No records found");



		}



		return $ResultArray;

	}

	function getDesignersDetailsByCategoryId($categoryId=''){

		global $table_config,$global_config;

		if($categoryId!=''){	

			$where = "And CategoryType= '".$categoryId."'";

		} else {

			$where = '';

		}

		$sql="SELECT * FROM ".$table_config["designers"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryType'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'designers/'.$result['Image'];



				$ThumbImage 	= SITEGLOBALUPLOADPATH.'designers/thumb/thumb_'.$result['Image'];

				$content 		= replace($result['Content']);

				$content 		= preg_replace("/[\t\s]+/", " ", trim($content));

				$addedDate 		= $result['AddedDate'];

				//"Description"=>$description,

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}

		} else{

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getDesignersCategoriesDetailsByWin() {

		global $table_config,$global_config;

		$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE IsDeleted='No' and ParentId = '0'";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 	   	   = $result['Id'];

				$parentId  	   = $result['ParentId'];

				$Type   	   = $result['ContentType'];

				$categoryName  = $result['ContentName'];

				$addedDate     = $result['AddedDate'];

				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"ContentType"=>$Type,"Category"=>$categoryName,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	

	function getDesignersDetailsByIdByWin($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){

			$where = "CategoryId = '".$categoryId."' AND ";

		} else {

			$where ="";

		}

		$sql="SELECT * FROM ".$table_config["designers"]." WHERE ".$where." IsDeleted='No' group by CategoryType";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE Id = '".$result['CategoryId']."' and IsDeleted='No'";

				$Category=SelectQry($sql);

				$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE Id = '".$result['CategoryType']."' and IsDeleted='No'";

				$subCategory=SelectQry($sql);

				$ResultArray[]  = array("Id"=>$id,"Category"=>$Category[0]['ContentName'],"SubCategory"=>$subCategory[0]['ContentName']);

			}		

		} else {

			$ResultArray = array('null');

		}

		return $ResultArray;

	}

	

	function getDesignersDetailsByWin($categoryid='',$subCategory='') {

		global $table_config,$global_config;

		

		$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE ContentName = '".$categoryid."' and IsDeleted='No'";

		$category=SelectQry($sql);

		$sql="SELECT * FROM ".$table_config["designerscategory"]." WHERE ContentName = '".$subCategory."' and CategoryType = '".$categoryid."' and IsDeleted='No'";

		$subcategory=SelectQry($sql); 

		

		$where = "And CategoryId = '".$category[0]['Id']."' and CategoryType = '".$subcategory[0]['Id']."'";	

		$sql="SELECT * FROM ".$table_config["designers"]." WHERE IsDeleted='No' ".$where."";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$categoryId 	= $result['CategoryId'];

				$contentType 	= $result['ContentType'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				//$description 	= replace($result['Description']);

				$image 			= SITEGLOBALUPLOADPATH.'designers/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'designers/thumb/'.$result['thumb'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				//,"Description"=>$description

				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		

		} else {

			$ResultArray[] = array("message"=>"No records found");

		}

		return $ResultArray;

	}



		/* Get Schedule Page Function */



	



	function getScheduleCategoriesDetails() {



		global $table_config,$global_config;



		$sql="SELECT * FROM ".$table_config["schedulecategory"]." WHERE IsDeleted='No' and ParentId = '0'";



		$results=SelectQry($sql);



		



		if(count($results) > 0) {



			foreach($results as $result) {



				$id 	   	   = $result['Id'];



				$parentId  	   = $result['ParentId'];



				$Type   	   = $result['ContentType'];



				$categoryName  = $result['ContentName'];



				$addedDate     = $result['AddedDate'];



				$ResultArray[] = array("Id"=>$id,"ParentId"=>$parentId,"ContentType"=>$Type,"ContentName"=>$categoryName,"AddedDate"=>$addedDate);



			}		



		} else {



			$ResultArray = array("message"=>"No records found");



		}



		return $ResultArray;



	}



	



	function getScheduleDetailsById($categoryId='') {

		global $table_config,$global_config;

		if($categoryId!=''){	

			$where = "And CategoryId= '".$categoryId."'";

		} else {

			$where = '';

		}

		$sql="SELECT * FROM ".$table_config["schedule"]." WHERE IsDeleted='No' ".$where.""; 

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 			= $result['Title'];

				$subTitle 		= $result['SubTitle'];

				$image 			= SITEGLOBALUPLOADPATH.'schedule/'.$result['Image'];

				$ThumbImage 	= SITEGLOBALUPLOADPATH.'schedule/thumb/'.$result['thumb'];

				$content 		= replace($result['Content']);

				$addedDate 		= $result['AddedDate'];

				$ResultArray[]  = array("Id"=>$id,"Title"=>$title,"SubTitle"=>$subTitle,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);

			}		



		} else {

			$ResultArray = array("message"=>"No records found");

		}

		return $ResultArray;

	}

	function getScheduleDetailsByIdWin($categoryId='') {



		global $table_config,$global_config;



		if($categoryId!=''){	



			$where = "And CategoryId= '".$categoryId."'";



		} else {



			$where = '';



		}

		$sql="SELECT * FROM ".$table_config["schedule"]." WHERE IsDeleted='No' ".$where.""; 



		$results=SelectQry($sql);



		if(count($results) > 0) {



			foreach($results as $result) {



				$id 			= $result['Id'];



				$categoryId 	= $result['CategoryId'];



				$contentType 	= $result['ContentType'];



				$title 			= $result['Title'];



				$subTitle 		= $result['SubTitle'];



				$description 	= replace($result['Description']);



				$image 			= SITEGLOBALUPLOADPATH.'schedule/'.$result['Image'];



				$ThumbImage 	= SITEGLOBALUPLOADPATH.'schedule/thumb/'.$result['thumb'];



				$content 		= replace($result['Content']);



				$addedDate 		= $result['AddedDate'];



				$ResultArray[]  = array("Id"=>$id,"CategoryId"=>$categoryId,"ContentType"=>$contentType,"Title"=>$title,"SubTitle"=>$subTitle,"Description"=>$description,"OrginalImage"=>$image,"ThumbImage"=>$ThumbImage,"Content"=>$content,"AddedDate"=>$addedDate);



			}		



		} else {



			$ResultArray = array('null');



		}



		return $ResultArray;



	}

	/*Get Next Event */

	

	function getEventDetails($tbl_name)	{

		global $table_config,$global_config;

		$sql="SELECT * FROM $tbl_name WHERE UNIX_TIMESTAMP(End) > UNIX_TIMESTAMP(NOW()) ORDER BY UNIX_TIMESTAMP(End) ASC LIMIT 1";

		$results=SelectQry($sql);

		if(count($results) > 0) {

			foreach($results as $result) {

				$id 			= $result['Id'];

				$title 	        = $result['Title'];

				$start 	        = $result['Start'];

				$end 			= $result['End'];

				$ResultArray  = array("Id"=>$id,"Title"=>$title,"Start"=>$start,"End"=>$end);

			}		

		} 



		return $ResultArray;

	}

	

	function check_event($start,$tomo,$title)

	{

		global $table_config,$global_config;

		$diff 		  = abs(strtotime($start) - strtotime($tomo));

		$years   	  = floor($diff / (365*60*60*24)); 

		$months  	  = floor(($diff - $years * 365*60*60*24) / (30*60*60*24)); 

		$days    	  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

		$hours   	  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60)); 

		$minuts  	  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 

		$seconds 	  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60));	

		$startDate    = $start;

		$ResultArray = array("Title"=>$title,"startDate"=>$start,"Date"=>$tomo,"Years"=>$years,"Months"=>$months,"Days"=>$days,"Hours"=>$hours,"Minitues"=>$minuts,"Seconds"=>$seconds);

		return $ResultArray;

	}

?>
<?php
    // API access key from Google API's Console

    include("includes/common.php");
 	$page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 	include(SITEADMINTEMPLATEPATH."header.php");
 	include(SITEADMININCLUDEPATH."subscription-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
    
    define( 'API_ACCESS_KEY', 'AAAAoT39ToA:APA91bHsf4TnR6F6rkgpLijxT-jwo-_HZMoy3Xd8wCxQ4-C8K37vRLHQ8PAO1EtG8eT--M24nxsDKdRGe7GMm-KUBB6dqzuS2J0W_HBy40C8rpLIDsZD6YzhxoJ0Mb-gXwlmdBhpGyoz' );

    $devicetokens = getalldevicetokens();
    $registrationIds = array();
    foreach($devicetokens as $s){
        $registrationIds[] = $s["deviceid"];
    }


    
    // prep the bundle
    $msg = array
    (
        'message' 	=> 'King Pick message',
        'title'		=> 'Kingpick notification',
        'subtitle'	=> 'Kingpick notification',
        'tickerText'	=> 'Kingpick notification. Kingpick notification. Kingpick notification',
        'vibrate'	=> 1,
        'sound'		=> 1,
        'largeIcon'	=> '',
        'smallIcon'	=> ''
    );
    $fields = array
    (
        'registration_ids' 	=> $registrationIds,
        'data'			=> $msg
    );

    
    $headers = array
    (
        'Authorization: key=' . API_ACCESS_KEY,
        'Content-Type: application/json'
    );
    
    $ch = curl_init();
    curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
    $result = curl_exec($ch );
    curl_close( $ch );
    echo $result;
    exit;
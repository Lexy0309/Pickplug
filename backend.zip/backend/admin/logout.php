<?php 
	include("includes/common.php");
	session_destroy();
	Redirect($global_config["SiteGlobalAdminPath"]."index.php");
?>
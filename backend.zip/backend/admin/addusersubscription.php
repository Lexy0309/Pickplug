<?php
 	include("includes/common.php");
 	$page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 	include(SITEADMINTEMPLATEPATH."header.php");
 	include(SITEADMININCLUDEPATH."subscription-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	 
 	checkLogin();
 	global $table_config;
 
	$id = $_REQUEST["id"];
	$user = getUserDetails($id);
	$subscriptions = getsubscriptions();

	if($_POST){

			$sid = $_POST["subscription"];

            $success = 0;
			foreach($subscriptions as $sq){
				if($sq["Id"] == $sid){
				    $productid = $sq["ProductId"];
					/*$sport = $sq["Sport"];
					$productid = $sq["ProductId"];
					if($sq["Duration"] != "n/a"){
							
							$expiredate = date('Y-m-d', strtotime('+'.$sq["Duration"].' day'));
					}else{
							$expiredate = $sq["EndDate"];
					}*/
					
					$arr = array();
                	$arr['PurchasedDate'] 		    = date('Y-m-d');//$_REQUEST['date'];
                	$arr['ProductId'] 				= $productid;
                	$arr['User'] 				    = $id;
                	$arr['Pick'] 				    = 0;//$_REQUEST['pick'];
                	$arr['TransactionID'] 		    = "";
					
					//print_r($arr);
					//die;
					
					if (isTransactionAlreadyExists($id,$productid) == '0'){
                        addsubscription($arr,'' ); 
                        $success = 1;
                    }
        
					break;
				}
			}
			//$addsubscription = addusersubscription($id, $sport, $expiredate);
			//$addtransaction = addusertransaction($id, $productid);
			header("Location:".$global_config["SiteGlobalAdminPath"]."listuser.php?success=".$success);
	}



?>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addSport" method="post" enctype="multipart/form-data">
        <fieldset>
				<legend>Add User Subscription</legend>
				
				<div class="control-group">
          <label class="control-label" for="subscription_Name">User : </label>
          <div class="controls">
							<p style="margin-top:0.5%;"><?php echo $user["FullName"]; ?></p>
          </div>
        </div>
        
        <div class="control-group">
          <label class="control-label" for="subscription_Name">Subscription *</label>
          <div class="controls">
						<select name="subscription" class="form-control" required>
								<option value="">Select subscription</option>
								<?php foreach($subscriptions as $s){ ?>
									<option value="<?php echo $s['Id']; ?>"><?php echo $s["Name"]; ?></option>
								<?php } ?>
						</select>
          </div>
        </div>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listuser.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
	  		$('#subscription_StartDate').datepicker({
                 format: 'yyyy-mm-dd'           
            });
	  		$('#subscription_EndDate').datepicker({
                 format: 'yyyy-mm-dd'           
            });
				
									 
			$("#addSport").validate({
				rules:{
					subscription_Name:"required",
				},
				messages:{
					subscription_Name:"Enter the Subscription Name",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

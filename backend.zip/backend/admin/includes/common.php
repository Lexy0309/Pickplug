<?php if(!isset($_SESSION)){ ob_start();

	session_start();

	}

	error_reporting(E_NOTICE ^ E_ALL);

	set_time_limit(-1);

	ini_set('memory_limit', '1024M');

	if (!defined( "MAIN_INCLUDE_PATH" )) {

		define( "MAIN_INCLUDE_PATH", dirname(__FILE__)."/");

	}

	

	if(!defined('ABSOLUTE_PATH'))

		define("ABSOLUTE_PATH",str_replace("includes/","",MAIN_INCLUDE_PATH));

		

	require_once("config.php");

	define("SITENAME",$global_config["SiteName"]);

	define("MAIN_CLASS_PATH",MAIN_INCLUDE_PATH."Classes/");

	define("SITE_FILE_IMAGE_PATH",$global_config["SiteGlobalPath"]."uploads/");
	
	define("SITEADMININCLUDEPATH",$global_config["SiteLocalAdminPath"].'admin-includes/');

	define("SITEADMINPATH",$global_config["SiteLocalAdminPath"]);

	define("SITEGLOBALADMINPATH",$global_config["SiteGlobalAdminPath"]);

	define("SITETEMPLATEPATH",$global_config["SiteTemplatePath"]);

	define("SITEADMINTEMPLATEPATH",$global_config["SiteAdminTemplatePath"]);

	define("SITEGLOBALPATH",$global_config["SiteGlobalPath"]);

	define("SITELOCALPATH",$global_config["SiteLocalPath"]);

	define("SITEIMAGEPATH",$global_config["SiteGlobalImagePath"]);

	define("SITECSSPATH",$global_config["SiteGlobalCSSPath"]);

	define("SITEGLOBALUPLOADPATH",$global_config["SiteGlobalUploadPath"]);

	define("SITEJSPATH",$global_config["SiteGlobalJSPath"]);

	define("UPLOADLOCALPATH",$global_config["SiteLocalUploadPath"]);

	define("SITEADMINMODULEPATH",$global_config["SiteAdminModulePath"]);

	define("SITEADMINIMAGEPATH",$global_config["SiteAdminImagePath"]);

	require_once(MAIN_INCLUDE_PATH."functions.php");



?>
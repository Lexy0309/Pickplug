<?php
	function printArray($str){
		print "<pre>";
		print_r($str);
		print "</pre>";
	} 
	
	function doprintArray($str) {
		$strTestingIP = '192.168.1.7';
		if($_SERVER['REMOTE_ADDR']==$strTestingIP) {
			print "<pre>";
			print_r($str);
			print "</pre>";
		}
			
	}
	function Redirect($strURL)	{
		header("location:".$strURL);
		exit();
	}
?>
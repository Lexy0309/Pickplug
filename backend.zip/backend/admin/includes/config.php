<?php 

	
	$global_config = array();
	
	/*$FolderPath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/.\\') . '/';*/
	
	$FolderPath = "/app/admin/";

	$global_config["SiteGlobalPath"] 				= "http://".$_SERVER['HTTP_HOST'].$FolderPath;

	$global_config["SiteLocalPath"] 				= $_SERVER['DOCUMENT_ROOT'].$FolderPath;

	$global_config["SiteGlobalAdminPath"] 			= $global_config["SiteGlobalPath"]."";

	$global_config["SiteGlobalCKEditorPath"]    	= $global_config["SiteGlobalPath"]."ckeditor";

	$global_config["SiteGlobalUploadPath"] 			= $global_config["SiteGlobalPath"]."uploads/"; 

	$global_config["SiteLocalAdminPath"] 			= $global_config["SiteLocalPath"].'';

	$global_config["SiteAdminIncludePath"]			= $global_config["SiteLocalAdminPath"].'admin-includes/';

	$global_config["SiteAdminImagePath"]			= $global_config["SiteGlobalAdminPath"].'images/';

	$global_config["SiteAdminTemplatePath"]			= $global_config["SiteLocalAdminPath"].'templates/';

	$global_config["SiteTemplatePath"]				= $global_config["SiteLocalPath"].'templates/';

	$global_config["SiteLocalUploadPath"] 			= $global_config["SiteLocalPath"].'uploads/';

	$global_config["DBHost"]					    = "localhost";

	$global_config["DBUserName"]  					= "propicks_giazza";

	$global_config["DBPassword"]					= "GiazzaApp852";

	$global_config["DBDatabaseName"]				= "propicks_giazzaapp";

	$global_config["DBTablePrefix"]					= "tbl_";

	$global_config["SiteName"]					    = 'Giazza App';

	$global_config["SiteTitle"]					    = 'Giazza App';

	$global_config["PageLimit"]					    = 20;	

	$global_config["CSSFiles"]					    = array();

	$global_config["JSFiles"]					    = array();



	$imgWidth  = 40;

	$imgHeight = 40;



	$imgWidthThumb = 40;

	$imgHeightThumb = 40;

	

	$userImageResizeW = 150;

	$userImageResizeH = 150;

	/*Sport Management Image Upload Width & Height*/

	

	$SportimgWidth  = 48;

	$SportimgHeight = 48;

	

	/*Team Management Image Upload Width & Height*/

	

	$TeamimgWidth  = 80;

	$TeamimgHeight = 80;

	

	/*Bet Management Image Upload Width & Height*/

	

	$BetimgWidth  = 308;

	$BetimgHeight = 82;

	

	/* Country for Bet Management*/

	$countrylist=array('1'=>'CANADA','2'=>'USA','3'=>'UK & OTHER');
	
	$global_config["adminrole"]				  = array('1'=>'Administrator','2'=>'Editor');
	
	
?>
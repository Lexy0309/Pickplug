<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."subscription-functions.php");
 include(SITEADMININCLUDEPATH."api-functions.php");
 checkLogin();
	
	if(isset($_REQUEST['trid']) && $_REQUEST['trid']) {
			$trid = $_REQUEST["trid"];
			$user = $_REQUEST["user"];
			$sid = $_REQUEST["sid"];
			deletesubscription($trid, $user, $sid);
			header("Location:".$global_config["SiteGlobalAdminPath"]."usersubscriptions.php?success=1");
	}

	if(isset($_REQUEST["success"]) && $_REQUEST["success"]){
		$strMessage = "User subscription Cancelled successfully";
		$strMessageClass = 'success';
	}
	
	
	$targetpage=basename($_SERVER['SCRIPT_FILENAME']);
	$where=" 1=1 and ProductId  Like 'com.pickplug%'"; //" Status='Active' AND IsDeleted='No'";
	
	
	$total_pages=GetTotalRecordsCount($table_config["transactions"],$where);
	 
	$searchArray["pagename"]    = basename($_SERVER['SCRIPT_FILENAME']);
 	$searchArray["tablename"]   = $table_config["sport"];
 	$searchArray["searchfield"] = "SportName";
	$searchArray["where"]		= $where;
	
	include($global_config["SiteAdminIncludePath"]."page-calculation.php");

	$arrFieldSet = '*';	
	$orderBy = " ORDER BY PurchasedDate DESC ";
	$arrUsers  = GetAllRecordsValues($table_config["transactions"],$arrFieldSet,$start,$limit,$where,$orderBy);
	include(SITEADMININCLUDEPATH."pagination.php");
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
   
    <div class="span">
	
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
	  
      
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>User</th>
						<th>Subscription</th>
						<th>Purchased date</th>
						<th>Expiry date</th>
            <!--<th>Cancel</th>-->
          </tr>
        </thead>
        <?php if($arrUsers) {
		$i=1;
		foreach($arrUsers as $arrUser) {
					
					$userdetails = getUserDetails($arrUser["User"]);
					$subscription = getsubscriptiondetails($arrUser["ProductId"]);
					
		?>
		<?php
		 if ($userdetails['Email']!=''){
		?>
		   <tbody>
          <tr>
            <td width="20%"><?php echo $userdetails['Email']; ?></td>
						<td width="10%"><?php echo $subscription['Name'];?></td>
						<td width="10%"><?php echo $arrUser['PurchasedDate'];?></td>
						<td width="10%"><?php echo getSubscriptionExpiryDate($subscription['Id'],$userdetails['Id']);?></td>
      <!--      <td align="center" style="text-align:center;" width="10%">-->
						<!--	<button onclick="cancelsubscription(<?php echo $arrUser['Id']; ?>, <?php echo $arrUser['User']; ?>, <?php echo $subscription['Sport']; ?>)" class="btn btn-danger btn-xs">Cancel Subscription</button>-->
						<!--</td>-->
          </tr>
        </tbody>
        
		<?php
		    $i++;
		 }
		?>
		
        
        <?php  } } else { ?>
        <tr>
          <td colspan="6" align="center"><p style="color:red; text-align:center;">No records found</p></td>
        </tr>
        <?php } ?>
      </table>
      <?php if($total_pages>$global_config["PageLimit"]){?>
      <?php print $pagination;?>
      <?php } ?>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>
<script>
	function cancelsubscription(trid, user, sid)
	{
		if(confirm("Are you sure want to cancel subscription?")){
			window.location.href = "<?php echo $global_config["SiteGlobalAdminPath"];?>usersubscriptions.php?trid="+trid+"&user="+user+"&sid="+sid;
		}
	}
</script>




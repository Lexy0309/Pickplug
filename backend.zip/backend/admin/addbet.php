<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."bet-functions.php");
 checkLogin();
 global $table_config;
 
if(isset($_POST['Submit']))
{
	if($_FILES)
	{
		@$strImageProperties = getimagesize($_FILES["file_File"]["tmp_name"]);
		if($strImageProperties[0]>=$BetimgWidth && $strImageProperties[1]>=$BetimgHeight)  {
		$strBannerCount = CheckDataExists($table_config["bet"],'BetName',$_POST['bet_BetName']);
			if($strBannerCount==0)	{
				$ary['bet_Country']     = $_POST['bet_Country'];
				$ary['bet_BetName']     = $_POST['bet_BetName'];
				$ary['bet_BetWebsite']  = $_POST['bet_BetWebsite'];
				$ary['bet_Description'] = $_POST['bet_Description'];
				$ary['bet_Position']	= getBetPosition() + 1;
				//$ary['bet_ModifiedDate'] = date('Y-m-d H:i:s');
				$BannerId	= insertSportsDetails($ary,"bet_",$table_config["bet"],$_FILES);	
				if(!empty($BannerId)){
					$strMessage="Bet Detail added successfully";
					$strMessageClass="success";
					unset($_POST);
				}	
			} else {
				$strMessage="Bet Name already exists";
				$strMessageClass="error";
			}
		} 
		else
		{
			$strMessage="Uploaded image greater than ".$BetimgWidth." X ".$BetimgHeight." pixels";
			$strMessageClass="error";
		} 

	}
}
?>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addBet" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Add Bet</legend>
        

		 <div class="control-group">
          <label class="control-label" for="bet_Country">Country*</label>
          <div class="controls">
		  <select name="bet_Country" id="bet_Country">
				<option selected="selected" value=""> -- Country -- </option>
				<?php foreach($countrylist as $key=>$country){ 	?>
					<option value="<?php echo $key; ?>" <?php if($_POST['bet_Country']==$key) { echo "selected";} else { echo ""; } ?> ><?php echo $country; ?></option>
				<?php } ?>	
			</select>
          </div>
        </div>
		
		<div class="control-group">
          <label class="control-label" for="bet_BetName">Bet Name*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="bet_BetName" name="bet_BetName"  rel="popover" value="<?php echo $_POST['bet_BetName'];?>" />
          </div>
        </div>
		
		<div class="control-group">
        	<label class="control-label" for="bet_BetLogo">Bet Logo</label>
			<div class="controls">
				<input type="file" id="file_File" name="file_File"  size="74">
				<span class="help-block">Uploaded image greater than <?php echo $BetimgWidth; ?> X <?php echo $BetimgHeight; ?> pixels</span> 
			</div>
        </div>
		
		<div class="control-group">
          <label class="control-label" for="bet_BetWebsite">Bet Website*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="bet_BetWebsite" name="bet_BetWebsite"  rel="popover" value="<?php echo $_POST['bet_BetWebsite'];?>" />
          </div>
        </div>
		
		<div class="control-group">
			<label class="control-label" for="bet_Description">Description</label>
			<div class="controls">
				<textarea name="bet_Description" id="bet_Description" style="width:530px !important; height:150px !important;"><?php echo $_POST['bet_Description'];?></textarea>
			</div>
		</div>
        
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listbets.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/wysihtml5-0.3.0.js"></script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-wysihtml5.js"></script>
<script>
	$('#bet_Description').wysihtml5();
</script>
<script type="text/javascript">
	  $(document).ready(function(){
					 
			$("#addBet").validate({
				rules:{
					bet_Country:"required",
					bet_BetName:"required",
					bet_BetWebsite:"required"
				},
				messages:{
					bet_Country:"Choose Country",
					bet_BetName:"Enter Bet Name",
					bet_BetWebsite:"Enter Website"
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
</script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

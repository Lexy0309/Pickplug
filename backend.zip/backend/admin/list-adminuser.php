<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 checkLogin();
	if($_REQUEST['op']=='delete' && !empty($_REQUEST['id'])) {
		$deleteid = doDeleteRecord($_REQUEST['id'],$table_config["admin"]);
		if($deleteid) {
			$strMessage="Select Record Deleted Successfully";
			$strMessageClass="success";
		}
	}

	if(!empty($_REQUEST['SearchByFullName'])){
		$strId = $_REQUEST['SearchByFullName'];
	} 
	
	$targetpage=basename($_SERVER['SCRIPT_FILENAME']);
	$where=" Username LIKE '".$strId."%'";
	if(isset($_GET['key'])){
		$where.=" AND Title like '%".trim($_GET['key'])."%'";
		$targetpage.="?key=".trim($_GET['key'])."";
	} else {
		$targetpage.="?";
	}
	
	$total_pages=GetTotalRecordsCount($table_config["admin"],$where);
	 
	$searchArray["pagename"]    = basename($_SERVER['SCRIPT_FILENAME']);
 	$searchArray["tablename"]   = $table_config["admin"];
 	$searchArray["searchfield"] = "Username";
	$searchArray["where"]		= $where;
	
	include($global_config["SiteAdminIncludePath"]."page-calculation.php");

	$arrFieldSet = '*';	
	$orderBy = " ORDER BY Id DESC ";
	$arrUsers  = GetAllRecordsValues($table_config["admin"],$arrFieldSet,$start,$limit,$where,$orderBy);
	include(SITEADMININCLUDEPATH."pagination.php");
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
    <a href="<?php echo SITEGLOBALADMINPATH;?>add-adminuser.php">
	  		<button type="button" class="btn">Add Admin User</button>
	  	</a>
       
	   <div style="float:right;">
		  <div class="search_frame">
		  <form name="searchByName" id="searchByName" method="post" action="list-adminuser.php">
		  	 <input type="text" name="SearchByFullName" id="SearchByFullName" value=""  placeholder="Search By Name"/>
		  </div>
		  <div class="add">
		 	 <button type="button" class="btn" onClick="javascript:document.searchByName.submit()">Search User</button>
		  </div>
		  </form>
	  </div>
	  
	   <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
	  
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Username</th>
			<th>Email</th>
			<th>Role</th>
            <th style="text-align:center;">Action</th>
          </tr>
        </thead>
        <?php if($arrUsers) {
		$i=1;
		$arrayrole = $global_config["adminrole"];
		foreach($arrUsers as $arrUser) {
		$role = $arrUser['Role'];
		?>
        <tbody>
          <tr>
            <td width="20%"><?php echo $arrUser['Username'];?></td>
			<td width="25%"><?php echo $arrUser['Email'];?></td>
			<td width="10%"><?php echo $arrayrole[$role]?></td>          
            
            <td align="center" style="text-align:center;" width="10%">
				<a href="<?php echo SITEGLOBALADMINPATH.'edit-adminuser.php?id='.base64_encode($arrUser['Id']); ?>" ><img src="images/edit.gif" alt="edit" title="edit"/></a>&nbsp;&nbsp;
				<a href="<?php echo SITEGLOBALADMINPATH.'list-adminuser.php?op=delete&id='.$arrUser['Id'];?>" onClick="return confirm('Are you sure want to delete?');"><img src="images/delete.gif" alt="delete" title="delete" /></a><br />
			</td>
          </tr>
        </tbody>
        <?php $i++; } } else { ?>
        <tr>
          <td colspan="6" align="center"><p style="color:red; text-align:center;">No records found</p></td>
        </tr>
        <?php } ?>
      </table>
	  
      <?php if($total_pages>$global_config["PageLimit"]){?>
      <?php print $pagination;?>
      <?php } ?>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>



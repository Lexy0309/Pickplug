<?php
 	include("includes/common.php");
 	$page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 	include(SITEADMINTEMPLATEPATH."header.php");
 	include(SITEADMININCLUDEPATH."subscription-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	 
 	checkLogin();
 	global $table_config;

    if($_POST){
        $interval = $_POST["hour"].":".$_POST["min"];
        $price = $_POST["packageprice"];
        $update = updatetimeinterval($interval, $price);
        $strMessage="Time Interval has been updated";
		$strMessageClass="success";
    }

    $interval = gettimeinterval();
    $packageprice = checkfortheofferprice();
    $ti = explode(":", $interval["time_interval"]);
 

?>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addSport" method="post" enctype="multipart/form-data">
        <fieldset>
			<legend>Add Time Interval</legend>
				
            <div class="control-group">
                <label class="control-label" for="subscription_Name">Time Interval : </label>
                <div class="controls">
                    <input type="number" placeholder="Enter hour" required class="form-control" name="hour" value="<?php echo $ti[0]; ?>" />
                    Hours :
                    <input type="number" placeholder="Enter Minutes" required class="form-control" name="min" value="<?php echo $ti[1]; ?>" />
                    Minutes
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="subscription_Name">Offer Price : </label>
                <div class="controls">
                    <input type="number" placeholder="Enter Offer price" required class="form-control" name="packageprice" value="<?php echo $packageprice; ?>" />
                </div>
            </div>
    
            <div class="form-actions">
                <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
                <a class="btn" href="<?php echo SITEGLOBALPATH;?>listsport.php">Cancel</a>
            </div>

        </fieldset>
      </form>
    </div>
  </div>
</div>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

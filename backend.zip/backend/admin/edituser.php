<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."user-functions.php");
 checkLogin();
 global $table_config;
 $UserId = base64_decode($_REQUEST['id']);// Get Userid from URL
 
	if(isset($_POST['Submit'])){
		if(!empty($_FILES['user_Photo']['name'])) {
				
				$strGalleryCount = CheckDataExists($table_config["user"], 'Email', $_POST['user_Email'],$Field='Id',$UserId);
				if($strGalleryCount==0){
					$ary['user_Email']           = $_POST['user_Email'];
					$ary['user_FullName']        = $_POST['user_FullName'];
					$ary['user_PhoneNumber'] 	 = $_POST['user_PhoneNumber'];
					$ary['user_Birthday'] 		 = $_POST['user_Birthday'];
					$ary['user_Gender'] 		 = $_POST['user_Gender'];
								
					$strUserId	= updateGalleryDetails($ary,"user_",$table_config["user"],$UserId,$_FILES);	
					
					if(!empty($strUserId)){
						$strMessage="User details updated successfully";
						$strMessageClass="success";
						unset($_POST);
					}	
				} else {
				   $strMessage="User Email already exists";
				   $strMessageClass="error";
				}
			
		}else {
			$strGalleryCount = CheckDataExists($table_config["user"], 'Email', $_POST['user_Email'],$Field='Id',$UserId);
			if($strGalleryCount==0){
				    $ary['user_Email']           = $_POST['user_Email'];
					$ary['user_FullName']        = $_POST['user_FullName'];
					$ary['user_PhoneNumber'] 	 = $_POST['user_PhoneNumber'];
					$ary['user_Birthday'] 		 = $_POST['user_Birthday'];
					$ary['user_Gender'] 		 = $_POST['user_Gender'];
							
				$strUserId	= updateGalleryDetails($ary,"user_",$table_config["user"],$UserId,$_FILES);	
				
				if(!empty($strUserId)){
					$strMessage="User details updated successfully";
					$strMessageClass="success";
					unset($_POST);
				}	
			} else {
			   $strMessage="User Email already exists";
			   $strMessageClass="error";
			}
		}
	} 
	
	$arrUser = GetRecordsValuesById($table_config["user"],$UserId);
	
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="editHere" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Edit User</legend>
        
        <div class="control-group">
          <label class="control-label" for="user_Email">Email*</label>
          <div class="controls">
		  	  <input type="text"  class="input-xxlarge" id="user_Email" name="user_Email"  rel="popover" value="<?php echo $arrUser['Email'];?>" />
          </div>
        </div>
		        
		<div class="control-group">
          <label class="control-label" for="user_FullName">FullName*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="user_FullName" name="user_FullName"  rel="popover" value="<?php echo $arrUser['FullName'];?>" />
          </div>
        </div>
		<div class="control-group">
          <label class="control-label" for="user_PhoneNumber">Phone Number</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="user_PhoneNumber" name="user_PhoneNumber"  rel="popover" value="<?php echo $arrUser['PhoneNumber'];?>" />
			<span id="errmsg" style="color:#FF0000"></span>
          </div>
        </div>
		<div class="control-group">
          <label class="control-label" for="user_Birthday">Birthday</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="user_Birthday" name="user_Birthday"  rel="popover" value="<?php echo $arrUser['Birthday'];?>" />
          </div>
        </div>
		
		<div class="control-group">
			<label class="control-label" for="user_Gender">Gender</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="user_Gender" id="user_Gender"  value="Male" <?php if($arrUser['Gender']=="Male") { ?>checked="checked" <?php } ?>  /> Male
				</label>
				<label class="radio">
					<input type="radio" name="user_Gender" id="user_Gender" value="Female" <?php if($arrUser['Gender']=="Female") { ?>checked="checked" <?php } ?> /> Female
				</label>
			</div>
        </div>       
       
		
		
		<div class="control-group">
			<label class="control-label" for="user_Photo">Photo</label>
			<div class="controls">
				<input type="file" id="user_Photo" name="user_Photo"  size="74">
				 <span class="help-block"></span> 
				<?php if($arrUser['Photo']!="" && file_exists(UPLOADLOCALPATH."userImage/".$arrUser['Photo'])) { ?>
				&nbsp;			
				<a data-toggle="lightbox" href="#demoLightbox" style="margin:10px 0 0;float:left;">
				<img src="<?php echo SITEGLOBALUPLOADPATH;?>userImage/<?php  echo $arrUser['Photo'];?>" width="65" height="65" alt="" />
				</a>	
				
				<div id="demoLightbox" class="lightbox hide fade"  tabindex="-1" role="dialog" aria-hidden="true">
					<div class='lightbox-header'>
						<button type="button" class="close" data-dismiss="lightbox" aria-hidden="true">&times;</button>
					</div>
					<div class='lightbox-content'>
						<img src="<?php echo SITEGLOBALUPLOADPATH;?>userImage/<?php  echo $arrUser['Photo'];?>" width="" height="" alt=""/>
					</div>
				</div>	
				<?php } ?>	
			</div>
		</div>
		
        
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listuser.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
	  		$('#user_Birthday').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$("#editHere").validate({
				rules:{
					user_Email:{
						email: true,
						required:true
					},
					user_FullName:{
						minlength: 2,
						required:true,
					}
				},
				messages:{
					user_Email:"Enter Email",
					user_FullName:"Enter Full Name"
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
			//called when key is pressed in textbox
			$("#user_PhoneNumber").keypress(function (e) {
				//if the letter is not digit then display error and don't type anything
				if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				//display error message
					$("#errmsg").html("Digits Only").show().fadeOut("slow");
					return false;
				}
			});
		});
	  </script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-lightbox.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include('push/pushFunctions.php');
 
 checkLogin();
 global $table_config;
 	if(isset($_POST['submit'])) {
		$strAllusers	=	 doGetAllUserDeviceDetails();
		
		
		$message		  =	$_POST['message'];
		$title = $_POST["title"];
		
		if(isset($_POST['submit'])) {
		$strAllusers	=	 doGetAllUserDeviceDetails();
		$message		  =	$_POST['message'];
		$title = $_POST["title"];
		if(count($strAllusers)>=1){
			$sendnotification   = doSendNotificationMessage($strAllusers,$message);
			doSendAndroidNotification($message);
			sendandroidpushnotifications($title, $message);
			//sendiospushnotifications($title, $message);
			$strMessageClass    ="success";
			$msg				="Notifications send successfully";
			
			/*foreach($strAllusers as $result) { 
					$strDeviceToken		= $result['devicetoken']; 
					$strDeviceType		= $result['type']; 
					$sendnotification   = doSendNotificationMessageNew($strDeviceToken,$strDeviceType,$message);
					$strMessageClass    ="success";
					$msg				="Notifications send successfully";
					
				}*/
		}
	}
	}
?>
<script type="text/javascript">
	function chk_form()
	{	
		if(document.getElementById('message').value == '')
		{
			alert('Please Enter the Push Message');
			return false;
		}
	 return true;
	}
	
</script>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">

<?php
 if(!empty($msg)) { ?> 
<div class="alert alert-<?php echo $strMessageClass;?>">  
  <a class="close" data-dismiss="alert">x</a>  
  <?php echo $msg;?>
</div>  
<?php } ?>
      <form action=" " method="POST" id="form" name="form" class="form-horizontal well">
        <fieldset>
        <legend>Push Notification</legend>
        
		
				<div class="control-group">
          <label class="control-label" for="fightImage">Title</label>
          <div class="controls">
            <input type="text" class="form-control" style="width:60%;" name="title" required />
          </div>
        </div>
        
        <div class="control-group">
          <label class="control-label" for="fightImage">Message</label>
          <div class="controls">
            <textarea rows="3" class="input-xxlarge" name="message" id="message"  rel="popover" required ></textarea>
          </div>
        </div>
        
        <div class="form-actions">
          <input class="btn btn-primary" type="submit" name="submit" id="submit" value="Submit" onClick="return chk_form();" /></td>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>



<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

<?php
	 include("includes/common.php");
	 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
	 include(SITEADMINTEMPLATEPATH."header.php");
	 include(SITEADMININCLUDEPATH."picks-functions.php");
	 checkLogin();
	 $PicksId = base64_decode($_REQUEST['id']);
	 $arrPickstDetails = GetAllDetailsById($table_config["picks"],$PicksId);
	 if(isset($_POST['Submit'])) {
	  if($_POST['pick_VisitingTeam']==$_POST['pick_HomeTeam']) {
 		 	$strMessage="Visiting Team & Home Team cannot be Same";
	 		$strMessageClass="error";
 		} else {
		 $ary['pick_SportName']     = $_POST['pick_SportName'];
		 $ary['pick_VisitingTeam']  = $_POST['pick_VisitingTeam'];
		 $ary['pick_HomeTeam']      = $_POST['pick_HomeTeam'];
		 //$ary['pick_PickDate']      = $_POST['pick_PickDate'];
		  $ary['pick_PickDate']      =  date('Y-m-d H:i:s',strtotime($_POST['pick_PickDate'].' '.$_POST['pickHour'].':'.$_POST['pickMinute'].':'.$_POST['pickSecond']));
		 $ary['pick_PickTitle']     = $_POST['pick_PickTitle'];
		 $ary['pick_PickAnalysis']  = $_POST['pick_PickAnalysis'];
		 $ary['pick_PickStatus']    = $_POST['pick_PickStatus'];
		 $ary['pick_PickRecord']    = $_POST['pick_PickRecord'];
		 $ary['pick_FreePick']       = $_POST['pick_FreePick'];

		 $ary['pick_NflPick']       = $_POST['pick_NflPick'];
		 $ary['pick_WeekDate']       = date('Y-m-d H:i:s',strtotime($_POST['pick_WeekDate'].' '.$_POST['pickweekHour'].':'.$_POST['pickweekMinute'].':'.$_POST['pickweekSecond']));
		 $ary['pick_ModifiedDate'] 	= date('Y-m-d H:i:s');
			$id = updateDetails($ary,'pick_',$table_config["picks"],$PicksId);
			//$sql = "UPDATE tbl_pick set ModifiedDate ='".$ary['pick_ModifiedDate']."' where SportName='".$ary['pick_SportName']."' AND IsDeleted='No'";
			$sql = "UPDATE tbl_pick set ModifiedDate ='".$ary['pick_ModifiedDate']."' where IsDeleted='No'";
			mysql_query($sql);
			if($id) {

				$sqry = 'SELECT RecordNo FROM tbl_sport WHERE Id="'.$arrPickstDetails["SportName"].'"';
		 		$res = SelectQry($sqry);
		 		$recordno = $res[0]["RecordNo"];
				$expl = explode(":", $recordno);
				$record = rtrim(ltrim($expl[1], " "), " ");
				$wlstat = explode("-", $record);
				
				if($ary['pick_PickStatus'] == "Win"){
						$win = $wlstat[0]+1;
						if($arrPickstDetails["PickStatus"] == "Lose"){
							$lose = $wlstat[1]-1;
						}else{
							$lose = $wlstat[1];
						}
					  
				}else if($ary['pick_PickStatus'] == "Lose"){
						if($arrPickstDetails["PickStatus"] == "Win"){
							$win = $wlstat[0]-1;
						}else{
							$win = $wlstat[0];
						}
						$lose = $wlstat[1]+1;
				}else{
						if($arrPickstDetails["PickStatus"] == "Win"){
							$win = $wlstat[0]-1;
							$lose = $wlstat[1];
						}else if($arrPickstDetails["PickStatus"] == "Lose"){
							$win = $wlstat[0];
							$lose = $wlstat[1]-1;
						}
				}

				$recordno = $expl[0].": ".$win."-".$lose;

				$upqry = 'UPDATE tbl_sport SET RecordNo="'.$recordno.'" WHERE Id="'.$arrPickstDetails["SportName"].'"';
				mysql_query($upqry);

				$strMessage = "Picks Updated successfully";
				$strMessageClass = 'success';
			}

			


		}
	 	
	 }
	 	 $arrPickstDetails = GetAllDetailsById($table_config["picks"],$PicksId);
	 	 $sportname=getAllDetails($table_config['sport']);//Get Sport Name for Drop Down List
     $teamname=getAllDetails($table_config['team']);// Get Team Name for Drop Down List
?>
<script language="javascript">
	function showPickDate(sportid) {
		if(sportid==1) {
			document.getElementById('defaultpick').style.display = 'none';
			document.getElementById('nflpick').style.display = 'block';
			document.getElementById('nflweekpick').style.display = 'block';
		} else {
			document.getElementById('defaultpick').style.display = 'block';
			document.getElementById('nflpick').style.display = 'none';
			document.getElementById('nflweekpick').style.display = 'none';
		}
	}
</script>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addPick" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Edit Pick</legend>
         <div class="control-group">
            <label class="control-label" for="pick_FreePick">Free Pick</label>

 
          <div class="controls">
 			
				<label class="radio">
					<input type="radio" name="pick_FreePick" id="pick_FreePick_Yes"  value="1" <?php if($arrPickstDetails['FreePick']=="1") { ?>checked="checked" <?php } ?> /> Yes
				</label>
				<label class="radio">
					<input type="radio" name="pick_FreePick" id="pick_FreePick_No" value="0" <?php if($arrPickstDetails['FreePick']=="0") { ?>checked="checked" <?php } ?>/> No
				</label>

          </div>
        </div>
        <div class="control-group">
          <label class="control-label" for="pick_SportName">Sport Name*</label>
          <div class="controls">
		  <select name="pick_SportName" id="pick_SportName" onchange="showPickDate(this.value);">
				<option selected="selected" value=""> -- Sport Name -- </option>
				<?php foreach($sportname as $sport){
					if($sport['Id']==$arrPickstDetails['SportName']) { $sel="selected"; } else { $sel="";}
				 ?>
					<option value="<?php echo $sport['Id']; ?>" <?php echo $sel; ?> ><?php echo $sport['SportName']; ?></option>
				<?php } ?>	
			</select>
          </div>
        </div>
		
		 <div class="control-group">
          <label class="control-label" for="pick_VisitingTeam">Visiting Team*</label>
          <div class="controls">
		  <select name="pick_VisitingTeam" id="pick_VisitingTeam">
				<option selected="selected" value=""> -- Visiting Team -- </option>
				<?php foreach($teamname as $team){
					if($team['Id']==$arrPickstDetails['VisitingTeam']) { $sel="selected"; } else { $sel="";}
				?>
					<option value="<?php echo $team['Id']; ?>" <?php echo $sel; ?>><?php echo $team['TeamName']; ?></option>
				<?php } ?>	
			</select>
          </div>
        </div>
		
		 <div class="control-group">
          <label class="control-label" for="pick_HomeTeam">Home Team*</label>
          <div class="controls">
		  <select name="pick_HomeTeam" id="pick_HomeTeam">
				<option selected="selected" value=""> -- Home Team -- </option>
				<?php foreach($teamname as $team){
					if($team['Id']==$arrPickstDetails['HomeTeam']) { $sel="selected"; } else { $sel="";}
				?>
					<option value="<?php echo $team['Id']; ?>" <?php echo $sel; ?>><?php echo $team['TeamName']; ?></option>
				<?php } ?>
			</select>
          </div>
        </div>
		
		<div class="control-group" id="defaultpick" <?php if($arrPickstDetails['SportName']==1) { ?>style="display:none"<?php } else { ?> style="display:block"<?php } ?>>
          <label class="control-label" for="pick_PickDate">Pick Date*</label>
          <div class="controls">
            <input type="text"  class="input-large" id="pick_PickDate" name="pick_PickDate"  rel="popover" value="<?php echo date('Y-m-d',strtotime($arrPickstDetails['PickDate']));?>" />
            <select name="pickHour" id="pickHour" class="time_selectbox">
						<option value="00">Hour</option>
							<?php for($i=1;$i<=24;$i++){ ?>
								
								<option value="<?php echo $i; ?>" <?php if(date('H',strtotime($arrPickstDetails['PickDate']))==$i){?> selected="selected" <?php }?>><?php echo $i; ?></option>
							<?php } ?>
						</select>
						<select name="pickMinute" id="pickMinute" class="time_selectbox">
						<option value="00">Minute</option>
							<?php for($i=1;$i<=60;$i++){ ?>
								<option value="<?php echo $i; ?>" <?php if(date('i',strtotime($arrPickstDetails['PickDate']))==$i){?> selected="selected" <?php }?>><?php echo $i; ?></option>
							<?php } ?>
						</select>
						<select name="pickSecond" id="pickSecond" class="time_selectbox">
						<option value="00">Seconds</option>
							<?php for($i=1;$i<=60;$i++){ ?>
								<option value="<?php echo $i; ?>"  <?php if(date('s',strtotime($arrPickstDetails['PickDate']))==$i){?> selected="selected" <?php }?>><?php echo $i; ?></option>
							<?php } ?>
						</select>
          </div>
        </div>
		<div class="control-group" id="nflpick" <?php if($arrPickstDetails['SportName']==1) { ?>style="display:block"<?php } else { ?> style="display:none"<?php } ?>>
          <label class="control-label" for="pick_PickDate">Pick Date*</label>
          <div class="controls">
				<select name="pick_NflPick" id="pick_NflPick" style="width:310px;">
					<?php for($m=1;$m<=22;$m++) { 
					$strweekdetails = getWeeksDetails($table_config["week"],$m);
					?>
						<option value="<?php echo $strweekdetails['Id']; ?>" <?php if($arrPickstDetails['NflPick']==$strweekdetails['Id']) { ?> selected="selected" <?php } ?>><?php echo $strweekdetails['name'].' ('.$strweekdetails['startdate'].' to '.$strweekdetails['enddate'].')'; ?></option>
						
					<?php } ?>
				</select>
		  </div>
		</div>
		<div class="control-group" id="nflweekpick" <?php if($arrPickstDetails['SportName']==1) { ?>style="display:block"<?php } else { ?> style="display:none"<?php } ?>>
          <label class="control-label" for="pick_PickDate">Week Date*</label>
          <div class="controls">
            <input type="text"  class="input-large" id="pick_WeekDate" name="pick_WeekDate"  rel="popover" value="<?php echo date('Y-m-d',strtotime($arrPickstDetails['WeekDate']));?>" />
            <select name="pickweekHour" id="pickweekHour" class="time_selectbox">
						<option value="00">Hour</option>
							<?php for($w=1;$w<=24;$w++){ ?>
								
								<option value="<?php echo $w; ?>" <?php if(date('H',strtotime($arrPickstDetails['WeekDate']))==$w){?> selected="selected" <?php }?>><?php echo $w; ?></option>
							<?php } ?>
						</select>
						<select name="pickweekMinute" id="pickweekMinute" class="time_selectbox">
						<option value="00">Minute</option>
							<?php for($w=1;$w<=60;$w++){ ?>
								<option value="<?php echo $w; ?>" <?php if(date('i',strtotime($arrPickstDetails['WeekDate']))==$w){?> selected="selected" <?php }?>><?php echo $w; ?></option>
							<?php } ?>
						</select>
						<select name="pickweekSecond" id="pickweekSecond" class="time_selectbox">
						<option value="00">Seconds</option>
							<?php for($w=1;$w<=60;$w++){ ?>
								<option value="<?php echo $w; ?>"  <?php if(date('s',strtotime($arrPickstDetails['WeekDate']))==$w){?> selected="selected" <?php }?>><?php echo $w; ?></option>
							<?php } ?>
						</select>
		  </div>
		</div>
		
		<div class="control-group">
          <label class="control-label" for="pick_PickTitle">Pick Title*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="pick_PickTitle" name="pick_PickTitle"  rel="popover" value="<?php echo $arrPickstDetails['PickTitle'];?>" />
          </div>
        </div>
		<div class="control-group">
          <label class="control-label" for="pick_PickAnalysis">Pick Analysis*</label>
           <div class="controls">
			<textarea name="pick_PickAnalysis" id="pick_PickAnalysis" style="width:530px !important; height:100px !important;"><?php echo $arrPickstDetails['PickAnalysis']; ?></textarea>
          	<br />
			<span id="charNum"><!--Maximum 500 Character--></span>
		  </div>
        </div>
		<fieldset style="width:850px;border:1px solid #CCCCCC; margin:0 0 0 50px;padding:0 0 0 10px" >
    		<legend style="border:0px solid #CCCCCC; width:110px;font-weight: normal; font-size:16px">Record Screen</legend>
			<div class="control-group">
          <label class="control-label" for="pick_PickStatus">Pick Status*</label>
		  <div class="controls">
				<label class="radio">
					<input type="radio" name="pick_PickStatus" id="pick_Status_Win"  value="Win" <?php if($arrPickstDetails['PickStatus']=="Win") { ?>checked="checked" <?php } ?> /> Win
				</label>
				<label class="radio">
					<input type="radio" name="pick_PickStatus" id="pick_Status_Lose" value="Lose" <?php if($arrPickstDetails['PickStatus']=="Lose") { ?>checked="checked" <?php } ?>/> Lose
				</label>
                
                <label class="radio">
                
					<input type="radio" name="pick_PickStatus" id="pick_Status_Pending" value="Pending" <?php if($arrPickstDetails['PickStatus']=="Pending") { ?>checked="checked" <?php } ?>/> Pending
				</label>
			</div>
        </div>
		<div class="control-group">
          <label class="control-label" for="pick_PickRecord">Pick Record*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="pick_PickRecord" name="pick_PickRecord"  rel="popover" value="<?php echo $arrPickstDetails['PickRecord'];?>" />
          </div>
        </div>
  
 		 </fieldset>
		
		    
		
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listpicks.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>


<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/wysihtml5-0.3.0.js"></script>

<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-wysihtml5.js"></script>

<script>

	$('#pick_PickAnalysis').wysihtml5();

</script>


<script type="text/javascript">
	  $(document).ready(function(){
	  		$('#pick_PickDate').datepicker({
                 format: 'yyyy-mm-dd'          
            });
	  		$('#pick_WeekDate').datepicker({
                 format: 'yyyy-mm-dd'           
            });
					
			$("#addPick").validate({
				rules:{
					pick_SportName:"required",
					pick_VisitingTeam:"required",
					pick_HomeTeam :"required",
					pick_PickDate:"required",
					pick_WeekDate:"required",
					pick_PickTitle:"required",
					pick_PickAnalysis:"required",
					pick_PickStatus:"required",
					pick_PickRecord:"required"
				},
				messages:{
					pick_SportName:"Select the Sport Name",
					pick_VisitingTeam:"Select Visiting Team",
					pick_HomeTeam:"Select Home Team",
					pick_PickDate:"Enter Pick Date",
					pick_WeekDate:"Enter Week Date",
					pick_PickTitle:"Enter Pick Title",
					pick_PickAnalysis:"Enter Pick Analysis",
					pick_PickStatus:"Enter Pick Status",
					pick_PickRecord:"Enter Pick Record"
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

<?php 
	function getSponcerandScheduleValues($type){	
		$sql	= "SELECT count(*) as cnt FROM tbl_content where ContentType = '".$type."'";
		$strResult=SelectQry($sql);
		return $strResult[0]['cnt'];	
	}
?>
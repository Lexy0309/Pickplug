<?php 
	include("../includes/common.php");
	include("../admin-includes/common-functions.php");
	include("admin-ajax-functions.php");
	if($_GET['PageAction']=='getSponcerandSchedule'){
		echo $values = getSponcerandScheduleValues($_GET['type']);
		//printArray($values);
	}

?>

function doDownOrder(catid,galid,pos,order,nextID,nextIDPosition,form){
	document.getElementById('catid').value = catid;
	document.getElementById('galid').value = galid;
	document.getElementById('pos').value = pos;
	document.getElementById('order').value = order;
	document.getElementById('nextID').value = nextID;
	document.getElementById('nextIDPosition').value = nextIDPosition;
	document.listMenuForm.submit();
}
function doUpOrder(catid,galid,pos,order,prevID,prevIDPosition,form){
	document.getElementById('catid').value = catid;
	document.getElementById('galid').value = galid;
	document.getElementById('pos').value = pos;
	document.getElementById('order').value = order;
	document.getElementById('prevID').value = prevID;
	document.getElementById('prevIDPosition').value = prevIDPosition;
	document.listMenuForm.submit();
}

<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."subscription-functions.php");
 checkLogin();
	if($_REQUEST['op']=='delete' && !empty($_REQUEST['id'])) {
		$deleteid = doDeleteRecordByStatus($_REQUEST['id'],$table_config["subscription"]);
		if($deleteid) {
			$strMessage="Select Record Deleted Successfully";
			$strMessageClass="success";
		}
	}
	
	
	$targetpage=basename($_SERVER['SCRIPT_FILENAME']);
	$where=" 1=1"; //" Status='Active' AND IsDeleted='No'";
	if(isset($_GET['key'])){
		$where.=" AND Title like '%".trim($_GET['key'])."%'";
		$targetpage.="?key=".trim($_GET['key'])."";
	} else {
		$targetpage.="?";
	}
	
	$total_pages=GetTotalRecordsCount($table_config["subscription"],$where);
	 
	$searchArray["pagename"]    = basename($_SERVER['SCRIPT_FILENAME']);
 	$searchArray["tablename"]   = $table_config["sport"];
 	$searchArray["searchfield"] = "SportName";
	$searchArray["where"]		= $where;
	
	include($global_config["SiteAdminIncludePath"]."page-calculation.php");

	$arrFieldSet = '*';	
	$orderBy = " ORDER BY Id DESC ";
	$arrUsers  = GetAllRecordsValues($table_config["subscription"],$arrFieldSet,$start,$limit,$where,$orderBy);
	include(SITEADMININCLUDEPATH."pagination.php");
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
   
    <div class="span">
	
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
	  <div class="add">
	  	<a href="<?php echo SITEGLOBALADMINPATH;?>addsubscription.php">
	  		<button type="button" class="btn">Add Subscription</button>
	  	</a>
	  </div>
      
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Name</th>
			<th>product id</th>
            <th style="text-align:center">Enabled</th>
            <th style="text-align:center;">Action</th>
          </tr>
        </thead>
        <?php if($arrUsers) {
		$i=1;
		foreach($arrUsers as $arrUser) {
		?>
        <tbody>
          <tr>
            <td width="20%"><?php echo $arrUser['Name'];?></td>
			<td width="10%"><?php echo $arrUser['ProductId'];?></td>
            <td align="center" width="15%" style="text-align:center"><?php echo $arrUser['Enabled'] ?></td>
            <td align="center" style="text-align:center;" width="10%">
				<a href="<?php echo SITEGLOBALADMINPATH.'addsubscription.php?id='.base64_encode($arrUser['Id']); ?>" ><img src="images/edit.gif" alt="edit" title="edit"/></a>&nbsp;&nbsp;
				<a href="<?php echo SITEGLOBALADMINPATH.'listsport.php?op=delete&id='.$arrUser['Id'];?>" onClick="return confirm('Are you sure want to delete?');"><img src="images/delete.gif" alt="delete" title="delete" /></a><br />
			</td>
          </tr>
        </tbody>
        <?php $i++; } } else { ?>
        <tr>
          <td colspan="6" align="center"><p style="color:red; text-align:center;">No records found</p></td>
        </tr>
        <?php } ?>
      </table>
      <?php if($total_pages>$global_config["PageLimit"]){?>
      <?php print $pagination;?>
      <?php } ?>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>



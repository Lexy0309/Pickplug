<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."sport-functions.php");
 checkLogin();
 global $table_config;

  $sports = listSports($table_config["sport"]);
  $totCount = count($sports);
  if(isset($_POST['Submit'])) {
		for($j=0;$j<$totCount;$j++) {
			$recNo = $_POST['sport_RecordNo'.$j];
			$where=" WHERE Id='".$_POST['sportid'.$j]."'";
			$sql = "UPDATE ".$table_config["sport"]." set RecordNo ='".$recNo."'".$where;
			mysql_query($sql);
			$strUserId =1;
			
		}
			if(!empty($strUserId)) {
				$strMessage="Sport details updated successfully";
				$strMessageClass="success";
				unset($_POST);
			}	
	}
	 $sports = listSports($table_config["sport"]);
     $totCount = count($sports);

?>
<div class="span10 pull-left" style="vertical-align:top">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="week" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>List Records</legend>
        <div class="control-group">
        	<div class="controls">
            	<span class="help-block" style="width:60%;"><b>SportName</b><span style="margin-left:30%;"><b>Record Number</b></span></span> 
            </div>
        </div>
		<?php 
			for($i=0;$i<$totCount;$i++) { 
			  $rcdNo = $sports[$i]['RecordNo'];
		?>
				<div class="control-group">
				  <label class="control-label" for="pick_PickDate"></label>
				  <div class="controls">
				  <input type="hidden" name="sportid<?php echo $i ?>" value="<?php  echo $sports[$i]['Id']?>" />
					<input type="text"  class="input-large" id="sport_SportName<?php echo $i;?>" name="sport_SportName<?php echo $i;?>"  rel="popover" value="<?php echo $sports[$i]['SportName']; ?>"  readonly="readonly"/>
					<input type="text"  class="input-large" id="sport_RecordNo<?php echo $i;?>" name="sport_RecordNo<?php echo $i;?>"  rel="popover" value="<?php echo $rcdNo; ?>" />
				  </div>
				</div>
		<?php  } ?>
			
	
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" onclick="javascript:history.go(-1);">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
	  $(document).ready(function(){
	  		$(".date-picker").datepicker({
                 format: 'yyyy-mm-dd'           
            });
	  		$(".wildcard-append .date-picker").datepicker({
                 format: 'yyyy-mm-dd'           
            });
	  		$('#week1_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
			$(".date-picker").datepicker();
			$(".datepicker-trigger").on("click", function() {
				$(".date-picker1").datepicker("show");
			});
			
			$(".datepicker-trigger2").on("click", function() {
				$(".date-picker2").datepicker("show");
			});
			
			$(".datepicker-trigger3").on("click", function() {
				$(".date-picker3").datepicker("show");
			});
			
			$(".datepicker-trigger4").on("click", function() {
				$(".date-picker4").datepicker("show");
			});
			
			
			$(".datepicker-trigger5").on("click", function() {
				$(".date-picker5").datepicker("show");
			});
			
			$(".datepicker-trigger6").on("click", function() {
				$(".date-picker6").datepicker("show");
			});
			
			$(".datepicker-trigger7").on("click", function() {
				$(".date-picker7").datepicker("show");
			});
			
			$(".datepicker-trigger8").on("click", function() {
				$(".date-picker8").datepicker("show");
			});
			
			$(".datepicker-trigger9").on("click", function() {
				$(".date-picker9").datepicker("show");
			});
			
			$(".datepicker-trigger10").on("click", function() {
				$(".date-picker10").datepicker("show");
			});

	  		$('#wildcard_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#wildcard_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#divisional_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#divisional_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#championship_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#championship_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#probowl_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#probowl_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
	  		$('#superbowl_start_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$('#superbowl_end_date').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			
			$("#week").validate({
				rules:{
					week1_start_date:"required",
					
				},
				messages:{
					week1_start_date:"*",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
		
		function getEndDate()
		{
		startdate = document.getElementById('foo').value;  
		var xmlhttp;
		if (window.XMLHttpRequest)
		  {// code for IE7+, Firefox, Chrome, Opera, Safari
		  xmlhttp=new XMLHttpRequest();
		  }
		else
		  {// code for IE6, IE5
		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		xmlhttp.onreadystatechange=function()
		  {
		  if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
			document.getElementById("week1_end_date").value=xmlhttp.responseText;
			document.getElementById('week').submit();
			}
		  }
		xmlhttp.open("GET","enddate.php?start="+startdate,true); 
		xmlhttp.send(); //return false;
		//document.getElementById('week').submit();
		}
		
		function getEndDates()
		{
		startdate = document.getElementById('foo').value;  
		var xmlhttp;
		if (window.XMLHttpRequest)
		  {// code for IE7+, Firefox, Chrome, Opera, Safari
		  xmlhttp=new XMLHttpRequest();
		  }
		else
		  {// code for IE6, IE5
		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		xmlhttp.onreadystatechange=function()
		  {
		  if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
			document.getElementById("week1_end_date").value=xmlhttp.responseText;
			}
		  }
		xmlhttp.open("GET","enddate.php?start="+startdate,true);
		xmlhttp.send();
		}
		
		function getWeeks(){
			document.getElementById('week').submit();
		}
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

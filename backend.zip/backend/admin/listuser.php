<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."user-functions.php");
 checkLogin();
	if($_REQUEST['op']=='delete' && !empty($_REQUEST['id'])) {
		$deleteid = doDeleteRecord($_REQUEST['id'],$table_config["user"]);
		if($deleteid) {
			$strMessage="Select Record Deleted Successfully";
			$strMessageClass="success";
		}
	}

	if(isset($_REQUEST["success"]) && $_REQUEST["success"]){
		$strMessage="Subscription has been added to the selected user";
		$strMessageClass="success";
	}
	

	if(!empty($_REQUEST['SearchByFullName'])){
		$strId = $_REQUEST['SearchByFullName'];
	} 
	
	$targetpage=basename($_SERVER['SCRIPT_FILENAME']);
	$where=" FullName LIKE '".$strId."%'";
	if(isset($_GET['key'])){
		$where.=" AND Title like '%".trim($_GET['key'])."%'";
		$targetpage.="?key=".trim($_GET['key'])."";
	} else {
		$targetpage.="?";
	}
	
	$total_pages=GetTotalRecordsCount($table_config["user"],$where);
	 
	$searchArray["pagename"]    = basename($_SERVER['SCRIPT_FILENAME']);
 	$searchArray["tablename"]   = $table_config["user"];
 	$searchArray["searchfield"] = "FullName";
	$searchArray["where"]		= $where;
	
	include($global_config["SiteAdminIncludePath"]."page-calculation.php");

	$arrFieldSet = '*';	
	$orderBy = " ORDER BY Id DESC ";
	$arrUsers  = GetAllRecordsValues($table_config["user"],$arrFieldSet,$start,$limit,$where,$orderBy);
	include(SITEADMININCLUDEPATH."pagination.php");
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
	<button onclick="window.location.href='<?php echo SITEGLOBALADMINPATH.'exportcsv.php?tbl='.$table_config["user"].''?>'" class="btn">Export User</button>
    <a href="<?php echo SITEGLOBALADMINPATH;?>adduser.php">
	  		<button type="button" class="btn">Add User</button>
	  	</a>
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>" style="float:left;width:83%;"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
       
	   <div style="float:right;">
		  <div class="search_frame">
		  <form name="searchByName" id="searchByName" method="post" action="listuser.php">
		  	 <input type="text" name="SearchByFullName" id="SearchByFullName" value=""  placeholder="Search By Name"/>
		  </div>
		  <div class="add">
		 	 <button type="button" class="btn" onclick="javascript:document.searchByName.submit()">Search User</button>
		  </div>
		  </form>
	  </div>
	  
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Full Name</th>
						<th>Email</th>
						<th>Photo</th>
						<th>Subscription</th>
            <th style="text-align:center">Added Date</th>
            <th style="text-align:center;">Action</th>
          </tr>
        </thead>
        <?php if($arrUsers) {
		$i=1;
		foreach($arrUsers as $arrUser) {
				
				$subscription = getusersubscription($arrUser["Id"]);
				
				$subscriptionname = "Free";
				if(count($subscription) > 0){
					$subscriptionname = $subscription[0]["Name"];
				}

		?>
        <tbody>
          <tr>
            <td width="20%"><?php echo $arrUser['FullName'];?></td>
						<td width="25%"><?php echo $arrUser['Email'];?></td>
						<td width="10%">
							<?php if($arrUser['Photo']!="" && file_exists(UPLOADLOCALPATH."userImage/".$arrUser['Photo'])) { ?>
							<img src="<?php echo SITEGLOBALUPLOADPATH."userImage/".$arrUser['Photo'];?>" alt="" width="65" height="65"/>
							<?php } ?>	
						</td>
						<td width="10%">
								<?php echo $subscriptionname; ?>
						</td>
            <td align="center" width="15%" style="text-align:center"><?php echo date("M j, Y - h:i a",strtotime($arrUser['AddedDate']));?></td>
            <td align="center" style="text-align:center;" width="10%">
							<a href="<?php echo SITEGLOBALADMINPATH.'edituser.php?id='.base64_encode($arrUser['Id']); ?>" ><img src="images/edit.gif" alt="edit" title="edit"/></a>&nbsp;&nbsp;
							<a href="<?php echo SITEGLOBALADMINPATH.'listuser.php?op=delete&id='.$arrUser['Id'];?>" onClick="return confirm('Are you sure want to delete?');"><img src="images/delete.gif" alt="delete" title="delete" /></a><br />
							<a href="<?php echo SITEGLOBALADMINPATH.'addusersubscription.php?id='.$arrUser['Id'];?>" style="font-size: 11px;margin-top: 7%;padding: 2%;" class="btn btn-primary btn-xs">Add subscription</a><br />
						</td>
          </tr>
        </tbody>
        <?php $i++; } } else { ?>
        <tr>
          <td colspan="6" align="center"><p style="color:red; text-align:center;">No records found</p></td>
        </tr>
        <?php } ?>
      </table>
	  
      <?php if($total_pages>$global_config["PageLimit"]){?>
      <?php print $pagination;?>
      <?php } ?>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>



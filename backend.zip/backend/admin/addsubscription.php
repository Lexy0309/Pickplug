<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."subscription-functions.php");
 checkLogin();
 global $table_config;
 
 	 $SubId = base64_decode($_REQUEST['id']); //base64_decode
 	 
	if(isset($_POST['Submit'])){
	
		
	
		$ary['subscription_Name']  = $_POST['subscription_Name'];
		$ary['subscription_Sport']  = $_POST['subscription_Sport'];
		$ary['subscription_Duration']  = $_POST['subscription_Duration'];
		$ary['subscription_ProductId'] 	= $_POST['subscription_ProductId'];
		$ary['subscription_StartDate'] 	= $_POST['subscription_StartDate'];
		$ary['subscription_EndDate'] 	= $_POST['subscription_EndDate'];
		$ary['subscription_Enabled'] 	= $_POST['subscription_Enabled'];
			
		$strBannerCount = CheckDataExists($table_config["subscription"],'Name',$_POST['subscription_Name']);


		if($strBannerCount==0){


			
			$BannerId	= insertSubscriptionDetails($ary,"subscription_",$table_config["subscription"]);	
			if(!empty($BannerId)){
				$strMessage="Subscription Detail added successfully";
				$strMessageClass="success";
				unset($_POST);
			}	
		} else {
		 
		 $id = updateSubscriptionDetails($ary,'subscription_',$table_config["subscription"],$SubId);
			if($id) {
				$strMessage = "Picks Updated successfully";
				$strMessageClass = 'success';
			}
			
			
		//    $strMessage="Subscription Name already exists";
// 		   $strMessageClass="error";
		} 
			
		
	}

	 if ($SubId)
	 	$arrSubDetails = GetAllDetailsById($table_config["subscription"],$SubId);
	 	
	 $sportname=getAllDetails($table_config['sport']);
	 $sportname[] = array('Id' => -1, 'SportName' => 'All Sports Combo');
?>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addSport" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Add Subscription</legend>
        
        <div class="control-group">
          <label class="control-label" for="subscription_Name">Name*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="subscription_Name" name="subscription_Name"   value="<?php echo $arrSubDetails['Name'];?>" />
          </div>
        </div>
		
		        
        <div class="control-group">
          <label class="control-label" for="subscription_ProductId">Product Id*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="subscription_ProductId" name="subscription_ProductId"  value="<?php echo $arrSubDetails['ProductId'];?>" />
          </div>
        </div>
		
		
         <div class="control-group">
          <label class="control-label" for="subscription_Sport">Sport Name*</label>
          <div class="controls">
		  <select name="subscription_Sport" id="subscription_Sport" onchange="showPickDate(this.value);">
				<option selected="selected" value=""> -- Sport Name -- </option>
			 
					
				 
				<?php foreach($sportname as $sport){ 
				
					if($sport['Id']==$arrSubDetails['Sport']) { $sel="selected"; } else { $sel="";}
				?>
					<option value="<?php echo $sport['Id']; ?>"  <?php echo $sel; ?>><?php echo $sport['SportName']; ?></option>
				<?php } ?>	
			</select>
          </div>
        </div>
        
                
		<div class="control-group">
			<label class="control-label" for="subscription_Duration">Duration</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="subscription_Duration" id="subscription_Duration_365"  value="365" <?php if($arrSubDetails['Duration']=="365") { ?>checked="checked" <?php } ?>   /> 365
				</label>
				<label class="radio">
					<input type="radio" name="subscription_Duration" id="subscription_Duration_30" value="30" <?php if($arrSubDetails['Duration']=="30") { ?>checked="checked" <?php } ?>  /> 30
				</label>
				<label class="radio">
					<input type="radio" name="subscription_Duration" id="subscription_Duration_na" value="n/a" <?php if($arrSubDetails['Duration']=="n/a") { ?>checked="checked" <?php } ?>  /> n/a
				</label>
			</div>
        </div>  
  
        <div class="control-group" id="defaultpick" style="display:block">
          <label class="control-label" for="subscription_StartDate">Start Date</label>
          <div class="controls">
            <input type="text"  class="input-large" id="subscription_StartDate" name="subscription_StartDate"  rel="popover" value="<?php echo $arrSubDetails['StartDate'];?>" />
 
          </div>
        </div>
     
        <div class="control-group" id="defaultpick" style="display:block">
          <label class="control-label" for="subscription_EndDate">End Date</label>
          <div class="controls">
            <input type="text"  class="input-large" id="subscription_EndDate" name="subscription_EndDate" value="<?php echo $arrSubDetails['EndDate'];?>" />
 
          </div>
        </div>
        
 
        
		<div class="control-group">
			<label class="control-label" for="subscription_Enabled">Enabled</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="subscription_Enabled" id="subscription_Enabled_Yes"  value="1" <?php if($arrSubDetails['Enabled']=="1") { ?>checked="checked" <?php } ?>   /> Yes
				</label>
				<label class="radio">
					<input type="radio" name="subscription_Enabled" id="subscription_Enabled_No" value="0" <?php if($arrSubDetails['Enabled']=="0") { ?>checked="checked" <?php } ?>   /> No
				</label>
			</div>
        </div>       
		
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listsport.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
	  		$('#subscription_StartDate').datepicker({
                 format: 'yyyy-mm-dd'           
            });
	  		$('#subscription_EndDate').datepicker({
                 format: 'yyyy-mm-dd'           
            });
				
									 
			$("#addSport").validate({
				rules:{
					subscription_Name:"required",
				},
				messages:{
					subscription_Name:"Enter the Subscription Name",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

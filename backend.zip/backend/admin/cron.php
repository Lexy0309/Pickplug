<?php
 include("includes/common.php");
 include(SITEADMININCLUDEPATH."common-functions.php");
 include('push/cron-functions.php');
  include('push/pushFunctions.php');
  global $table_config;
 	if($_REQUEST['type']=='pick') {
		$today = date('Y-m-d');
		$strTodayPicks	=	 doGetTodayPickDetails($table_config["picks"],$today);
		$strcountpicks = count($strTodayPicks);
		
		if($strcountpicks > 0) {
			$strPickActiveUsers = doGetPickUserDetails($table_config["user"]);
			if(count($strPickActiveUsers > 0)) {
				foreach($strPickActiveUsers as $pickusers) {
					$strEmail = $pickusers['Email'];
					$userid = $pickusers['Id'];
					$res = doSendMail($strEmail);
					$strAllusers	=	 doGetAllUserPickDeviceDetails($userid);
					if(!empty($strAllusers)) {
						foreach($strAllusers as $result) { 
							$message 			= "Pick Available for today";
							$strDeviceToken		= $result['devicetoken']; 
							$strDeviceType		= $result['type']; 
							$sendnotification   = doSendNotificationMessageCron($strDeviceToken,$strDeviceType,$message);
							$strMessageClass    ="success";
							//$msg				="Notifications send successfully";
							
						}

					}
					
					
				}
				foreach($strPickActiveUsers as $pickusers) {
					$strEmail = $pickusers['Id'];
					
					$res = doSendMail($strEmail);
				}
				
				if( $res == true ) {
					echo "Message sent successfully...";
				 }  else  {
					echo "Message could not be sent...";
				 }
			
			}
		}
		
	}

?>
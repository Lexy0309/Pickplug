<?php
	include("includes/common.php");
	$page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
	include(SITEADMINTEMPLATEPATH."header.php");
	include(SITEADMININCLUDEPATH."adminuser-functions.php");
	checkLogin();
	global $table_config;
	$UserId = base64_decode($_REQUEST['id']);// Get Userid from URL
	
	if(isset($_POST['Submit']))
	{
		$AdminUserCount = CheckDataExists($table_config["admin"], 'Username', $_POST['user_Username']);
		if($AdminUserCount == 0) {
			$ary['user_Username']       = $_POST['user_Username'];
			$ary['user_Password']       = $_POST['user_Password'];
			$ary['user_Email'] 	        = $_POST['user_Email'];
			$ary['user_Role'] 	        = $_POST['user_Role'];
			$ary['user_Status'] 		= $_POST['user_Status'];
			
			$AdminInsertId	= addAdminUser($ary,"user_",$table_config["admin"]);	
			
			if(!empty($AdminInsertId)) {
				$strMessage="Admin User details added successfully";
				$strMessageClass="success";
				unset($_POST);
			}	
		} else {
			$strMessage="Admin Username already exists";
			$strMessageClass="error";
		}
	}
	
?>

<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
	 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
	
      <form class="form-horizontal well" id="add-adminform" name="add-adminform" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Add Admin User</legend>
        
       	 <div class="control-group">
          <label class="control-label" for="user_Username">Username*</label>
          <div class="controls">
		  	  <input type="text"  class="input-xlarge" id="user_Username" name="user_Username"  rel="popover" value="<?php echo (isset($_POST['user_Username'])) ? $_POST['user_Username'] : "";?>" />
          </div>
        </div>
		
		 <div class="control-group">
          <label class="control-label" for="user_Password">Password*</label>
          <div class="controls">
		  	  <input type="password"  class="input-xlarge" id="user_Password" name="user_Password"  rel="popover" value="<?php echo (isset($_POST['user_Password'])) ? $_POST['user_Password'] : "";?>" />
          </div>
        </div>
		
	    <div class="control-group">
          <label class="control-label" for="user_Email">Email</label>
          <div class="controls">
		  	  <input type="text"  class="input-xlarge" id="user_Email" name="user_Email"  rel="popover" value="<?php echo (isset($_POST['user_Email'])) ? $_POST['user_Email'] : "";?>" />
          </div>
        </div>
		        
		<div class="control-group">
          <label class="control-label" for="user_Role">Role</label>
          <div class="controls">
         	<select name="user_Role" id="user_Role">
				<!--<option value="0">-Role-</option>-->
				<?php foreach ( $global_config["adminrole"] as $k=>$adminrole) { ?>
				<option value="<?php echo $k ?>" ><?php echo $adminrole ?></option>
				<?php } ?>
			</select>
		  </div>
        </div>
	
		
		<div class="control-group">
			<label class="control-label" for="user_Status">Status</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="user_Status" id="user_Status_Active"  value="Active" <?php if($_POST['user_Status']=="Active") { ?>checked="checked" <?php } ?> checked="checked"  /> Active
				</label>
				<label class="radio">
					<input type="radio" name="user_Status" id="user_Status_InActive" value="InActive" <?php if($_POST['user_Status']=="InActive") { ?>checked="checked" <?php } ?> /> InActive
				</label>
			</div>
        </div>       
       
        
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>list-adminuser.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
	  		$('#user_Birthday').datepicker({
                 format: 'yyyy-mm-dd'           
            });
			$("#add-adminform").validate({
				rules:{
					user_Username: {
						required:true
					},
					user_Password: {
						minlength: 5,
						required:true,
					}
				},
				messages:{
					user_Username:"Enter Admin Username",
					user_Password:"Enter Admin Password Minimun 5 Char"
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
			//called when key is pressed in textbox
			$("#user_PhoneNumber").keypress(function (e) {
				//if the letter is not digit then display error and don't type anything
				if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				//display error message
					$("#errmsg").html("Digits Only").show().fadeOut("slow");
					return false;
				}
			});
		});
	  </script>
<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-lightbox.min.js"></script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

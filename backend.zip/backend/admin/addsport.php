<?php
 include("includes/common.php");
 $page = basename($_SERVER['SCRIPT_FILENAME'],'.php');
 include(SITEADMINTEMPLATEPATH."header.php");
 include(SITEADMININCLUDEPATH."sport-functions.php");
 checkLogin();
 global $table_config;
 
	if(isset($_POST['Submit'])){
		if($_FILES) {
			@$strImageProperties = getimagesize($_FILES["file_File"]["tmp_name"]);
			if($strImageProperties[0]>=$SportimgWidth && $strImageProperties[1]>=$SportimgHeight)  {
				$strBannerCount = CheckDataExists($table_config["sport"],'SportName',$_POST['sport_SportName']);
				if($strBannerCount==0){
					$ary['sport_SportName']  = $_POST['sport_SportName'];
					$ary['sport_Status'] 	= $_POST['sport_Status'];
					$ary['sport_RecordNo'] 	= $_POST['sport_RecordNo'];

					
					$BannerId	= insertSportsDetails($ary,"sport_",$table_config["sport"],$_FILES);	
					if(!empty($BannerId)){
						$strMessage="Sport Detail added successfully";
						$strMessageClass="success";
						unset($_POST);
					}	
				} else {
				   $strMessage="Sport Name already exists";
				   $strMessageClass="error";
				} 
			} else {
				$strMessage="Uploaded image greater than ".$SportimgWidth." X ".$SportimgHeight." pixels";
				$strMessageClass="error";
			}	
		}
	}
?>
<div class="span10 pull-left">
  <div class="row" id="fight-wrapper">
    <div class="span">
      <?php
 if(!empty($strMessage)) { ?>
      <div class="alert alert-<?php echo $strMessageClass;?>"> <a class="close" data-dismiss="alert">x</a> <?php echo $strMessage;?> </div>
      <?php } ?>
      <form class="form-horizontal well" id="addSport" method="post" enctype="multipart/form-data">
        <fieldset>
        <legend>Add Sport</legend>
        
        <div class="control-group">
          <label class="control-label" for="sport_SportName">Sport Name*</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="sport_SportName" name="sport_SportName"  rel="popover" value="<?php echo $_POST['sport_SportName'];?>" />
          </div>
        </div>
		
		<div class="control-group">
        	<label class="control-label" for="sport_SportIcon">Sport Icon</label>
			<div class="controls">
				<input type="file" id="file_File" name="file_File"  size="74">
				<span class="help-block">Uploaded image greater than <?php echo $SportimgWidth?> X <?php echo $SportimgHeight?> pixels</span> 
			</div>
        </div>
        
        
         <div class="control-group">
          <label class="control-label" for="sport_SportName">Record Number</label>
          <div class="controls">
            <input type="text"  class="input-xxlarge" id="sport_RecordNo" name="sport_RecordNo"  rel="popover" value="<?php echo $_POST['sport_RecordNo'];?>" />
          </div>
        </div>
        
		<div class="control-group">
			<label class="control-label" for="sport_Status">Status</label>
			<div class="controls">
				<label class="radio">
					<input type="radio" name="sport_Status" id="sport_Status_Active"  value="Active" checked="checked"   /> Active
				</label>
				<label class="radio">
					<input type="radio" name="sport_Status" id="sport_Status_Inactive" value="Inactive" /> Inactive
				</label>
			</div>
        </div>       
		
        <div class="form-actions">
          <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
          <a class="btn" href="<?php echo SITEGLOBALPATH;?>listsport.php">Cancel</a>
        </div>
        </fieldset>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
	  $(document).ready(function(){
					 
			$("#addSport").validate({
				rules:{
					sport_SportName:"required",
				},
				messages:{
					sport_SportName:"Enter the Sport Name",
				},
				errorClass: "help-inline",
				errorElement: "span",
				highlight:function(element, errorClass, validClass) {
					$(element).parents('.control-group').addClass('error');
				},
				unhighlight: function(element, errorClass, validClass) {
					$(element).parents('.control-group').removeClass('error');
					$(element).parents('.control-group').addClass('success');
				}
			});
		});
	  </script>
<?php  include(SITEADMINTEMPLATEPATH."footer.php");?>

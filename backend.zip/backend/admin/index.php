<?php 
error_reporting(E_ERROR | E_PARSE);
include("includes/common.php");
require_once(SITEADMININCLUDEPATH."common-functions.php");
include(SITEADMININCLUDEPATH."login-functions.php");
if(isset($_REQUEST['Submit'])=="Login")	{
	$strLoginHistory = doInsertLoginHistory($_REQUEST,$table_config["loginhistory"]);
	$strLoginStatus  = doAdminLogin($_REQUEST);
	$strLoginResultCount=count($strLoginStatus);
	if($strLoginResultCount==1)	{
	  assignSession($strLoginStatus);
	}	else	{
	  $strMessage="Invalid Username or Password"; 
	  $strMessageClass="indexerror"; 
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php print $global_config["SiteName"]; ?>&nbsp;::&nbsp;Admin Control</title>
<link rel="stylesheet" type="text/css" href="<?php echo $global_config["SiteAdminGlobalPath"]; ?>css/admin-index.css" />
<link rel="stylesheet" href="<?php echo $global_config["SiteAdminGlobalPath"]; ?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $global_config["SiteAdminGlobalPath"]; ?>css/font-awesome.min.css">
<style type="text/css">

        body
        {
            padding-top: 40px;
            padding-bottom: 40px;
            background-color: #f5f5f5;
        }

        .form-signin
        {
            max-width: 300px;
            padding: 19px 29px 29px;
            margin: 0 auto 20px;
            background-color: #fff;
            border: 1px solid #bbb;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            box-shadow: 0 1px 10px #a7a7a7, inset 0 1px 0 #fff;
        }

        .form-signin .form-signin-heading,
        .form-signin .checkbox
        {
            margin-bottom: 10px;
        }

        .form-signin input[type="text"],
        .form-signin input[type="password"]
        {
            font-size: 16px;
            height: auto;
            margin-bottom: 15px;
            padding: 4px 9px;
        }

    </style>
</head>

<body>
<?php if(isset($strMessage)){?>
<table border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto 10px;width:358px;">
  <tr>
  <td colspan="2" align="center" height="30">
   <div class="<?php echo $strMessageClass;?>">
		<p><?php echo $strMessage;?></p>
	</div>
  </td>
  </tr>
</table>
<?php } ?>
<div id="ErrorTable" class="indexerror"></div>
<div class="container">
    <form class="form-signin" method="post">

        <h2 class="form-signin-heading">Please sign in</h2>

        <div class="input-prepend">
            <span class="add-on"><i class="icon-large icon-envelope"></i></span>
            <input class="span3" name="frmUserName" type="text" id="frmUserName" placeholder="Username">
        </div>
        <div class="input-prepend">
            <span class="add-on"><i class="icon-large icon-key"></i></span>
            <input class="span3" name="frmPassword" type="password" id="frmPassword" placeholder="Password">
        </div>
        <button class="btn btn-large btn-primary" type="submit" name="Submit" value="Login">Sign in</button>
    </form>
</div>
</body>
</html>
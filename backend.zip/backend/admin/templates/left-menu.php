<?php 
$userArray  			= array("listuser","edituser");
$settingsArray 			= array("settings","mailsettings");
$userrole               = doGetUserRole($_SESSION["demo"]['userid']);
?>  



<div class="span2 pull-left">
<!--Sport Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">App Analytics</li>
			<li <?php if($page=='appanalytics') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>appanalytics.php">App Analytics</a></li>
		</ul>

	</div>	


	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Sports Management</li>

			<li <?php if($page=='addsport') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>addsport.php">Add Sport</a></li>

			<li <?php if($page=='listsport' || $page=='editsport') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listsport.php">List Sports</a></li>

		</ul>

	</div>	

	

<!--Team Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Team Management</li>

			<li <?php if($page=='addteam') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>addteam.php">Add Team</a></li>

			<li <?php if($page=='listteam' || $page=='editteam') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listteam.php">List Teams</a></li>

		</ul>

	</div>	

<!--Picks Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Picks Management</li>

			<li <?php if($page=='addpicks') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>addpicks.php">Add Pick</a></li>

			<li <?php if($page=='listpicks' || $page=='editpicks') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listpicks.php">List Picks</a></li>

		</ul>

	</div>	
	
<!--Record Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Record Management</li>


			<li <?php if($page=='listrecord') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listrecord.php">List Records</a></li>

		</ul>

	</div>	

<!--Bets Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Bets Management</li>

			<li <?php if($page=='addbet') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>addbet.php">Add Bet</a></li>

			<li <?php if($page=='listbets' || $page=='editbet') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listbets.php">List Bets</a></li>

		</ul>

	</div>	

	

<!--User Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">User Management</li>

            <li <?php if($page=='adduser' ) { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>adduser.php">Add User</a></li>

			<li <?php if($page=='listuser' || $page=='edituser') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listuser.php">List Users</a></li>

            <li <?php if($page=='importuser') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>importuser.php">Import Users</a></li>

		</ul>

	</div>

	<?php if($userrole==1) { ?>

<!--Admin User Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Admin User Management</li>

            <li <?php if($page=='add-adminuser' ) { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>add-adminuser.php">Add Admin User</a></li>

			<li <?php if($page=='list-adminuser' || $page=='edit-adminuser') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>list-adminuser.php">List Admin Users</a></li>

		</ul>

	</div>
<?php } ?>
	

<!--Week Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Weeks Management</li>

			<li <?php if($page=='addweek') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>addweek.php">Manage Weeks</a></li>

		</ul>

	</div>



        <div class="well sidebar-nav">

            <ul class="nav nav-tabs nav-stacked">

                <li class="nav-header">Push Notification</li>

                <li <?php if($page=='sendnotificationuser') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>sendnotificationuser.php">Push Notification</a></li>

            </ul>

        </div>
        
        
		


<!--Subscription Management-->

	<div class="well sidebar-nav">

		<ul class="nav nav-tabs nav-stacked">

			<li class="nav-header">Subscription Management</li>

			<li <?php if($page=='addsubscription') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>addsubscription.php">Add Subscription</a></li>
			   <li <?php if($page=='listsubscription' || $page=='edituser') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>listsubscription.php">List Subscriptions</a></li>
			   <li <?php if($page=='usersubscriptions') { ?> class="active" <?php } ?>><a href="<?php echo $global_config["SiteGlobalAdminPath"];?>usersubscriptions.php">User Subscriptions</a></li>

		</ul>

	</div>
</div>



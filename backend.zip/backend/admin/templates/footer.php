</div>
<footer align="center">
    <p align="center">Copyright &copy; 2013 <strong><?php echo SITENAME;?></strong></p>
</footer>
</body>
</html>
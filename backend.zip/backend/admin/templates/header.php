<?php require_once(SITEADMININCLUDEPATH."common-functions.php"); ?>

<!DOCTYPE html>

<html class="no-js">

<head>

    <meta charset="utf-8">

    <title><?php print ucfirst($_SESSION["demo"]['Username']); ?></title>

    <meta name="description" content="">

    <meta name="viewport" content="width=device-width">



    <link rel="stylesheet" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/bootstrap-responsive.min.css">

    <link rel="stylesheet" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/main.css">

    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/bootstrap-datetimepicker.min.css">

	<link href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/bootstrap-toggle-buttons.css" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/bootstrap-wysihtml5.css"></link>

	<link rel="stylesheet" href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/bootstrap-lightbox.min.css">

	

	<!-- Jquery Calendar with datepicker

	<link href="<?php echo $global_config["SiteGlobalAdminPath"];?>css/jquery-calendar.css" type="text/css" rel="stylesheet">-->

	

	





<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/jquery.js"></script>

<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-tooltip.js"></script>

<script src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-popover.js"></script>

<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/jquery.validate.js"></script>

<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/validation.js"></script>

<script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/adminAjax.js"></script>

 <script type="text/javascript" src="<?php echo $global_config["SiteGlobalAdminPath"];?>js/bootstrap-datepicker.js"></script>



</head>

<body>



<div class="navbar navbar-fixed-top">

    <div class="navbar">

        <div class="navbar-inner">

            <div class="container-fluid">

                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </a>

                <span class="brand">

				<?php print ucfirst($_SESSION["demo"]['Username']); ?>

				</span>



                <div class="nav-collapse collapse">



                    <ul class="nav">

                        <li class="active"><a href="<?php print SITEGLOBALADMINPATH; ?>listsport.php"><i class="icon-home icon-black"></i> Dashboard</a></li>

                        <li><a href="<?php print SITEGLOBALADMINPATH; ?>setting.php"><i class="icon-book icon-black"></i> Setting</a></li>

                      </ul>



                    <ul class="nav pull-right settings">

                        <li class="dropdown">

                            <ul class="dropdown-menu">

                                <li><a href="#">Account Settings</a></li>

                                <li class="divider"></li>

                                <li><a href="#">System Settings</a></li>

                            </ul>

                        </li>

                    </ul>



                    <ul class="nav pull-right settings">

                        

                        <li><a href="<?php print $global_config["SiteGlobalAdminPath"]; ?>logout.php" class="tip icon logout" data-original-title="Logout" data-placement="bottom">

						

						<i

                           class="icon-large icon-off"></i></a></li>

                    </ul>



                    <ul class="nav pull-right settings">

                        <li class="divider-vertical"></li>

                    </ul>



                    <p class="navbar-text pull-right">

                        Welcome <strong>Admin</strong>

                    </p>

              

					

					<?php if($page == 'listfight') { ?>					

                    <div class="pull-right">

                        <form class="form-search form-inline" style="margin:5px 0 0 0;" method="get">

                            <div class="input-append">

                                <input type="text" name="key" class="span2 search-query" placeholder="Search" value="<?php echo $_POST['key'];?>">

                                <button type="submit" class="btn" name="filter"><i class="icon-search"></i></button>

                            </div>

                        </form>

                    </div>

					<?php } ?>





                </div>

                <!--/.nav-collapse -->

            </div>

        </div>

    </div>

</div>

<div class="row-fluid">

			<?php

			 	include(SITEADMINTEMPLATEPATH.'left-menu.php');

			?>






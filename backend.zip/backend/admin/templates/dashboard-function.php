<?php 
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	
	function getAllDetailsCount($tbl_name, $where="") {
		$sql = "select count(*) as n from  ".$tbl_name." $where";
		$strTestimonials = SelectQry($sql);
		return $strTestimonials[0]['n'];
	}
	
	function getLatestDetails($tbl_name, $where="") {
		$sql = "select * from  ".$tbl_name." $where order by Id limit 1";
		$strTestimonials = SelectQry($sql);
		return $strTestimonials[0];
	}
	
	function getLastLoginDetails($tbl_name) {
		$sql = "select * from  ".$tbl_name."  order by Id desc limit 1";		
		$strLastLogin = SelectQry($sql);
		return $strLastLogin[0];
	}
	
	function GetTodayAppointments() {
		$sql = "select PatientName,Phone,Treatment,PreferredDate,Status  from  tbl_appointments  where IsDeleted='No' and PreferredDate like '%".date('Y-m-d')."%' order by PreferredDate asc ";		
		$strTodayAppointments = SelectQry($sql);
		return $strTodayAppointments;
	}
	
	function GetTodayAppointmentsByStatus($status) {
		$sql = "select count(*) as n from  tbl_appointments  where IsDeleted='No' and Status='".$status."' and PreferredDate like '%".date('Y-m-d')."%'";		
		$strAppointments = SelectQry($sql);
		return $strAppointments[0]['n'];
	}
	
	function getTodayEvents() {
		$sql = "SELECT EventName,Location, EventStartDate, EventEndDate FROM tbl_events WHERE  EventStartDate >= '".date('d-M-Y')."' AND EventEndDate >= '".date('d-M-Y',strtotime('+7 days'))."' ORDER BY EventStartDate ASC";
		$strTodayEvent = SelectQry($sql);
		return $strTodayEvent;
	}
	
	function getTodayMoreEvents() {
		$sql = "SELECT EventName,Location, EventStartDate, EventEndDate FROM tbl_events WHERE  EventStartDate <= '".date('d-M-Y')."' AND EventEndDate <= '".date('d-M-Y',strtotime('+7 days'))."'";
		$strTodayMoreEvent = SelectQry($sql);
		return $strTodayMoreEvent;
	}
	
	function getAppointmentDate() {
		$sql = "SELECT * FROM tbl_order WHERE  type='Service' ORDER BY id ASC";
		$strappointmentDate = SelectQry($sql);
		return $strappointmentDate;
	}
	function getServiceDetails($date) {
		$sql="SELECT count(id) as product_count,id FROM tbl_order WHERE type='Service' AND YEAR(appointmentDate) = YEAR('".$date."') AND MONTH(appointmentDate) = MONTH('".$date."') AND DAY(appointmentDate)  = DAY('".$date."')";
		$strService = SelectQry($sql);
		return $strService;
	}
	
	function getServiceDetailsnew($date) {
		$sql="SELECT * FROM tbl_order WHERE type='Service' AND YEAR(appointmentDate) = YEAR('".$date."') AND MONTH(appointmentDate) = MONTH('".$date."') AND DAY(appointmentDate)  = DAY('".$date."')";
		$strService = SelectQry($sql);
		return $strService;
	}
	
	function getUserDetails($date) {
		$sql="SELECT * FROM tbl_order WHERE YEAR(appointmentDate) = YEAR('".$date."') AND MONTH(appointmentDate) = MONTH('".$date."') AND DAY(appointmentDate)  = DAY('".$date."')";
		$strService = SelectQry($sql);
		//printArray($strService);
		return $strService;
	}
	function getServiceUserById($id) {
		$sql="SELECT * FROM tbl_order WHERE id = '".$id."' AND IsDeleted='No' AND type='Service' ORDER BY id ASC";
		$strService = SelectQry($sql);
		//printArray($strService);
		return $strService;
	}
	
?>
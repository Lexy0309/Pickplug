<div id="menu">
	<ul>
		<li <?php if(isset($currentpage)&& $currentpage=='home') { ?> class="active" <?php } ?>><a href="<?php print $global_config["SiteGlobalAdminPath"]; ?>home.php">Dashboard</a></li>
	</ul>
</div>
<?php



/* update user details */
function updateUserDetails($objArray,$Prefix,$tbl_name,$id,$fileArray='') {
	global $global_config;
	$where="WHERE Ident='".$id."'";
	$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
	return $ID;
}

function updateUserDetailsByEmail($objArray,$Prefix,$tbl_name,$email,$fileArray='') {
	global $global_config;
	$where="WHERE Email='".$email."'";
	$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
	return $ID;
}



/* Add User Details */



function addUserDetails($objArray,$Prefix,$tbl_name,$id,$fileArray='') {
	global $global_config;
	$insertid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);	
	if(!empty($fileArray['user_Photo']['name'])) {
		doUploadUserPhoto($fileArray,$insertid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'userImage/','Photo');
	}
	return true;
}





function updateGalleryDetails($objArray,$Prefix,$tbl_name,$id,$fileArray) {

	global $global_config;

	$where="WHERE Id='".$id."'";

    $ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	

	doUploadUserPhoto($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'userImage/','Photo');

	return $ID;

}



function doUploadUserPhoto($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName) {

		global $global_config, $table_config;

		$file = $fileArray["user_Photo"]["tmp_name"];

		$destpath	=  $strFilePath;

		if($file!=''){

			$filename = $fileArray["user_Photo"]["name"];

			$fileExt = substr($filename,-4,4);

			$DBFilename = substr($filename,0,-4);

			$filename=date('YmdHis').$fileExt;

			if($filename!=''){

				@unlink($destpath.$filename);

			}

			copy($file,$destpath.$filename);

			$strImageProperties = getimagesize($file);

			updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);

		}

	}

	

function SearchByValue($tbl_name,$where)

{

	$sql = "select * from ".$tbl_name." $where";

	$strUser=SelectQry($sql);

	return $strUser;

}

function doDeleteRecordByStatus($id,$tbl_name) {
	$deldate = date('Y-m-d H:i:s');
	$sql = "update `".$tbl_name."` set `IsDeleted` = 'Yes', `ModifiedDate` = '".$deldate."' where `Id` = '".$id."'"; 
	ExecuteQry($sql);
	return true;
}

function getusersubscription($id)
{
	$sql = 'SELECT * FROM tbl_transactions LEFT JOIN tbl_subscription ON tbl_subscription.ProductId=tbl_transactions.ProductId WHERE tbl_transactions.User='.$id;
	$res = SelectQry($sql);
	return $res;
}

?>
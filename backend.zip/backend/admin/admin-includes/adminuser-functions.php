<?php
/* Add Adminuser Details */
function addAdminUser($objArray,$Prefix,$tbl_name) {
	global $global_config;
	$insertid =	AddInfoToDB($objArray,$Prefix,$tbl_name);	
	return true;
}

/* update user details */
function updateAdminUser($objArray,$Prefix,$tbl_name,$id) {
	global $global_config;
	$where = "WHERE Id='".$id."'";
	$updateid = UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
	return true;
}
?>
<style type="text/css">
a {
  color: #0088cc;
  text-decoration: none;
}
a:hover {
  color: #005580;
  text-decoration: underline;
}

h2 { padding-top: 20px; }
h2:first-of-type { padding-top: 0; }
ul { padding: 0; }

.pagination {
  height: 36px;
  margin: 18px 0;
  float: right;
}
.pagination ul {
  display: inline-block;
  *display: inline;
  /* IE7 inline-block hack */

  *zoom: 1;
  margin-left: 0;
  margin-bottom: 0;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
  -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}
.pagination li {
  display: inline;
}
.pagination a {
  float: left;
  padding: 0 14px;
  line-height: 34px;
  text-decoration: none;
  border: 1px solid #ddd;
  border-left-width: 0;
}
.pagination a:hover,
.pagination .active a {
  background-color: #f5f5f5;
}
.pagination .active a {
  color: #999999;
  cursor: default;
}
.pagination .disabled span,
.pagination .disabled a,
.pagination .disabled a:hover {
  color: #999999;
  background-color: transparent;
  cursor: default;
}
.pagination li:first-child a {
  border-left-width: 1px;
  -webkit-border-radius: 3px 0 0 3px;
  -moz-border-radius: 3px 0 0 3px;
  border-radius: 3px 0 0 3px;
}
.pagination li:last-child a {
  -webkit-border-radius: 0 3px 3px 0;
  -moz-border-radius: 0 3px 3px 0;
  border-radius: 0 3px 3px 0;
}
.pagination-centered {
  text-align: center;
}
.pagination-right {
  text-align: right;
}
.pager {
  margin-left: 0;
  margin-bottom: 18px;
  list-style: none;
  text-align: center;
  *zoom: 1;
}
.pager:before,
.pager:after {
  display: table;
  content: "";
}
.pager:after {
  clear: both;
}
.pager li {
  display: inline;
}
.pager a {
  display: inline-block;
  padding: 5px 14px;
  background-color: #fff;
  border: 1px solid #ddd;
  -webkit-border-radius: 15px;
  -moz-border-radius: 15px;
  border-radius: 15px;
}
.pager a:hover {
  text-decoration: none;
  background-color: #f5f5f5;
}
.pager .next a {
  float: right;
}
.pager .previous a {
  float: left;
}
.pager .disabled a,
.pager .disabled a:hover {
  color: #999999;
  background-color: #fff;
  cursor: default;
}
</style>
<?php 

if(isset($_GET['key'])) {
	$targetpage = $targetpage."&";
} 
    $pagination = "";
	  $adjacents = 1;
  	if($lastpage > 1)
 	{	
		$pagination .= "<div class=\"pagination\">";
		if ($page > 1) 
			 $pagination.= " <ul>
    <li><a href=\"$targetpage"."page=$prev\">&larr;</a><li>";
		else
			$pagination.= "<li><a href='#'>&larr;</a></li>";	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
		    
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					 $pagination.= "<li class=\"active\"><a href='#'>$counter</a></li>";
				else
				 $pagination.= "<li><a href=\"$targetpage"."?page=$counter\" class=\"inactive-page\">$counter</a></li>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "&nbsp;<span class=\"active\">$counter</span>&nbsp;";
					else
					 	$pagination.= "<li><a href=\"$targetpage"."?page=$counter\" class=\"inactive-page\">$counter</a></li>";					
				}
				$pagination.= "..";
				 $pagination.= "<li><a href=\"$targetpage"."?page=$lpm1\" class=\"inactive-page\">$lpm1</a></li>";
					$pagination.= "<li><a href=\"$targetpage"."?page=$lastpage\" class=\"inactive-page\">$lastpage</a></li>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<li><a href=\"$targetpage"."?page=1\" class=\"inactive-page\">1</a></li>";
				//$pagination.= "<a href=\"$targetpage&page=2\" class=\"inactive-page\">2</a>";
				$pagination.= "..";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "&nbsp;<span class=\"active\">$counter</span>&nbsp;";
					else
						$pagination.= "<li><a href=\"$targetpage"."?page=$counter\" class=\"inactive-page\">$counter</a></li>";					
				}
			 	$pagination.= "..";
			 	$pagination.= "<li><a href=\"$targetpage"."?page=$lpm1\" class=\"inactive-page\">$lpm1</a></li>";
			 	$pagination.= "<li><a href=\"$targetpage"."?page=$lastpage\" class=\"inactive-page\">$lastpage</a></li>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<li><a href=\"$targetpage"."?page=1\" class=\"inactive-page\">1</a></li>";
				//$pagination.= "<a href=\"$targetpage&page=2\" class=\"inactive-page\">2</a>";
				$pagination.= "..";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
					 	$pagination.= "&nbsp;<span class=\"current-page\">$counter</span>&nbsp;";
					else
					 	$pagination.= "<li><a href=\"$targetpage"."?page=$counter\" class=\"inactive-page\">$counter</a></li>";					
				}
			}
		}
		
		//next button
 		if ($page < $counter - 1) 
			 $pagination.= "<li><a href=\"$targetpage"."page=$next\">&rarr;</a></li>";
		else
			 $pagination.= "<li><a href='#'>&rarr;</a></li>";
		$pagination.= "<ul></div>\n";		
	}
?>

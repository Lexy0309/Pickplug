<?php

function insertTeamsDetails($objArray,$Prefix,$tbl_name,$fileArray) {

	global $global_config;

	$objArray['team_AddedDate']= date("Y-m-d H:m:s");

	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);

	doUploadDesignImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'team/','TeamIcon');

	doUploadteamThumbImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'team/','thumb','302','302');

	return $insertedid; 

}
function updateUserDetailsByEmail($objArray,$Prefix,$tbl_name,$email,$fileArray='') {
	global $global_config;
	$where="WHERE Email='".$email."'";
	$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
	return $ID;
}
function addUserDetails($objArray,$Prefix,$tbl_name,$id,$fileArray='') {
	global $global_config;
	$insertid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);	
	if(!empty($fileArray['user_Photo']['name'])) {
		doUploadUserPhoto($fileArray,$insertid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'userImage/','Photo');
	}
	return true;
}



function updateSportsDetails($objArray,$Prefix,$tbl_name,$id,$fileArray) {

	global $global_config;

	$where="WHERE Id='".$id."'";

    $ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	

	doUploadDesignImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'team/','TeamIcon');

	doUploadteamThumbImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'team/','thumb','302','302');

	return $ID;

}





function doUploadteamThumbImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$thumbWidth='',$thumbHeight='') {

		global $global_config, $table_config;

		$file = $fileArray["file_File"]["tmp_name"];

		$destpath	=  $strFilePath;

		$thumbpath   =  $destpath.'thumb/';

		if($file!=''){

			$filename = $fileArray["file_File"]["name"];

			$fileExt = substr($filename,-4,4);

			$DBFilename = substr($filename,0,-4);

			if($thumbpath){

				$filename='thumb_'.date('YmdHis').$fileExt;

			} else {

				$filename=date('YmdHis').$fileExt;

			}

			if($filename!=''){

				@unlink($destpath.$filename);

				@unlink($thumbpath.$filename);

			}

			copy($file,$destpath.$filename);

			

			$strImageProperties = getimagesize($file);

				if($thumbWidth != ''){

					if($strImageProperties[0]>$thumbWidth){

						FinalCrop($destpath.$filename,$thumbpath.$filename,$thumbWidth,$thumbHeight);	

					}else{

						copy($file,$thumbpath.$filename);

					}

				}	

			updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);

		}

	}

?>


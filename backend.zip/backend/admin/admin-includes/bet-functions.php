<?php

function insertSportsDetails($objArray,$Prefix,$tbl_name,$fileArray) {

	global $global_config;

	$objArray['bet_AddedDate']= date("Y-m-d H:i:s");

	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);

	doUploadDesignImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'bet/','BetLogo');

	//doUploadSportsThumbImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'sport/','thumb','302','302');

	return $insertedid; 

}

 function getBetPosition(){
		global $table_config,$global_config,$countrylist;
		$sql="SELECT MAX(Position) as pos FROM ".$table_config["bet"]."";
		$results=SelectQry($sql);
		return $results[0]['pos'];
	 }

function updateSportsDetails($objArray,$Prefix,$tbl_name,$id,$fileArray) {

	global $global_config;

	$where="WHERE Id='".$id."'";

    $ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	

	doUploadDesignImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'bet/','BetLogo');

	//doUploadSportsThumbImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'sport/','thumb','302','302');

	return $ID;

}







?>
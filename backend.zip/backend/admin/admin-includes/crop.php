<?php 

 define ("MAX_SIZE","400");

 $errors=0;
 
 if($_SERVER["REQUEST_METHOD"] == "POST")
 {
     $image =$_FILES["Video_VideoImage"]["name"];
	 $uploadedfile = $_FILES['Video_VideoImage']['tmp_name'];

  if ($image) 
  {
	$filename = stripslashes($_FILES['Video_VideoImage']['name']);
	$extension = getExtension($filename);
	$extension = strtolower($extension);
	 if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) 
	 {
		echo ' Unknown Image extension ';
		$errors=1;
	 }
	 else
	 {
	   $size=filesize($_FILES['Video_VideoImage']['tmp_name']);
 
		if($extension=="jpg" || $extension=="jpeg" )
		{
			$uploadedfile = $_FILES['Video_VideoImage']['tmp_name'];
			$src = imagecreatefromjpeg($uploadedfile);
		}
		else if($extension=="png")
		{
			$uploadedfile = $_FILES['Video_VideoImage']['tmp_name'];
			$src = imagecreatefrompng($uploadedfile);
		}
		else 
		{
			$src = imagecreatefromgif($uploadedfile);
		}
 
		list($width,$height)=getimagesize($uploadedfile);
		
		$newwidth=100;
		$newheight=100;
		
		//$newheight=($height/$width)*$newwidth;
		$tmp=imagecreatetruecolor($newwidth,$newheight);
		imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
		$filename = str_replace(" ","_",$_FILES['Video_VideoImage']['name']);
		
		$dbFileName = date("YmdHsi")."_".basename($filename,$extension).'jpg';		
		$filename = $global_config["VideoLocalImageUpload"].$dbFileName;
		
		copy($source_file,$filename);
		//if($extension=='jpg' || $extension=='jpeg'){
			imagejpeg($tmp,$filename,100);
		//}
/*		if($extension=="png"){
			imagepng($tmp,$filename,100);
		}
		if($extension=="gif"){
			imagegif($tmp,$filename,100);
		}
*/		imagedestroy($src);
		imagedestroy($tmp);
	}
  }
}

/*function getExtension($str) {
	 $i = strrpos($str,".");
	 if (!$i) { return ""; } 

	 $l = strlen($str) - $i;
	 $ext = substr($str,$i+1,$l);
	 return $ext;
 }*/
 ?>
<?php

	function getAllDetails($tbl_name)	{
		$sql="SELECT * FROM $tbl_name";
		$strResult = SelectQry($sql);
		return $strResult;
	}
	
	function GetAllDetailsById($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
    
    
function insertSubscriptionDetails($objArray,$Prefix,$tbl_name) {

	global $global_config;

// 	$objArray['sport_AddedDate']= date("Y-m-d H:m:s");

	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);

 

	return $insertedid; 

}

 

function updateSubscriptionDetails($objArray,$Prefix,$tbl_name,$id) {

	global $global_config;

	$where="WHERE Id='".$id."'";

    $ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
 

	return $ID;

}



 
 
	function listSports($tblname) {
		global $global_config;
		$sql = "SELECT Id,SportName,RecordNo,SportIcon FROM ".$tblname. " ORDER BY Id DESC";
		$strResult = SelectQry($sql);
		return $strResult;
	}

?>


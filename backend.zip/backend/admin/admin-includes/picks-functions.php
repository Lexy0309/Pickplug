<?php

	function getAllDetails($tbl_name)	{
		$sql="SELECT * FROM $tbl_name";
		$strResult = SelectQry($sql);
		return $strResult;
	}
	
	function GetAllDetailsById($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
	
	function CheckPicksDataExists($TableName,$ColumnName,$Value,$Field='',$Ident='') {
		if($TableName && $ColumnName && $Value)	
		{
			if($TableName && $ColumnName && $Ident)	
				$where = " Where ".$ColumnName ."  ='". addslashes($Value) . "' and ".$Field."='".$Ident."'";
			else
				$where = " Where ".$ColumnName ." ='". addslashes($Value) . "'";
		}
		$strSql    = "Select Count(*) as Cnt from ".$TableName.$where;
		$Data  	   = SelectQry($strSql);
		return $Data[0][0];
	}
	/* update  details */
	function updateDetails($objArray,$Prefix,$tbl_name,$id) {
		global $global_config;
		$where="WHERE Id='".$id."'";
		$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
		return $ID;
	}
	
	function getWeeksDetails($tbl_name,$j) {
		$sql = "select * from ".$tbl_name." where Id ='".$j."'";
		$strResult = SelectQry($sql);
		return $strResult[0];
	}
	
	function doDeleteRecordByStatuses($id,$tbl_name) {
		$deldate = date('Y-m-d H:i:s');
		$sql = "update `".$tbl_name."` set `IsDeleted` = 'Yes', `ModifiedDate` = '".$deldate."' where `Id` = '".$id."'"; 
		ExecuteQry($sql);
		
		// update all picks
		$strSql1 = "select SportName from ".$tbl_name." where Id ='".$id."'";
		$res = SelectQry($strSql1);
		$sportname = $res[0]['SportName'];
		
		$updateSQL =  "update `".$tbl_name."` set  `ModifiedDate` = '".$deldate."' where `SportName` = '".$sportname."'"; 
		ExecuteQry($updateSQL);
		return true;
	}
	function getSportName($tbl_name) {
		$sql = "select Id,SportName from ".$tbl_name;
		$strResult = SelectQry($sql);
		return $strResult;
	}

?>
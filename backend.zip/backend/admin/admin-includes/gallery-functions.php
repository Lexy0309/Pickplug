<?php

/* insert product details */
function insertDetails($objArray,$Prefix,$tbl_name) {
	global $global_config;
	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);
	return $insertedid; 
}
function insertGalleryDetails($objArray,$Prefix,$tbl_name,$fileArray) {
	global $global_config;
	$objArray['gallery_Addeddate']= date("Y-m-d H:m:s");
	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);
	doUploadDesignImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'gallery/','Image');
	doUploadInnerThumbImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'gallery/','thumb','302','302');
	//doUploadInnerImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'gallery/','Image','302','302','200','302','151','151');
	return $insertedid; 
}
/* update product details */
function updateDetails($objArray,$Prefix,$tbl_name,$id,$fileArray='') {
	global $global_config;
	$where="WHERE Id='".$id."'";
	$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
	return $ID;
}
function updateGalleryDetails($objArray,$Prefix,$tbl_name,$id,$fileArray) {
	global $global_config;
	$where="WHERE Id='".$id."'";
	//$objArray['gallery_Addeddate']= date("Y-m-d H:m:s");
	$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
	doUploadDesignImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'gallery/','Image');
	doUploadInnerThumbImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'gallery/','thumb','302','302');
	//doUploadInnerImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'gallery/','Image','302','302','200','302','151','151');
	return $ID;
}

function updatepublishstatus($id,$tbl_name,$status){
	if($status=='Yes') {
		$State = 'No';
	} else{
		$State = 'Yes';
	}
	$sql = "UPDATE ".$tbl_name." SET Published='$State' WHERE Id='".$id."'";
	ExecuteQry($sql);
}
function GetAllGallertCatRecordsById($tbl_name,$id){
	$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
	$strResult = SelectQry($sql);
	return $strResult[0];
}
function getGalleryCategoryDetails($tbl_name){
	$sql = "select * from ".$tbl_name."";
	$strResult = SelectQry($sql);
	return $strResult;
}
?>
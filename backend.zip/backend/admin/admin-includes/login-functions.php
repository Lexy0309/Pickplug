<?php 
	function doAdminLogin($objArray){
		global $table_config;
		$sql="SELECT * FROM ".$table_config["admin"]." WHERE Username='".stripslashes($objArray['frmUserName'])."' AND Password='".stripslashes($objArray['frmPassword'])."'";
		$result=SelectQry($sql);
		return $result;
	}
	
	function doInsertLoginHistory($objArray,$tbl_name){
		global $table_config;
			$objArray["txt_username"]	= $objArray["frmUserName"];
			$objArray["txt_logindate"]	= date("Y-m-d");
			$objArray["txt_logintime"]	= date("H:i:s");
			$objArray["txt_ip_address"]	= $_SERVER['REMOTE_ADDR'];
	 		$id = AddInfoToDB($objArray,'txt_',$tbl_name);
			return $id;
	}
	
	function assignSession($objArray){
	  $_SESSION["demo"]['userid']  	=$objArray[0]["Id"];
	  $_SESSION["demo"]['Username']	=$objArray[0]["Username"];
	  Redirect(SITEGLOBALADMINPATH."listsport.php");
	}
?>
<?php 
$limit = $global_config["PageLimit"];
//how many items to show per page
$page = $_GET['page'];
if($page) 
	$start = ($page - 1) * $limit; 			//first item to display on this page
else
	$start = 0;	
if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;	
	$lastpage = ceil($total_pages/$limit);	  //lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;
?>
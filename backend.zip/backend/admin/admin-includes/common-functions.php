


<?php

	error_reporting(E_ERROR | E_PARSE);

	require_once(SITEADMININCLUDEPATH."main-tables.php");
	require_once("ImageManipulator.php");
	global $qryArrays;
	$qryArrays = array();

	$strLoggedIn  				= $_SESSION['id'];
	$strEmployeeDisplayInterval = $_SESSION['Empdisplayinterval'];
    $str404ErrorMessage			= $_SESSION['PageNotFound404'];
	$strDownMessage				= $_SESSION['sitedowntext'];
	$strSiteDown				= $_SESSION['Sitedown'];
		
	$_SESSION['local_path']    = $global_config["SiteLocalPath"]."admin/userfiles/"; 
    $_SESSION['site_url_path'] = $global_config["SiteGlobalPath"]."admin/userfiles/";
    $_SESSION['thumbs']	       = "_thumbs";
    $_SESSION['images']		   = "Images";
    $_SESSION['files']		   = "Files";
    $_SESSION['flash']		   = "Flash";   

	$dbhost = $global_config['DBHost'];
	$dbuser = $global_config['DBUserName'];
	$dbpass = $global_config['DBPassword'];
	$dbname = $global_config['DBDatabaseName'];
	
		
	$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	mysql_select_db($dbname) or die('Could not connect: ' . mysql_error());
	//funtion to select values from the db
	function SelectQry($Qry) {
		global $qryArrays;
		$qryArrays[] = $Qry;
		$result  = mysql_query($Qry) or die ("QUERY Error:".$Qry."<br>".mysql_error());
		$numrows = mysql_num_rows($result);		
		if ($numrows == 0){			
			return;
		} else {
		   $row = array(); 
		   $record = array();
		   while ($row = mysql_fetch_array($result)){ 
			$record[] = $row; 
		   }		
		}		
		return MakeStripSlashes($record);
	}
	function FetchQryAsAssoc($Qry) {
		global $qryArrays;
		$qryArrays[] = $Qry;
		$result  = mysql_query($Qry) or die ("QUERY Error:".$Qry."<br>".mysql_error());
		$numrows = mysql_num_rows($result);		
		if ($numrows == 0){			
			return;
		} else {
 
		   $row = array(); 
		   $record = array();
		   while ($row = mysql_fetch_assoc($result)){ 
			$record[] = $row; 
		   }		
		}		
		return MakeStripSlashes($record);
	}

	//Function to Execute the query
	function ExecuteQry($Qry, $InsertAction='')	{
		global $qryArrays;
		$qryArrays[] = $Qry;
		if($Qry!="")	{
			mysql_query($Qry) or die("Error on MySQL Query : ".$Qry."<br>".mysql_error());
			if($InsertAction=="insert")
				return mysql_insert_id();
			else
				return true;
		} else {
			print "Empty Query : ";
			exit();
		}
	}
	
	/*Insert the value into table*/
	
	function insertDetails($objArray,$Prefix,$tbl_name) {
	global $global_config;
	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);
	return $insertedid; 
   }
	
	
	function AddInfoToDB($objArray,$Prefix,$TableName){
		$counter = 0;
		foreach($objArray as $key=>$value){
			$pos = strpos($key, $Prefix);
			if (!is_integer($pos)) {
			}else{
				$key = str_replace($Prefix,"",$key);
				$insertArray[$counter]["Field"] = $key;
 				$insertArray[$counter]["Value"] = stripslashes($value);
				$counter++;
			}
		}
		$insert_id = doInsert($TableName,$insertArray);
		return $insert_id;
	}

	function UpdateInfoToDB($objArray,$Prefix,$TableName,$Where){
		$counter = 0;
	
	    foreach($objArray as $key=>$value){
			$pos = strpos($key, $Prefix);
			if (!is_integer($pos)) {
			}else{
				$key = str_replace($Prefix,"",$key);
				$UpdateArray[$counter]["Field"] = $key;
				$UpdateArray[$counter]["Value"] = $value;
				$counter++;
			}
		}
		//print_r($UpdateArray);
		$res =doUpdate($TableName,$UpdateArray,$Where);
		return $res;
	}	
	function doInsert($strTableName,$objFieldsArray)
	{
		global $objSmarty;
		if(is_array($objFieldsArray))
		{
			$strInsertFields = "";
			$strInsertValues = "";
			for($i=0;$i<count($objFieldsArray);$i++)
			{
				$strInsertFields.= $objFieldsArray[$i]["Field"];
				$strInsertValues.= "'".addslashes($objFieldsArray[$i]["Value"])."'";
				if($i<count($objFieldsArray)-1)
				{
					if($objFieldsArray[$i]["Field"]!=""){
					$strInsertFields.=", ";
					$strInsertValues.=", ";
					}
				}
			}
			$strInsertQry = "INSERT INTO $strTableName($strInsertFields) VALUES($strInsertValues)";
 			
			ExecuteQry($strInsertQry);
			$InsertId = mysql_insert_id();
			return $InsertId;
		}
	}

	function doUpdate($strTableName,$objFieldsArray,$WhereClause)
	{
		global $objSmarty;
		if(is_array($objFieldsArray))
		{
			$strUpdateFields = "";
			for($i=0;$i<count($objFieldsArray);$i++)
			{
				$strUpdateFields.= $objFieldsArray[$i]["Field"]."="."'".addslashes($objFieldsArray[$i]["Value"])."'";
				if($i<count($objFieldsArray)-1)
				{
					if($objFieldsArray[$i]["Field"]!=""){
						$strUpdateFields.=", ";
					}
				}
			}
			$strUpdateQry = "UPDATE $strTableName SET $strUpdateFields $WhereClause"; 
			
			ExecuteQry($strUpdateQry);

			return true;
		}
	}
	
	/**
		 * Apply stripslashes function for array of values 
		 * @param 	ToStripslash (array)			
		 * @return  Stripped array
	*/
	function MakeStripSlashes($array,$replaceValue='',$replaceValueTo='') {
		if($array) {
			foreach($array as $key=>$value) {
				if(is_array($value))  {
					$value=MakeStripSlashes($value);
					if($replaceValue==''&&$replaceValueTo=='')
						$array_temp[$key]=str_replace("#AMP#","",$value);
					else
						$array_temp[$key]=str_replace($replaceValue,$replaceValueTo,$value);                      
				} else {
					$array_temp[$key]=stripslashes(stripslashes($value));
				}	
			}    
		}   
		return $array_temp;   
	}

	function CheckDataExists($TableName,$ColumnName,$Value,$Field='',$Ident='') {
		if($TableName && $ColumnName && $Value)	
		{
			if($TableName && $ColumnName && $Ident)	
				$where = " Where ".$ColumnName ."  ='". addslashes($Value) . "' and ".$Field."!='".$Ident."'";
			else
				$where = " Where ".$ColumnName ." ='". addslashes($Value) . "'";
		}
		$strSql    = "Select Count(*) as Cnt from ".$TableName.$where;
		$Data  	   = SelectQry($strSql);
		return $Data[0][0];
	}
	
	function getRequestValues() {
		global $_GET,$_POST;
		return $_GET;
	}
	
	function RandomCode() {
		$randomcode	= strtolower(substr(md5(uniqid(rand(), true)),0,10));
		return $randomcode;
	}
	
	
	function RemoveNumericInArray($accoArray)	{
		foreach($accoArray as $key=>$value){
			if(is_numeric($key))
				unset($accoArray[$key]);
			$$key = $value;
			$value=stripslashes($value);
		}
		return $accoArray;
	}
			
	function createthumb($input_file_name, $output_filename, $new_w, $new_h='') {

		//print $input_file_name; exit;
	
		if (preg_match("/(jpg|jpeg|JPG)$/i",$input_file_name)){
			$src_img = imagecreatefromjpeg($input_file_name);
		} else if (preg_match("/png$/i",$input_file_name)){
			$src_img = imagecreatefrompng($input_file_name);
		} else if (preg_match("/gif$/i",$input_file_name)){
			$src_img = imagecreatefromgif($input_file_name);
		} else {
			throw new Exception("ERROR: Cant work with file $input_file_name becuase its an unsupported file type for this function.");
		}
	
		if( $src_img == false ) {
			throw(new Exception("ERROR: Unabel to open image file $input_file_name"));
		}
	
		$old_x = imageSX($src_img);
		$old_y = imageSY($src_img);
	
		if( $new_h == 0 ) {
			$thumb_w = $new_w;
					$thumb_h = $old_y * ($new_w / $old_x);
	
		} else if( $new_w == 0 ) {
			$thumb_h = $new_h;
					$thumb_w = $old_x * ($new_h / $old_y);
		} else {
			if ($old_x > $old_y) 	{
				$thumb_w = $new_w;
				$thumb_h = $old_y * ($new_h/$old_x);
			} else if ($old_x < $old_y) {
				$thumb_w = $old_x * ($new_w/$old_y);
				$thumb_h = $new_h;
			} else if ($old_x == $old_y) {
				$thumb_w = $new_w;
				$thumb_h = $new_h;
			}
		}
	
		$dst_img = @ImageCreateTrueColor($thumb_w,$thumb_h);
		@imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y); 
	
		if (preg_match("/png$/i",$input_file_name)){
			@imagepng($dst_img,$output_filename); 
		} elseif(preg_match("/gif$/i",$input_file_name)){
			@imagegif($dst_img,$output_filename); 
		} else {
			@imagejpeg($dst_img,$output_filename); 
		}
	
		@imagedestroy($dst_img); 
		@imagedestroy($src_img); 
	}
		
	function doPrintFieldValuesByPost($strFieldName){
		if(isset($_POST[$strFieldName])){
		   return $_POST[$strFieldName];
		}
	}
	
	function MakeStrip($value) {
			$Data 	= ltrim($value);	
			$Data 	= rtrim($Data);	
			$Data 	= strtolower($Data);	
			$array1 = array(" ","'",",","&","__","--","&amp;","  ","-amp;-","/");
			$array2 = array("-","","","","-","-","","-","-","");
			$Data 	= str_replace($array1,$array2,$Data);
			return $Data;
	}
	
	function GetAllRecordsValues($tbl_name,$fieldname,$start,$limit,$where='',$orderBy=''){
		if($start!='' || $limit!='')  {
			if($where!='') {
					$where= "WHERE $where ".$orderBy." LIMIT $start,$limit";
			} elseif($where=='') {
				   $where= "WHERE ".$orderBy." LIMIT $start,$limit";
				} 
		}		
		$sql="SELECT ".$fieldname." FROM ".$tbl_name."  $where";
		$strUser=SelectQry($sql);
		return $strUser;
	}

	function doUnlinkImage($objArray,$tbl_name,$fieldName,$filePath){
		$destpath	=  $filePath;
		$thumbpath  =  $destpath.'thumb/';
		$normalPath =  $destpath.'normal/';
		$filename = $objArray['strImage'];
		if($filename!=''){
			@unlink($destpath.$filename);
			@unlink($thumbpath.$filename);
			@unlink($normalPath.$filename);
		}
		updateImageStatus($objArray['strDeleteId'],$tbl_name,$fieldName,'');
		return true;
	}
	function GetTotalValuescount($tbl_name) {
		$sql = "select Id from ".$tbl_name." where IsDeleted='No'";
		$strResult = SelectQry($sql);
		return count($strResult);
	}
	function doUploadImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$normalWidth='',$mediumWidth='',$thumbWidth='') {
		global $global_config, $table_config;
		//print $ident;
		$file = $fileArray["file_File"]["tmp_name"];
		$destpath	=  $strFilePath;
		
		$normalpath  =  $destpath.'normal/';
		$mediumpath  =  $destpath.'medium/';
		$thumbpath   =  $destpath.'thumb/';
		if($file!=''){
			$filename = $fileArray["file_File"]["name"];
			$fileExt = substr($filename,-4,4);
			$DBFilename = substr($filename,0,-4);
			//$filename=strtolower(str_replace(' ','-',$DBFilename)).date('YmdHis').$fileExt;
			$filename=date('YmdHis').$fileExt;
			if($filename!=''){
				@unlink($destpath.$filename);
				@unlink($thumbpath.$filename);
				@unlink($normalpath.$filename);
				@unlink($mediumpath.$filename);
			}
			copy($file,$destpath.$filename);
			
			$strImageProperties = getimagesize($file);
			if($strImageProperties[0]>=$strImageProperties[1]) {
				if($normalWidth != ''){
					if($strImageProperties[0]>$normalWidth){
						createthumb($destpath.$filename,$normalpath.$filename,$normalWidth,"");	
					}else{
						copy($file,$normalpath.$filename);
					}
				}
				if($mediumWidth != ''){
					if($strImageProperties[0]>$mediumWidth){
						createthumb($destpath.$filename,$mediumpath.$filename,$mediumWidth,"");
					}else{
						copy($file,$mediumpath.$filename);
					}	
				}
				if($thumbWidth != ''){
					if($strImageProperties[0]>$thumbWidth){
						createthumb($destpath.$filename,$thumbpath.$filename,$thumbWidth,"");	
					}else{
						copy($file,$thumbpath.$filename);
					}
				}			
			}
			updateImageStatus($ident,$tblName,$strFieldName,$filename);
		}
	}
	function doUploadInnerImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$normalWidth='',$normalHeight='',$mediumWidth='',$thumbWidth='',$cropWidth='',$cropHeight='') {
		global $global_config, $table_config;
		$file = $fileArray["file_File"]["tmp_name"];
		$destpath	=  $strFilePath;
		
		$normalpath  =  $destpath.'normal/';
		$mediumpath  =  $destpath.'medium/';
		$thumbpath   =  $destpath.'thumb/';
		$croppath    =  $destpath.'crop/';
		if($file!=''){
			$filename = $fileArray["file_File"]["name"];
			$fileExt = substr($filename,-4,4);
			$DBFilename = substr($filename,0,-4);
			//$filename=strtotime(date('Y-m-d H:i:s a')).$fileExt;
			if($thumbpath){
				$filename='thumb_'.date('YmdHis').$fileExt;
			} elseif($croppath){
				$filename='crop_'.date('YmdHis').$fileExt;
			} else {
				$filename=date('YmdHis').$fileExt;
			}
			if($filename!=''){
				@unlink($destpath.$filename);
				@unlink($thumbpath.$filename);
				@unlink($normalpath.$filename);
				@unlink($mediumpath.$filename);
				@unlink($croppath.$filename);
			}
			copy($file,$destpath.$filename);
			
			$strImageProperties = getimagesize($file);
				if($normalWidth != ''){
					if($strImageProperties[0]>$normalWidth){
						CreateCropp($destpath.$filename,$normalpath.$filename,$normalWidth,$normalHeight);	
					}else{
						copy($file,$normalpath.$filename);
					}
				}
				if($mediumWidth != ''){
					if($strImageProperties[0]>$mediumWidth){
						createthumb($destpath.$filename,$mediumpath.$filename,$mediumWidth,"");
					}else{
						copy($file,$mediumpath.$filename);
					}	
				}
				if($thumbWidth != ''){
					if($strImageProperties[0]>$thumbWidth){
						createthumb($destpath.$filename,$thumbpath.$filename,$thumbWidth,"");	
					}else{
						copy($file,$thumbpath.$filename);
					}
				}	
				if($cropWidth != ''){
					if($strImageProperties[0]>$cropWidth){
						CreateCropp($destpath.$filename,$croppath.$filename,$cropWidth,$cropHeight);	
					}else{
						copy($file,$croppath.$filename);
					}
				}			
			updateImageStatus($ident,$tblName,$strFieldName,$filename);
		}
	}
	
	function GetValuesByKey($tbl_name,$field,$start,$limit,$key){
		if($start!='' || $limit!='')
			$limits = 'limit '.$start.','.$limit;
		$sql="SELECT * from ".$tbl_name." where IsDeleted='No' and ".$field." like '%".$key."%'  ".$limits; 
		$result=SelectQry($sql);
		return count($result);
	}
	function GetRecordsValuesById($tbl_name,$Id){
		$sql="SELECT * from ".$tbl_name." where Id='".$Id."'"; 
		$result=SelectQry($sql);
		return $result[0];
	}
	function getServiceBySubMenuId($tbl_name) {
		$sql="SELECT Id,PageTitle,Parent FROM ".$tbl_name." WHERE IsDeleted='No' AND Submenu='Yes' AND  Published='Yes' AND Parent='2'";
		$strServiceIdArray=SelectQry($sql);
		return $strServiceIdArray;
	}
	
	function doUpdateRecordsByMultiselect($SectionArray,$Action,$tbl_name,$strFilePath,$field,$uploadfolder) {
		global $table_config;
		if(!empty($strFilePath)) { $filePath = $strFilePath; } else { $strFilePath=''; }
		if(!empty($field)) { $strField = $field; } else { $strField=''; }
		if(!empty($uploadfolder)) { $strUploadfolder = $uploadfolder; } else { $strUploadfolder=''; }
		if($Action=='delete') {
			for($i=0;$i<count($SectionArray);$i++) {
				doDeleteRecord($SectionArray[$i],$tbl_name,$filePath,$strField,$strUploadfolder);
			}
			return 3;
		}else{
			for($i=0;$i<count($SectionArray);$i++) {
				doSetPublishType($SectionArray[$i],$tbl_name,$Action);
			}
			if($Action == 'UnPublish') {
				return 1;
			} else {
				return 2;
			}
		}
	}
	function doUpdateRecordsByMultiselectNew($SectionArray,$Action,$tbl_name,$strImageField='',$filepath='', $strDeleteImages='', $WhereField='') {
		global $table_config,$global_config;
		if($Action=='delete') {
			for($i=0;$i<count($SectionArray);$i++) {
				$where ='';
				if($WhereField!='') {
					$where =" WHERE ".$WhereField."='".$SectionArray[$i]."' ";
				}
				if($strDeleteImages=='Yes') {
					$strImages =  getImageNameById($strImageField,$SectionArray[$i],$tbl_name);	
		 	    	doDeleteListingImages($global_config["SiteLocalUploadPath"],$strImages[$strImageField], $filepath);
				} 
				doDeleteRecord($SectionArray[$i],$tbl_name,$where);
			}
			return 3;
		}else if($Action=='Publish'){
			for($i=0;$i<count($SectionArray);$i++) {
				updateSectionRecord($SectionArray[$i],$tbl_name,'Yes');
			}
			return 2;
		} else {
			for($i=0;$i<count($SectionArray);$i++) {
				updateSectionRecord($SectionArray[$i],$tbl_name,'No');
			}
			return 1;
		}
		
	}
	
	function updateRecords($tableName,$updateFields,$whereClause=''){
		if(is_array($updateFields)){
			$updateSet = array();
			foreach($updateFields as $key=> $values){
				$updateSet[]= $key."='".$values."'";
			}
			$toUpdate = ' SET '.implode(',',$updateSet);
		}
		$sql = "UPDATE ".$tableName.$toUpdate.$whereClause;
		ExecuteQry($sql);
	}

	function updateImageStatus($Id,$tbl_name,$fieldName,$strFieldValue=''){
		global $table_config;
		$sql = "UPDATE ".$tbl_name." SET ".$fieldName." = '".$strFieldValue."' WHERE Id='".$Id."'";
		ExecuteQry($sql);
	}
	function doSetPublishType($articleId,$tbl_name,$Action) {
		//print $tbl_name."  ".$articleId. " ".$Action; exit;
		$strPublishState = getPublishState($articleId,$tbl_name);
		if($Action=='Publish')
			$State = 'Yes';
		if($Action=='UnPublish')
			$State = 'No';
		if($Action=='') {
			if($strPublishState == 'Yes') {
				$State = 'No';
			} else {
				$State = 'Yes';
			}
		} 
		
		UpdatePublishState($tbl_name,$State,$articleId);
	}
	function getPublishState($articleId,$tbl_name) {
		$sql="SELECT Published FROM ".$tbl_name." WHERE Id='".$articleId."'";
		$result=SelectQry($sql);
		return $result[0]['Published'];	
	}
	function UpdatePublishState($tbl_name,$State,$articleId) {
		$sql = "UPDATE ".$tbl_name." SET Published='$State' WHERE Id='".$articleId."'"; 	
		ExecuteQry($sql);
	}
	function doDeleteRecord($strDeleteId,$tbl_name,$strFilePath='',$field='',$uploadfolder=''){
		 global $table_config;
		 if(!empty($strFilePath) && !empty($field) && !empty($uploadfolder)) {
		 	if($uploadfolder == 'gallery') {
				$query="SELECT ImageName FROM ".$table_config['gallery_images']." WHERE GalleryID=".$strDeleteId."";
				$galleryImages = SelectQry($query);
				if(!empty($galleryImages)) {
					foreach($galleryImages as $galleryImage) {
						$galleryImage = $galleryImage['ImageName'];
						doDeleteListingImages($strFilePath,$galleryImage,$uploadfolder);
					}
					$sql="DELETE FROM ".$table_config['gallery_images']." WHERE GalleryID='".$strDeleteId."'";
					ExecuteQry($sql);
				}
			} else if($uploadfolder == 'multiple') {
				$query="SELECT ImageName FROM ".$table_config['gallery_multiple_images']." WHERE GalleryID=".$strDeleteId."";
				$galleryImages = SelectQry($query);
				if(!empty($galleryImages)) {
					foreach($galleryImages as $galleryImage) {
						$galleryImage = $galleryImage['ImageName'];
						doDeleteListingImages($strFilePath,$galleryImage,$uploadfolder."/images");
					}
					$sql="DELETE FROM ".$table_config['gallery_multiple_images']." WHERE GalleryID='".$strDeleteId."'";
					ExecuteQry($sql);
				}
			} else if($uploadfolder == 'video') {
				$sql = "SELECT * FROM ".$table_config["assignvideo"]." WHERE FIND_IN_SET('".$strDeleteId."',VideoIds) AND IsDeleted='No'";		
				$resultArray = SelectQry($sql);	
				if(is_array($resultArray)) {
					foreach($resultArray as $result) {
						if(strstr($result['VideoIds'], ',')) {
							$explode = explode(',',$result['VideoIds']);
							if(in_array($strDeleteId,$explode)) {
								$removeVideoId = str_replace($strDeleteId,'',$explode);
								if(!empty($removeVideoId)) {
									$videoIds = implode(',',array_filter($removeVideoId));
								}
							}
							$sql = "UPDATE ".$table_config["assignvideo"]." SET VideoIds ='".$videoIds."' WHERE VideoIds='".$result['VideoIds']."'";
							ExecuteQry($sql);
						} else {
							$sql = "DELETE FROM ".$table_config["assignvideo"]." WHERE VideoIds='".$result['VideoIds']."'";
							ExecuteQry($sql);
						}				
					}
				}
				$strImage = getImageNameById($field, $strDeleteId, $tbl_name);
		 		doDeleteListingImages($strFilePath,$strImage[$field],$uploadfolder);
			} else {
		  		$strImage = getImageNameById($field, $strDeleteId, $tbl_name);
		 		doDeleteListingImages($strFilePath,$strImage[$field],$uploadfolder);
			}
		 }
		 $sql="DELETE FROM ".$tbl_name." WHERE Id='".$strDeleteId."'";
		 ExecuteQry($sql);		 
		 return true;
	}
	function doDeleteImage($strID,$table_name){
		$strUpdateQry = "UPDATE ".$table_name." SET Image='' WHERE Id = '".$strID."'";
		ExecuteQry($strUpdateQry);
		return 1;
	}
	function doDeleteListingImages($strFilePath,$filename,$strUploadFolder='') {

		if($strUploadFolder !=""){
			$destpath    =  $strFilePath.$strUploadFolder.'/';
		} else {			
			$destpath    =  $strFilePath;
		}
		//echo $filename."<br />";
		//echo $destpath.$filename;exit;
				
		$normalpath = $destpath.'normal/';
		$originalpath = $destpath.'original/';
		$smallpath = $destpath.'small/';
		$thumbpath = $destpath.'thumb/';
		$mediumbpath = $destpath.'medium/';
		$multiimgpath = $destpath.'images/';		
		$multiimgnormalpath = $multiimgpath.'normal/';
		$multiimgsmallpath  = $multiimgpath.'small/';
		$multiimgthumbpath  = $multiimgpath.'thumb/';
		
		if($filename!=''){
			if(file_exists($destpath.$filename)) { @unlink($destpath.$filename); }
			if(file_exists($smallpath.$filename)) { @unlink($smallpath.$filename); }
			if(file_exists($originalpath.$filename)) { @unlink($originalpath.$filename); }
			if(file_exists($thumbpath.$filename)) { @unlink($thumbpath.$filename); }
			if(file_exists($normalpath.$filename)) { @unlink($normalpath.$filename); }
			if(file_exists($mediumbpath.$filename)) { @unlink($mediumbpath.$filename); }
			if(file_exists($multiimgpath.$filename)) { @unlink($multiimgpath.$filename); }
			if(file_exists($multiimgnormalpath.$filename)) { @unlink($multiimgnormalpath.$filename); }
			if(file_exists($multiimgsmallpath.$filename)) { @unlink($multiimgsmallpath.$filename); }
			if(file_exists($multiimgthumbpath.$filename)) { @unlink($multiimgthumbpath.$filename); }
		}
	}
	function checkLogin(){
		if(!isset($_SESSION["demo"]['userid'])){
			Redirect(SITEGLOBALADMINPATH."index.php");
		} 
	}
	function getImageNameById($strField, $strId, $tbl_name){
		$sql="SELECT ".$strField." FROM ".$tbl_name." WHERE Id=".$strId."";
		
		//echo $sql;exit;
		$result=SelectQry($sql);
		return $result[0];
	}
	function getExtension($str) {
		 $i = strrpos($str,".");
		 if (!$i) { return ""; } 
	
		 $l = strlen($str) - $i;
		 $ext = substr($str,$i+1,$l);
		 return $ext;
	 }
	 
	 function doSubmitAction($objArray,$table_name,$strFilePath='',$field='',$uploadfolder='') {
	 	if(!empty($strFilePath)) { $filePath = $strFilePath; } else { $strFilePath=''; }
		if(!empty($field)) { $strField = $field; } else { $strField=''; }
		if(!empty($uploadfolder)) { $strUploadfolder = $uploadfolder; } else { $strUploadfolder=''; }
	 	$strResult = doUpdateRecordsByMultiselect($objArray['frmCheck'],$objArray['SubmitAction'],$table_name,$filePath,$strField,$strUploadfolder);
		if($strResult==1) {
			$strMessage['message']="Selected Record(s) UnPublished Successfully";
			$strMessage['class']="success";
		}
		if($strResult==2) {
			$strMessage['message']="Selected Record(s) Published Successfully";
			$strMessage['class']="success";
		}
		if($strResult==3) {
			$strMessage['message']="Selected Record(s) deleted Successfully";
			$strMessage['class']="success";
		}
		return $strMessage;
	 }
	 
	 function doSetMessage($action,$value='') {
	 	if($action == 'SetFrontPage') {
			$strMessage['message']="Front Page Changed Successfully";
			$strMessage['class']="success";
		}
		if($action == 'SetPublish') {
			$strMessage['message']="Selected Record(s)'s Details Changed Successfully";
			$strMessage['class']="success";
		}
		if($action == 'PageAction' && $value == 'delete') {
		   $strMessage['message']="Record deleted successfully";
		   $strMessage['class']="success";
		}
		if($action == 'PageAction' && $value == 'ChangeImagePosition') {
			$strMessage['message'] = "Record position changed successfully";
	   		$strMessage['class'] = "success";
		}
		
		/*
		switch() {
		}
		*/
		
		return $strMessage;
	 }
	 
	function GetTotalRecordsCount($tbl_name1,$where,$tbl_name2=''){
		if(!empty($tbl_name2)) {
			$sql="SELECT * FROM ".$tbl_name1.", ".$tbl_name2." WHERE $where";
		} else {
			$sql="SELECT * FROM ".$tbl_name1." WHERE $where";
		}
		
		$strSectionCount=SelectQry($sql);
 		return count($strSectionCount);
	}
	
	function getListStatus($arrList,$i) {
		if($i&1==1){
			$arr['class']="alternate";
		}else{
			$arr['class']="none";
		}
		
		if($arrList[$i]['Published']=="Yes"){
			$arr['publish_image'] = SITEADMINIMAGEPATH."publish_g.png";
			$arr['alter'] = 'Published';
		}elseif($arrList[$i]['Published']=="No"){
			$arr['publish_image'] = SITEADMINIMAGEPATH."publish_x.png";
			$arr['alter'] = 'UnPublished';
		}
		
		$arr['nextID'] = $arrList[$i+1]['Ident'];
		$arr['prevID'] = $arrList[$i-1]['Ident'];
		$arr['nextIDPosition'] = $arrList[$i+1]['Position'];
		$arr['prevIDPosition'] = $arrList[$i-1]['Position'];
		
		return $arr;
	}	
	/* JSON API code */
	function showJsonResults($arr) {
		echo array21json($arr);
	}	
	function showJsonResults1($arr) {
		$key = '{ "Listing": [ { ';
		echo '"' . $key . '":'.array21json($arr).'} ] }';
	}
	function array21json($arr) {
			$parts = array();
			$is_list = false;   
			//Find out if the given array is a numerical array
			$keys = array_keys($arr);
			$max_length = count($arr)-1;
			if($arr) {
				if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {
					//See if the first key is 0 and last key is length - 1
					$is_list = true;
					for($i=0; $i<count($keys); $i++) {
						//See if each key correspondes to its position                  
						if($i != $keys[$i]) { //A key fails at position check.
							$is_list = false; //It is an associative array.
							break;
					   }
				   }
				}
			}
			
			foreach($arr as $key=>$value) {
				if(is_array($value)) {
					//Custom handling for arrays
					if($is_list) $parts[] = array21json($value); /* :RECURSION: */
					else $parts[] = '"' . $key . '":' . array21json($value); /* :RECURSION: */
				} else {
					$str = '';
					if(!$is_list) $str = '"' . $key . '":';
							   //Custom handling for multiple data types
					if(is_numeric($value)) $str .= $value; //Numbers
					elseif($value === false) $str .= 'false'; //The booleans
					elseif($value === true) $str .= 'true';
					else $str .= '"' . $value . '"'; //All other things
					// :TODO: Is there any more datatype we should be in the lookout for? (Object?)
					$parts[] = $str;
			   }
			}
			
			$json = implode(',',$parts);

			if($is_list) return  '[' . $json . ']';//Return associative JSON
			return  '{' . $json . '}';//Return associative JSON
	} 
   	function displayResult($objArray,$cat) {
		ob_clean();	
		$json_result = array2json1Meta($objArray,0); 
		$json_result = str_replace("\n","<br />",$json_result);
		$json_result = str_replace('\u000d',"<br />",$json_result);
		print '{"'.$cat.'":'.stripslashes($json_result).'}';
		exit;
	}
 	function displayResultAllPost($objArray,$sJson) {
		ob_clean();	
		$json_result = array2json2($objArray,0);	
		print stripslashes('{"'.$sJson.'":'.$json_result.'}');	exit;
	}
 	function displayResult3($objArray, $sJson, $numerkeyneed=true) {
		ob_clean();	
		$json_result = array2json3($objArray, $numerkeyneed); printArray($json_result); exit;
		print stripslashes('{"'.$sJson.'":'.$json_result.'}');	exit;
		//print '{"sickness":'.stripslashes($json_result).'}';	
	}
	
	/*function printArray($objArray){
		print "<pre>";
		print_r($objArray);
		print "</pre>";
	}*/
	
	function array2json1Meta($arr) { 
			$parts = array(); 
			$is_list = false; 
		
			$keys = array_keys($arr); 
			$max_length = count($arr)-1; 
			if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {
				$is_list = true; 
				for($i=0; $i<count($keys); $i++) { 
					if($i != $keys[$i]) { 
						$is_list = false; 
						break; 
					} 
				} 
			}   
		
			foreach($arr as $key=>$value) { 
				if(is_array($value)) { 
					if($is_list) $parts[] = array2json($value); 
					else $parts[] = '"' . $key . '":' . array2json($value); 
	
				} else { 
					$str = ''; 
					if(!$is_list) $str = '"' . $key . '":'; 
		
					if(is_numeric($value)) $str .= '"' . addslashes($value) . '"'; 
					elseif($value === false) $str .= 'false'; 
					elseif($value === true) $str .= 'true'; 
					else $str .= '"' . addslashes($value) . '"'; 
		
					$parts[] = $str; 
				}
			}
			$json = implode(',',$parts);
			 
			if($is_list) return '[' . $json . ']';
			return '{' . $json . '}';
	} 
	
	function array2jsonBK($arr) { 
			$parts = array(); 
			$is_list = false; 
		
			$keys = array_keys($arr); 
			$max_length = count($arr)-1; 
			if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {
				$is_list = true; 
				for($i=0; $i<count($keys); $i++) { 
					if($i != $keys[$i]) { 
						$is_list = false; 
						break; 
					} 
				} 
			}   
			foreach($arr as $key=>$value) { 
				if(is_array($value)) { 
					if($is_list) $parts[] = array2json($value); 
					else $parts[] = '"' . $key . '":' . array2json($value); 
				} else { 
					$str = ''; 
					if(!$is_list) $str = '"' . $key . '":'; 
		
					if(is_numeric($value) ) $str  .= $value; 
					elseif($value === false) $str .= 'false'; 
					elseif($value === true) $str  .= 'true'; 
					else $str .= '"' . addslashes($value) . '"'; 
					$parts[] = $str; 
				}
			}
			$json = implode(',',$parts);
			 
			if($is_list) return '[' . $json . ']';
			return '{' . $json . '}';
	} 
	
	function array2json($arr) {
		//if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality.
		$parts = array();
		$is_list = false;
	
		//Find out if the given array is a numerical array
		$keys = array_keys($arr);
		$max_length = count($arr)-1;
		if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1
			$is_list = true;
			for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position
				if($i != $keys[$i]) { //A key fails at position check.
					$is_list = false; //It is an associative array.
					break;
				}
			}
		} 
	
		foreach($arr as $key=>$value) {
			if(is_array($value)) { //Custom handling for arrays
				if($is_list) $parts[] = array2json($value); /* :RECURSION: */
				else $parts[] = '"' . $key . '":' . array2json($value); /* :RECURSION: */
			} else {
				$str = '';
				if(!$is_list) $str = '"' . $key . '":';
				//Custom handling for multiple data types
				if(is_numeric($value) && strlen($value)==1) $str .= '"'.$value.'"'; //Numbers
				elseif($value === false) $str .= 'false'; //The booleans
				elseif($value === true) $str .= 'true';
				else $str .= '"' . addslashes($value) . '"'; //All other things
				// :TODO: Is there any more datatype we should be in the lookout for? (Object?)
				$parts[] = $str;
			}
		}
		$json = implode(',',$parts);
		
		if($is_list) return '[' . $json . ']';//Return numerical JSON
		return '{' . $json . '}';//Return associative JSON
	} 	
	
	function array2json1($arr, $val) {
		//if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality.
		$parts = array();
		$is_list = false;
		//Find out if the given array is a numerical array	
		
		$keys = array_keys($arr);
		if($val==2)
			$max_length = count($arr)-1;
		else
			$max_length = count($arr);
		$val++;
		if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1
			$is_list = true;
			for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position
				if($i != $keys[$i]) { //A key fails at position check.
					$is_list = false; //It is an associative array.
					break;
				}
			}
		}
		foreach($arr as $key=>$value) {
			if(is_array($value)) { //Custom handling for arrays
				if($is_list) $parts[] = array2json($value, $val); /* :RECURSION: */
				else $parts[] = '"' . $key . '":' . array2json($value, $val); /* :RECURSION: */
			} else {
				$str = '';
				if(!$is_list) $str = '"' . $key . '":';
				//Custom handling for multiple data types
				//if(is_numeric($value)) $str .= '"'.$value.'"'; //Numbers
				if(is_numeric($value) && strlen($value)==1) $str .= '"'.$value.'"'; //Numbers
				elseif($value === false) $str .= 'false'; //The booleans
				elseif($value === true) $str .= 'true';
				else $str .= '"' . addslashes($value) . '"'; //All other things
				// :TODO: Is there any more datatype we should be in the lookout for? (Object?)
				$parts[] = $str;
			}
		}
		$json = implode(',',$parts);
		if($is_list) return '[' . $json . ']';//Return numerical JSON
		return '{' . $json . '}';//Return associative JSON
	}
	
	function array2json2($arr, $val) {
		$parts = array();
		$is_list = false;
		//Find out if the given array is a numerical array
		$keys = array_keys($arr);
		//$keys = array_keys($arr);
		//printArray($keys);exit;
		if($val==2)

			$max_length = count($arr)-1;
		else
			$max_length = count($arr);
		$val++;
		if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1
			$is_list = true;
			for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position
				if($i != $keys[$i]) { //A key fails at position check.
					$is_list = false; //It is an associative array.
					break;
				}
			}
		}
	
		foreach($arr as $key=>$value) {
			if(is_array($value)) { //Custom handling for arrays
				if($is_list) $parts[] = array2json2($value, $val); /* :RECURSION: */
				else $parts[] = '"' . $key . '":' . array2json2($value, $val); /* :RECURSION: */
			} else {
				$str = '';
				if(!$is_list) $str = '"' . $key . '":';
				//Custom handling for multiple data types
				if(is_numeric($value) && strlen($value)==1) $str .= '"'.$value.'"'; //Numbers
				elseif($value === false) $str .= 'false'; //The booleans
				elseif($value === true) $str .= 'true';
				else $str .= '"' . addslashes($value) . '"'; //All other things
				// :TODO: Is there any more datatype we should be in the lookout for? (Object?)
				$parts[] = $str;
			}
		} //printArray($is_list); exit;
		$json = implode(',',$parts);
		if($is_list) return '[' . $json . ']';//Return numerical JSON
		//else return '[' . $json . ']';
		return '{' . $json . '}';//Return associative JSON
	}
	
	// CONVERT THE VALUES ARRAY TO JSON - 3 ARGUMENTS
	function array2json3($arr, $numerkeyneed = true, $arrayval = false) {
		$parts = array();
			$is_list = false;
		
			//Find out if the given array is a numerical array
			$keys = array_keys($arr);
			//if($numerkeyneed)
				$max_length = count($arr);
			//else
				//$max_length = count($arr)-1;
			if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1
				$is_list = true;
				for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position
					if($i != $keys[$i]) { //A key fails at position check.
						$is_list = false; //It is an associative array.
						break;
					}
				}
			} 
			foreach($arr as $key=>$value) {
				if(is_array($value)) { //Custom handling for arrays
					if($is_list) $parts[] = array2json($value, $numerkeyneed); /* :RECURSION: */
					else {
						if($numerkeyneed)
							$parts[] = '"' . $key . '":' . array2json($value, $numerkeyneed); /* :RECURSION: */
						else if(is_string($key))
							$parts[] = '"' . $key . '":' . array2json($value, $numerkeyneed, true); /* :RECURSION: */
						else
							$parts[] = array2json($value, $numerkeyneed); /* :RECURSION: */
					}
				} else {
					$str = '';
					if(!$is_list) $str = '"' . $key . '":';
		
					//Custom handling for multiple data types
					if(is_numeric($value) && strlen($value)==1) $str .= $value; //Numbers
					elseif($value === false) $str .= 'false'; //The booleans
					elseif($value === true) $str .= 'true';
					else $str .= '"' . addslashes($value) . '"'; //All other things
					// :TODO: Is there any more datatype we should be in the lookout for? (Object?)
		
					$parts[] = $str;
				}
			}
			$json = implode(',',$parts);
			// echo "<br>";
			if($is_list || $arrayval) return '[' . $json . ']';//Return numerical JSON
			return '{' . $json . '}';//Return associative JSON
	}
	 	
		// REPLACE NEW LINE
	function replace($cnt){
		$cnt = str_replace('"', "'", $cnt);
		//$cnt = str_replace("\n","",$cnt);
		$cnt = str_replace("\r","",$cnt);
		$cnt = str_replace(">	<","><",$cnt);
		$cnt = str_replace(">  <","><",$cnt);
		$cnt = str_replace(">	<","><",$cnt);
		$cnt = str_replace(">    <","><",$cnt);
		$cnt = str_replace(">	<","><",$cnt);
		$cnt = str_replace(">	<","><",$cnt);
		$cnt = trim($cnt);	
		return $cnt;
	}
	function htmlallentities($str){
	  $res = '';
	  $strlen = strlen($str);
	  for($i=0; $i<$strlen; $i++){
		$byte = ord($str[$i]);
		if($byte < 128) // 1-byte char
		  $res .= $str[$i];
		elseif($byte < 192); // invalid utf8
		elseif($byte < 224) // 2-byte char
		  $res .= '&#'.((63&$byte)*64 + (63&ord($str[++$i]))).';';
		elseif($byte < 240) // 3-byte char
		  $res .= '&#'.((15&$byte)*4096 + (63&ord($str[++$i]))*64 + (63&ord($str[++$i]))).';';
		elseif($byte < 248) // 4-byte char
		  $res .= '&#'.((15&$byte)*262144 + (63&ord($str[++$i]))*4096 + (63&ord($str[++$i]))*64 + (63&ord($str[++$i]))).';';
	  }
	  return $res;
	}

	function doStripContent($sContent){
		$sContent					= str_replace(array("\t","\r","  ",'/n'),"",$sContent);
		$sContent					= stripslashes($sContent);	
		$sContent					= preg_replace('#(<[/]?img.*>)#U', '', $sContent);
		$sContent					= str_replace(']]>', ']]&gt;', $sContent);
		$sContent					= str_replace('&#8217;', "'", $sContent);
		$sContent					= str_replace('"', "&rdquo;", $sContent);
		$sContent					= strip_tags($sContent);	
		return $sContent;
	}
	function get_youtube($url){
		$JSON = file_get_contents("https://gdata.youtube.com/feeds/api/videos/".$url."?v=2&alt=json");
		$JSON_Data = json_decode($JSON);
		$views = $JSON_Data->{'entry'}->{'yt$statistics'}->{'viewCount'};
		return $JSON_Data->{'entry'};
   }
	function CreateCropp($sourceFile,$destinationFile,$newwidth,$newheight){
		 define ("MAX_SIZE","400");
		 $errors=0;
		 if($_SERVER["REQUEST_METHOD"] == "POST"){
			$image = $destinationFile;
			$uploadedfile = $sourceFile;
		  if ($image){
			  $filename = stripslashes($destinationFile);
			   $extension = getExtension($filename);
			  $extension = strtolower($extension);
			 if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
				echo ' Unknown Image extension ';
				$errors=1;
			 } else	{
			   $size=filesize($sourceFile);
				if($extension=="jpg" || $extension=="jpeg" ){
					$uploadedfile = $sourceFile;
					$src = imagecreatefromjpeg($uploadedfile);
				} else if($extension=="png") {
					$uploadedfile = $sourceFile;
					$src = imagecreatefrompng($uploadedfile);
				} else {
					$src = imagecreatefromgif($uploadedfile);
				}
				list($width,$height)=getimagesize($uploadedfile);
				//$newheight=($height/$width)*$newwidth;
				@$tmp=imagecreatetruecolor($newwidth,$newheight);
				@imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
				$filename = $destinationFile;
				copy($sourceFile,$destinationFile);
				@imagejpeg($tmp,$filename,100);
				@imagedestroy($src);
				@imagedestroy($tmp);
				}
			}
		}
	}

	function displayResultWindows($objArray) {
		ob_clean();	
		$json_result = array2json1MetaWindows($objArray,0); 
		$json_result = str_replace("\n","<br />",$json_result);
		$json_result = str_replace('\u000d',"<br />",$json_result);
		print stripslashes($json_result);
		exit;
	}
	
	function array2json1MetaWindows($arr) { 
		$parts = array(); 
		$is_list = false; 
		$keys = array_keys($arr); 
		$max_length = count($arr)-1; 
		if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {
			$is_list = true; 
			for($i=0; $i<count($keys); $i++) { 
				if($i != $keys[$i]) { 
					$is_list = false; 
					break; 
				} 
			} 
		}   
		foreach($arr as $key=>$value) { 
			if(is_array($value)) { 
				if($is_list) $parts[] = array2json($value); 
				else $parts[] = '"' . $key . '":' . array2json($value); 
			} else { 
				$str = ''; 
				if(!$is_list) $str = '"' . $key . '":'; 
				if(is_numeric($value)) $str .= '"' . addslashes($value) . '"'; 
				elseif($value === false) $str .= 'false'; 
				elseif($value === true) $str .= 'true'; 
				else $str .= '"' . addslashes($value) . '"'; 
				$parts[] = $str; 
			}
		}
		$json = implode(',',$parts);
		if($is_list) return '[' . $json . ']';
		return '{' . $json . '}';
	} 
	function get_youtubeVideos($url){
		$JSON = file_get_contents("https://gdata.youtube.com/feeds/api/playlists/".$url."?v=2&alt=json");
		$JSON_Data = json_decode($JSON);
		$res       = $JSON_Data->feed->entry;
		return $res;

   }
   
   	function displayResultWindowsByParms($parms,$objArray) {

		ob_clean();	

		$json_result = array2json1MetaWindowsByParms($parms,$objArray,0); 

		$json_result = str_replace("\n","<br />",$json_result);

		$json_result = str_replace('\u000d',"<br />",$json_result);

		print stripslashes($json_result);

		exit;

	}



	



	function array2json1MetaWindowsByParms($parms,$arr) { 



			$parts = array(); 



			$is_list = false; 



			$keys = array_keys($arr); 



			$max_length = count($arr)-1; 



			if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {



				$is_list = true; 



				for($i=0; $i<count($keys); $i++) { 



					if($i != $keys[$i]) { 



						$is_list = false; 



						break; 



					} 



				} 



			}   



			foreach($arr as $key=>$value) { 



				if(is_array($value)) { 



					if($is_list) $parts[] = array2jsonWin($value); 



					else $parts[] = '"' . $key . '":' . array2json($value); 



				} else { 



					$str = ''; 



					if(!$is_list) $str = '"' . $key . '":'; 



					if(is_numeric($value)) $str .= '"' . addslashes($value) . '"'; 



					elseif($value === false) $str .= 'false'; 



					elseif($value === true) $str .= 'true'; 



					else $str .= '"' . addslashes($value) . '"'; 



					$parts[] = $str; 



				}



			}



			$json = implode(',',$parts);

			if($parms==0){

				if($is_list) return '[' . $json . ']';

			} else {

				if($is_list) return $json;

			}



			return '{' . $json . '}';



	} 
	
	function array2jsonWin($arr) {

		//if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality.

		$parts = array();

		$is_list = false;

	

		//Find out if the given array is a numerical array

		$keys = array_keys($arr);

		$max_length = count($arr)-1;

		if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1

			$is_list = true;

			for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position

				if($i != $keys[$i]) { //A key fails at position check.

					$is_list = false; //It is an associative array.

					break;

				}

			}

		} 

	

		foreach($arr as $key=>$value) {

			if(is_array($value)) { //Custom handling for arrays

				if($is_list) $parts[] = array2jsonWin($value); /* :RECURSION: */

				else $parts[] = '"' . $key . '":' . array2jsonWin($value); /* :RECURSION: */

			} else {

				$str = '';

				if(!$is_list) $str = '"' . $key . '":';

				//Custom handling for multiple data types

				if(is_numeric($value) && strlen($value)==1) $str .= '"'.$value.'"'; //Numbers

				elseif($value === false) $str .= 'false'; //The booleans

				elseif($value === true) $str .= 'true';

				elseif($value == 'null') $str .= '';

				else $str .= '"' . addslashes($value) . '"'; //All other things

				// :TODO: Is there any more datatype we should be in the lookout for? (Object?)

				$parts[] = $str;

			}

		}

		$json = implode(',',$parts);

		

		if($is_list) return '[' . $json . ']';//Return numerical JSON

		return '{' . $json . '}';//Return associative JSON

	} 	
	
	function doUploadDesignImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName) {
		global $global_config, $table_config;
		$file = $fileArray["file_File"]["tmp_name"];
		$destpath	=  $strFilePath;
		if($file!=''){
			$filename = $fileArray["file_File"]["name"];
			$fileExt = substr($filename,-4,4);
			$DBFilename = substr($filename,0,-4);
			$filename=date('YmdHis').$fileExt;
			if($filename!=''){
				@unlink($destpath.$filename);
			}
			copy($file,$destpath.$filename);
			$strImageProperties = getimagesize($file);
			updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);
		}
	}
	
	function doUploadInnerThumbImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$thumbWidth='',$thumbHeight='') {
		global $global_config, $table_config;
		$file = $fileArray["file_File1"]["tmp_name"];
		$destpath	=  $strFilePath;
		$thumbpath   =  $destpath.'thumb/';
		if($file!=''){
			$filename = $fileArray["file_File1"]["name"];
			$fileExt = substr($filename,-4,4);
			$DBFilename = substr($filename,0,-4);
			//$filename=strtotime(date('Y-m-d H:i:s a')).$fileExt;
			if($thumbpath){
				$filename='thumb_'.date('YmdHis').$fileExt;
			} else {
				$filename=date('YmdHis').$fileExt;
			}
			if($filename!=''){
				@unlink($destpath.$filename);
				@unlink($thumbpath.$filename);
			}
			copy($file,$destpath.$filename);
			
			$strImageProperties = getimagesize($file);
				if($thumbWidth != ''){
					if($strImageProperties[0]>$thumbWidth){
						FinalCrop($destpath.$filename,$thumbpath.$filename,$thumbWidth,$thumbHeight);	
					}else{
						copy($file,$thumbpath.$filename);
					}
				}	
			updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);
		}
	}
	function updateThumbImageStatus($Id,$tbl_name,$fieldName,$strFieldValue=''){
		global $table_config;
		$sql = "UPDATE ".$tbl_name." SET ".$fieldName." = '".$strFieldValue."' WHERE Id='".$Id."'";
		ExecuteQry($sql);
	}

	function FinalCrop1($src,$des,$w,$h){
		$im = new ImageManipulator($src);
		$centreX = round($im->getWidth()/2);
		$centreY = round($im->getHeight()/2);

		$x1 = $centreX - $w;
		$y1 = $centreY - $h;
		
		$x2 = $centreX; 
		$y2 = $centreY+60;

		$im->crop($x1, $y1, $x2, $y2); // takes care of out of boundary conditions automatically
		//$im->crop($x1, $y1, $x2, $y2); // takes care of out of boundary conditions automatically
		$im->save($des);
		
	}
	
	function FinalCrop($src,$des,$w,$h){
		$im = new ImageManipulator($src);
		$width  = $im->getWidth();
		$height = $im->getHeight();
		$centreX = round($width / 2);
		$centreY = round($height / 2);
		
		$cropWidth  = 302;
		$cropHeight = 302;
		$cropWidthHalf  = round($cropWidth / 2); // could hard-code this but I'm keeping it flexible
		$cropHeightHalf = round($cropHeight / 2);
		
		$x1 = max(0, $centreX - $cropWidthHalf);
		$y1 = max(0, $centreY - $cropHeightHalf);
		
		$x2 = min($width, $centreX + $cropWidthHalf);
		$y2 = min($height, $centreY + $cropHeightHalf);
		$im->crop($x1, $y1, $x2, $y2); 
		$im->save($des);
	}
	function doGetAllUserDeviceDetails(){
		$sql="SELECT * FROM tbl_apns_devices WHERE devicetoken!='(null)'";
		$result=SelectQry($sql);
		return $result;
	}
	function doGetUserRole($userid){
		$sql="SELECT `Role` FROM tbl_admin WHERE `Id` = '".$userid."'";
		$result=SelectQry($sql);
		return $result[0]['Role'];
	}
?>
<?php

function insertSportsDetails($objArray,$Prefix,$tbl_name,$fileArray) {

	global $global_config;

	$objArray['sport_AddedDate']= date("Y-m-d H:m:s");

	$insertedid		=	AddInfoToDB($objArray,$Prefix,$tbl_name);

	doUploadDesignImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'sport/','SportIcon');

	doUploadSportsThumbImages($fileArray,$insertedid,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'sport/','thumb','302','302');

	return $insertedid; 

}



function updateSportsDetails($objArray,$Prefix,$tbl_name,$id,$fileArray) {

	global $global_config;

	$where="WHERE Id='".$id."'";

    $ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	

	doUploadDesignImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'sport/','SportIcon');

	doUploadSportsThumbImages($fileArray,$id,$objArray,$tbl_name,$global_config["SiteLocalUploadPath"].'sport/','thumb','302','302');

	return $ID;

}





function doUploadSportsThumbImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$thumbWidth='',$thumbHeight='') {

		global $global_config, $table_config;

		$file = $fileArray["file_File"]["tmp_name"];

		$destpath	=  $strFilePath;

		$thumbpath   =  $destpath.'thumb/';

		if($file!=''){

			$filename = $fileArray["file_File"]["name"];

			$fileExt = substr($filename,-4,4);

			$DBFilename = substr($filename,0,-4);

			//$filename=strtotime(date('Y-m-d H:i:s a')).$fileExt;

			if($thumbpath){

				$filename='thumb_'.date('YmdHis').$fileExt;

			} else {

				$filename=date('YmdHis').$fileExt;

			}

			if($filename!=''){

				@unlink($destpath.$filename);

				@unlink($thumbpath.$filename);

			}

			copy($file,$destpath.$filename);

			

			$strImageProperties = getimagesize($file);

				if($thumbWidth != ''){

					if($strImageProperties[0]>$thumbWidth){

						FinalCrop($destpath.$filename,$thumbpath.$filename,$thumbWidth,$thumbHeight);	

					}else{

						copy($file,$thumbpath.$filename);

					}

				}	

			updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);

		}

	}
	
	function listSports($tblname) {
		global $global_config;
		$sql = "SELECT Id,SportName,RecordNo,SportIcon FROM ".$tblname. " ORDER BY Id DESC";
		$strResult = SelectQry($sql);
		return $strResult;
	}

?>


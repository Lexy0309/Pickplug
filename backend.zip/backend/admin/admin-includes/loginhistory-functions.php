<?php

/* --------------------------------- FUNCTION TO LIST LOGIN HISTORY TABLE --------------------------------*/ 

function GetLoginHistoryList($tbl_name){
	$sql="SELECT * FROM ".$tbl_name." WHERE username='admin'";
	$arrLoginHistoryList=SelectQry($sql);
	//printArray($arrLoginHistoryList);
	return $arrLoginHistoryList;
}


?>

<?php
 	ob_start ();
	session_start ();
  	include("../../includes/common.php");
	
	$filepath  = $global_config["SiteLocalPath"]."uploads/photogallery/".$_REQUEST["SESS_IMAGEID"].'/';
	$thumbpath = $global_config["SiteLocalPath"]."uploads/photogallery/".$_REQUEST["SESS_IMAGEID"].'/thumb/';

	if(!is_dir($filepath)) {
		mkdir($filepath);
		chmod($filepath,0777);
	}
	
	if(!is_dir($thumbpath)) {
		mkdir($thumbpath);
		chmod($thumbpath,0777);
	}
	
	$filename = time().'_'.$_FILES["photo"]["name"];
	$originalfile  = $filepath.$filename;
	
	copy($_FILES["photo"]["tmp_name"],$originalfile);

	$strImageProperties = getimagesize($originalfile);

	if($strImageProperties[0]>$strImageProperties[1])
		createthumb($originalfile,$thumbpath.$filename,"130","");		
	else
		createthumb($originalfile,$thumbpath.$filename,"","130");

	ob_flush();
?>
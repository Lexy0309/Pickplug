<?php
    function addUserAppLog($arr){
        $user_name = $arr['user_name'];
        $user_email = $arr['user_email'];
        $last_updated = $arr['last_updated'];
        $sql = "select * from tbl_user where FullName = '".$user_name."' and Email = '".$user_email."'";
        $results = SelectQry($sql);
        if(count($results) > 0){
            $user_id = $results[0]['Id'];
        }
        $sql1 = 'INSERT INTO tbl_user_app_logs(user_id, last_updated)
                     VALUES("'.$user_id.'", "'.$last_updated.'")';
        mysql_query($sql1);
        $ResultArray = array("status"=>"success","message"=>"UserAppLogs insert success");
        return $ResultArray;
    }
    function updateSubscription_android($arr){
        $productId_list = array();
        $productId_list = explode('', $arr['ProductId_list']);
        $user_id = $arr['User'];
        $sql = "select * from tbl_transactions where User = $user_id";
        $result = SelectQry($sql);
        $updatedAt = date('Y-m-d H:i:s');
        $user_product_id_list = [];
        if (!empty($result)){
            for ($k = 0 ; $k < count($result); $k++){
                for ($i = 0 ; $i < count($productId_list) ; $i++){
                    if ($productId_list[i] != $result[$k]['ProductId']) {
                        $product_id = $productId_list[i];
                        $sql1 = "UPDATE from tbl_transaction SET is_subscription_cancel = 'Y' and updatedAt = $updatedAt where User = $user_id and ProductId = $product_id";
                        mysql_query($sql1);
                        $sql2 = "delete from tbl_user_subscription where User = $user_id and ProductId = $product_id";
                        mysql_query($sql2);
                    }
                }
            }
        }

        $ResultArray = array("status"=>"success","message"=>"Favorites details updated successfully");
        return $ResultArray;
	}
	
	function getUserAppLog($selection, $year = 2019, $month = 4, $day = 1){
        switch($selection){
            case "total" :
                $sql = "Select count(*) as  total from tbl_user_app_logs";
                break;
            case "monthly":
                $sql = "select month(last_updated) as day, sum(case when year(last_updated) = $year then 1 else 0 end) as count_user  
                from tbl_user_app_logs group BY (month(last_updated)) ORDER BY(month(last_updated))";
                break;
            case "daily":
                $sql = "select DAY(last_updated) as day, sum(case when year(last_updated) = $year 
                and month(last_updated) = $month then 1 else 0 end) as count_user from tbl_user_app_logs group BY (day(last_updated)) ORDER BY(day(last_updated))";
                break;
            case "day": 
                $sql = "select count(*) as total from tbl_user_app_logs where year(last_updated) = $year and month(last_updated) = $month and day(last_updated) = $day order BY(last_updated)";
                break;
            default :
                $sql = "Select count(*) as  total from tbl_user_app_logs";
        }
        $results=SelectQry($sql);
        return $results;
        
    }
    function addsubscription_android($arr){
       
        $purchaseDate = $arr['PurchasedDate'];
        $product_id = $arr['ProductId']; 
	    $user_id = $arr['User'];
		$purchased_date = $arr['PurchasedDate'];
	    $product_id = $arr['ProductId'];
	    $transactionId = $arr['TransactionID'];
	    $payment_type = $arr['payment_type'];
        $package_name = $arr['package_name'];
        $puchased_token = $arr['purchased_token'];
        $is_auto_renewing = $arr['is_auto_renewing'];
        $user_google_account_email = $arr['user_google_account_email'];
        $is_insert_transaction = 0;

       
        
		$sql1 = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$product_id.'" AND Enabled=1';
        $result=SelectQry($sql1);
        $subscriptions = $result[0];
        $sportid = $subscriptions["Sport"];
        $duration = $subscriptions["Duration"];
        $subscription_id = $subscriptions["Id"];
        $fromdate = time();
        if($duration != "n/a"){
            $expiredate = date('Y-m-d', strtotime('+'.$duration.' day', $fromdate));
        }else{
            $expiredate = $subscriptions["EndDate"];
        }
        if (empty($is_insert_transaction)){
            $sql2 = 'INSERT INTO tbl_transactions(User, ProductId, TransactionID, subscription_id, payment_type, is_subscription_cancel, PurchasedDate, Pick, updatedAt)
                     VALUES("'.$user_id.'", "'.$product_id.'", "'.$transactionId.'", "'.$payment_type.'", "N", "'.$purchased_date.'", 0, "'.$updatedAt.'")';
            $is_insert_transaction = 1; 
        }

		
		if($is_insert_transaction) {
			

			$sql = 'INSERT INTO tbl_user_subscription(User, Sport, ExpiryDate, updatedAt) VALUES("'.$user_id.'", "'.$sportid.'", "'.$expiredate.'", "'.$fromdate.'")';
			mysql_query($sql);

			$userSubscriptions  = getUserSubscriptions($objArray["User"]);
			$userPicks 		 = getUserPicks($objArray["User"]);
			$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully",
					"User_Subscriptions"=>$userSubscriptions,
					"User_Picks"=>$userPicks
			);
		}
	
	return $ResultArray;

    }

	function sendEmail($to, $title, $msg){
		$from = "From: webmaster@example.com";
		mail($to, $title, $msg, $from);
	}

	function getUserEmailById($id){
        $sql = "select * from tbl_user where id = $id";
        $results=SelectQry($sql);
		if(count($results) >=1){
			return $results[0]['email'];
		}else{
			return 0;
        }
    }
    function getUserIdByEmail($email){
        $sql = "select * from tbl_user where Email = '".$email."'";
        $results=SelectQry($sql);
		if(count($results>=1)){
			return $results[0]['id'];
		}else{
			return 0;
        }
    }
    function insertAction(){
        $userid = $log_array;
        $sql = "Insert into tbl_action ( `data`) Values ('".$userid."')";
        mysql_query($sql);        
        
        
    }
 
    function insertUserSubscriiption($userid,$sportid,$expirydate){
        
        $date = date("Y-m-d H:i:s");
        $sql = "Insert into tbl_user_subscription ( `User`,`Sport`,`ExpiryDate`,`updatedAt` ) Values ('".$userid."','".$sportid."','".$expirydate."','".$date."')";
        mysql_query($sql);
	}
    
    function insertPaypalLog($trasaction_id,$log_array){
        $date = date("Y-m-d H:i:s");
		$sql = "Insert into paypal_log (`txn_id`,`log`,`posted_date`) Values ('".$trasaction_id."','".$log_array."','".$date."')";
		mysql_query($sql);
		return mysql_insert_id();
		
		
    }


    function getUserDetailsById($userid){
		$sql = "select * from  tbl_user where Id = '".$userid."'";
		$res = FetchQryAsAssoc($sql);
		return $res;
	}


	function getProductDetailsById($pid){
		$sql = "select * from  tbl_subscription where Id = '".$pid."'";
		$res = FetchQryAsAssoc($sql);
		return $res;
	}

    function getNotification($startLimit){
        $endLimit = 15;
		$sql = "select * from  tbl_notification ORDER BY created_at DESC limit ".$startLimit.",".$endLimit;
		$res = FetchQryAsAssoc($sql);
		return $res;
	}
	

    function updateProfile($userId,$arr){
        
       $sql = "UPDATE tbl_user SET Id = '".$userId."'";

		if(isset($arr['userFullName'])){
				if($arr['userFullName'] != ""){
					$sql .= " ,FullName = '".$arr['userFullName']."'";
				}
		}

		if(isset($arr['userPhoneNumber'])){
				if($arr['userPhoneNumber'] != ""){
					$sql .= " ,PhoneNumber = '".$arr['userPhoneNumber']."'";
				}
		}

		if(isset($arr['userGender'])){
				if($arr['userGender'] != ""){
					$sql .= " ,Gender = '".$arr['userGender']."'";
				}
		}

		if(isset($arr['userEmail'])){
				if($arr['userEmail'] != ""){
					$sql .= " , Email = '".$arr['userEmail']."'";	
				}
		}

		if(isset($arr['userBirthday'])){
				if($arr['userBirthday'] != ""){
					$sql .= " ,Birthday = '".$arr['userBirthday']."'";
				}
		}

		if(isset($arr['userPhoto'])){
				if($arr['userPhoto'] != ""){
					$sql .= " ,Photo = '".$arr['userPhoto']."'";
				}
		}
		
		$sql .= " WHERE Id = '".$userId."'";
		
		
		if(mysql_query($sql)){
		    
		    $ResultArray = array("status" => "success", "message"=>"Profile Updated Successfully","data"=>getUserDetails($userId));
		        
		        return $ResultArray;
		}else{
		    
		    $ResultArray = array("status" => "fail", "message"=>"Profile Not Updated Successfully","data"=>array());
		        
		        return $ResultArray;
		}

		
		
		


	}
	
	


  function isValidPassword($userId,$oldPassword){

		$valid = true;
		$sql = 'SELECT * FROM tbl_user WHERE Id = "'.$userId.'" AND Password = "'.$oldPassword.'"';

		$result  =  mysql_query($sql);
		$numrows = mysql_num_rows($result);		
		if($numrows > 0){
			$valid = true;
		}else{
			$valid = false;
		}
		return $valid;
	}



	function updateUserPassword($userId,$newPassword){
		$updatesql = "UPDATE tbl_user SET `Password` = '".$newPassword."' WHERE `Id` = '".$userId."'";
		

		mysql_query($updatesql);

		$ResultArray = array("status" => "success", "message"=>"Password Change Successfully");
		return $ResultArray;
	}

	
	
	function getLoginDetails($username,$password) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE Username='".$username."' AND Password='".$password."' AND Published='Yes' AND IsDeleted='No'";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			$ResultArray = array("status"=>"success","message"=>"Login Success");
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Invalid username and password");
		}
		return $ResultArray;
	}
	function getUserIdFromSession($session){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE session='".$session."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
			return $results[0]['Id'];
		}else{
			return 0;
		}
	}
	
	
	function getUserDetailsByEmail($email) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE Email='".$email."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
		  $user['Id']				 = $results[0]['Id'];
		  $user['FullName']			 = $results[0]['FullName'];
		  $user['Password'] 		 = $results[0]['Password'];
		  $user['Email'] 	 		 = $results[0]['Email'];
		  $user['PhoneNumber'] 		 = $results[0]['PhoneNumber'];
		  $user['Birthday'] 		 = $results[0]['Birthday'];
		  $user['Gender'] 		     = $results[0]['Gender'];
		  $user['Photo'] 		     = SITEGLOBALUPLOADPATH.'userImage/'.$results[0]['Photo'];
		  $user['session'] 		     = $results[0]['session'];
		  $user['Facebooktoken']	 = $results[0]['Token'];
		  $user['TwitterToken']		 = $results[0]['TwitterToken'];
		  $user['PickPush']			 = $results[0]['pick_push'];
		  $user['SportsPush']		 = $results[0]['sports_push'];
		  $user['FavoritesPush']	 = $results[0]['favorites_push'];
		  $user['PickMail']			 = $results[0]['pick_mail'];
		  $user['SportsMail']		 = $results[0]['sports_mail'];
		  $user['FavoritesMail']	 = $results[0]['favorites_mail'];
		  
		}
		return $user;
	}
	function getUserSubscriptions($userId) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user_subscription"]." WHERE User='".$userId."' and is_new_app_subscription='Y'";
		$results=FetchQryAsAssoc($sql);
		
		return $results;

	}
	
	function getUserPurchaseSubscription($userId) {
		$sql="SELECT * FROM tbl_user_subscription usubs,tbl_subscription subs WHERE usubs.User='".$userId."' and usubs.is_new_app_subscription='Y' and usubs.subscription_id = subs.Id";
		$results=FetchQryAsAssoc($sql);
		if(count($results) > 0) {
			for($i=0;$i<count($results);$i++){
			    $sql="SELECT * FROM tbl_sport WHERE IsDeleted='No' and Id='".$results[$i]['Sport']."'";
		        $sportResults=FetchQryAsAssoc($sql);
		        $results[$i]['SportDetail'] = $sportResults;
		        $results[$i]['sportIconImgPrefix'] = SITEGLOBALUPLOADPATH.'sport/';
			}
		}
		return $results;

	}
	
	function getFreePicks(){
	    $sql = "select * from tbl_pick where PickStatus='Pending' AND IsDeleted='No'   AND FreePick=1    ORDER BY NFLPick ASC";
    	
    	$picks = SelectQry($sql);
    
    	$dateAry 	 = getPendingGroupedDatesNew('-1','');
    	
    	$res = array();
    
        
		
    	if(count($dateAry)>=1){ 
    		$res['keys'] = $dateAry;
    	}
    	
    	for($i=0;$i<count($picks);$i++)
    	{
    		
    		//$res['pickDate'] = 	$ResultArray[$i]['PickDate'];
    		$strdate 	= strtotime($picks[$i]['PickDate']);
    		$finaldate  = date('d-m-Y',$strdate);
    		$pickdate = date('Y-m-d', $strdate);
    		$weekname = GetWeekDetailsById('tbl_week', $picks[$i]['NflPick']);
    		$weekname = $weekname['name'];
    		if($picks[$i]['SportId']==1) {
    				$res[$weekname] = getNflPickDetailsByIdNotFree('tbl_pick',$picks[$i]['NflPick'],'-1',$_REQUEST['date']);
    		} else {
    				$res[$finaldate]= getPendingPickDetailsByIdNotFree('tbl_pick',$pickdate,'-1',$_REQUEST['date']);
    		}
    	}
    
    	//print_r($res);exit;
 	    
        $allData = array("is_allow" => "yes","allpicks"=>$res);
        
	   
		return $allData;
	    /*$sql="SELECT pick.*,hometeam.TeamName as homeTeamName,hometeam.TeamIcon as homeTeamIcon,vteam.TeamName as visitiingTeamName,vteam.TeamIcon as visitingTeamIcon FROM tbl_pick as pick,tbl_teams as hometeam,tbl_teams as vteam WHERE pick.IsDeleted='No' and pick.FreePick='1' and pick.PickStatus='Pending' and hometeam.Id=pick.HomeTeam and vteam.Id=pick.VisitingTeam";
	    $pickresults=FetchQryAsAssoc($sql);
	    $SportImage 	= SITEGLOBALUPLOADPATH.'team/';
	    $allData = array("allpicks"=>$pickresults,"teamImgPrefix"=>$SportImage);
		return $allData;*/
	}
	
	function updateSubscriptionExpiryTime(){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user_subscription"]." WHERE is_new_app_subscription='Y' and expiry_duration > 0";
		$results=FetchQryAsAssoc($sql);
		if(count($results) > 0) {
			for($i=0;$i<count($results);$i++){
			    if ($results[$i]['expiry_duration'] == '1') {
			        $sql="DELETE FROM ".$table_config["user_subscription"]."  WHERE `Id` = '".$results[$i]['Id']."'";	
		            mysql_query($sql);
			    }else{
			        $updatesql = "UPDATE ".$table_config["user_subscription"]." SET expiry_duration = expiry_duration - 1 where Id = '".$results[$i]['Id']."'";	
		            mysql_query($updatesql);
			    }
			}
		}
	}
	
	function insertAppleLog($trasaction_id,$log_array){        
		$sql = "Insert into apple_subscription_log (`txn_id`,`log`) Values ('".$trasaction_id."','".$log_array."')";
		mysql_query($sql);
		return mysql_insert_id();
    }
    
	function getPicksBySport($sportId,$userId){
	    
        $sql = "select * from tbl_pick where SportName ='".$sportId."' AND PickStatus='Pending' AND IsDeleted='No'   AND FreePick=0    ORDER BY NFLPick ASC";
    	
    	$picks = SelectQry($sql);
    
    	$dateAry 	 = getPendingGroupedDatesNew($sportId,'');
    	
    	$res = array();
    
        
		
    	if(count($dateAry)>=1){ 
    		$res['keys'] = $dateAry;
    	}
    	
    	for($i=0;$i<count($picks);$i++)
    	{
    		
    		//$res['pickDate'] = 	$ResultArray[$i]['PickDate'];
    		$strdate 	= strtotime($picks[$i]['PickDate']);
    		$finaldate  = date('d-m-Y',$strdate);
    		$pickdate = date('Y-m-d', $strdate);
    		$weekname = GetWeekDetailsById('tbl_week', $picks[$i]['NflPick']);
    		$weekname = $weekname['name'];
    		if($picks[$i]['SportName'] == 1) {
    				$res[$weekname] = getNflPickDetailsByIdNotFree('tbl_pick',$picks[$i]['NflPick'],$sportId,$_REQUEST['date']);
    		} else {
    				$res[$finaldate]= getPendingPickDetailsByIdNotFree('tbl_pick',$pickdate,$sportId,$_REQUEST['date']);
    		}
    	}
    
    	//print_r($res);exit;
 	    
        $allData = array("is_allow" => "no","allpicks"=>$res);
        
        updateSubscriptionPeriod($userId);

        $sql="SELECT * FROM tbl_user_subscription WHERE is_new_app_subscription='Y' and User = '".$userId."' and (Sport='0' or Sport = '".$sportId."' )";
		$results    =   FetchQryAsAssoc($sql);
		if(count($results) > 0) {
		    for($i=0;$i<count($results);$i++){
		        $currentDate = strtotime(date('Y-m-d H:i:s'));
                $date = $results[$i]['ExpiryDate']." 23:59:59";
                $userLastActivity = strtotime($date);
                $minutes = round($userLastActivity - $currentDate) / 60;
                if ($minutes > 0) {
                    $allData = array("is_allow" => "yes","allpicks"=>$res);
                }
		    }
		}
		
		return $allData;
	}
	
	function updateAppleSubscriptionExpiryPeriod($transactionId,$productId){
		$q1 = 'SELECT * FROM tbl_transactions WHERE TransactionID = "'.$transactionId.'" and ProductId = "'.$productId.'" and payment_type="Apple"';
	    $resTrans    =   SelectQry($q1);
	    
		if(count($resTrans) > 0) {
		    for($i=0;$i<count($resTrans);$i++){
		        $transId = $resTrans[$i]["Id"];
		        $paymentType = $resTrans[$i]["payment_type"];
		        $isSubCancel = $resTrans[$i]["is_sbuscription_cancel"];
		        $paypalSubsId = $resTrans[$i]["subscription_id"];
		        $productId  = $resTrans[$i]["ProductId"];
		        $userId		=	$resTrans[$i]["User"]; 
		        //echo $productId;
            	$query = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$productId.'"';
    			$resSubs = SelectQry($query);
    			//print_r($resSubs);
	            //exit;
    			if(count($resSubs) > 0){
    			    $subsId = $resSubs[0]["Id"];
    			    $duration = $resSubs[0]["Duration"];
    			    $sql="SELECT * FROM tbl_user_subscription WHERE is_new_app_subscription='Y' and User = '".$userId."' and subscription_id = '".$subsId."'";
            		$results    =   FetchQryAsAssoc($sql);
            		if(count($results) > 0) {
            		    for($j=0;$j<count($results);$j++){
            		    	$fromdate = time();
							if($duration != "n/a"){
								$expiredate = date('Y-m-d', strtotime('+'.$duration.' day', $fromdate));
							}			
							if ($paymentType == "Apple"){
								if ($isSubCancel == 'N' && $paypalSubsId != ''){
									$query = "update tbl_user_subscription set ExpiryDate = '".$expiredate."' where Id = '".$results[$j]['Id']."'";
									$resSubs = SelectQry($query);
								}
							}
            			}
    				}
		    	}
			}
    	}
	}
	
	function updateSubscriptionExpiryPeriod($userId,$productId,$subscriptionId){
		$q1 = 'SELECT * FROM tbl_transactions WHERE User="'.$userId.'" and ProductId = "'.$productId.'" and subscription_id = "'.$subscriptionId.'"';
	    $resTrans    =   SelectQry($q1);
	    
		if(count($resTrans) > 0) {
		    for($i=0;$i<count($resTrans);$i++){
		        $transId = $resTrans[$i]["Id"];
		        $paymentType = $resTrans[$i]["payment_type"];
		        $isSubCancel = $resTrans[$i]["is_sbuscription_cancel"];
		        $paypalSubsId = $resTrans[$i]["subscription_id"];
		        $productId  = $resTrans[$i]["ProductId"];
		        //echo $productId;
            	$query = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$productId.'"';
    			$resSubs = SelectQry($query);
    			//print_r($resSubs);
	            //exit;
    			if(count($resSubs) > 0){
    			    $subsId = $resSubs[0]["Id"];
    			    $duration = $resSubs[0]["Duration"];
    			    $sql="SELECT * FROM tbl_user_subscription WHERE is_new_app_subscription='Y' and User = '".$userId."' and subscription_id = '".$subsId."'";
            		$results    =   FetchQryAsAssoc($sql);
            		if(count($results) > 0) {
            		    for($j=0;$j<count($results);$j++){
            		    	$fromdate = time();
							if($duration != "n/a"){
								$expiredate = date('Y-m-d', strtotime('+'.$duration.' day', $fromdate));
							}			
							if ($paymentType == "Paypal"){
								if ($paypalSubsId != ''){
									if ($isSubCancel == 'N'){
										$query = "update tbl_user_subscription set ExpiryDate = '".$expiredate."' where Id = '".$results[$j]['Id']."'";
    									$resSubs = SelectQry($query);
									}
								}
							}
            			}
    				}
		    	}
			}
    	}
	}
	
	function updateSubscriptionPeriod($userId){
		$q1 = 'SELECT * FROM tbl_transactions WHERE User="'.$userId.'"';
	    $resTrans    =   SelectQry($q1);
	    
		if(count($resTrans) > 0) {
		    for($i=0;$i<count($resTrans);$i++){
		        $transId = $resTrans[$i]["Id"];
		        $paymentType = $resTrans[$i]["payment_type"];
		        $isSubCancel = $resTrans[$i]["is_sbuscription_cancel"];
		        $paypalSubsId = $resTrans[$i]["subscription_id"];
		        $productId  = $resTrans[$i]["ProductId"];
		        //echo $productId;
            	$query = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$productId.'"';
    			$resSubs = SelectQry($query);
    			//print_r($resSubs);
	            //exit;
    			if(count($resSubs) > 0){
    			    $subsId = $resSubs[0]["Id"];
    			    $sql="SELECT * FROM tbl_user_subscription WHERE is_new_app_subscription='Y' and User = '".$userId."' and subscription_id = '".$subsId."'";
            		$results    =   FetchQryAsAssoc($sql);
            		if(count($results) > 0) {
            		    for($j=0;$j<count($results);$j++){
            		        $currentDate = strtotime(date('Y-m-d H:i:s'));
                            $date = $results[$j]['ExpiryDate']." 23:59:59";
                            $userLastActivity = strtotime($date);
                            $minutes = round($userLastActivity - $currentDate) / 60;

                            if ($minutes > 0) {
                                //$allData = array("is_allow" => "yes","allpicks"=>$res);
                            }else{
                                if ($paypalSubsId != ''){
                            		if ($isSubCancel == 'Y'){
                            			deleteUserSubsciption($transId,$results[$j]['Id']);
                            		}
                            	}else{
                            		deleteUserSubsciption($transId,$results[$j]['Id']);
                            	}
            		   	 	}
            			}
    				}
		    	}
			}
    	}
	}
	
	function deleteUserSubsciption($transactionId,$userSubsId){
		 $sql="DELETE FROM tbl_user_subscription WHERE `Id` = '".$userSubsId."'";
		 mysql_query($sql);
		 
		 $sql="DELETE FROM tbl_transactions WHERE `Id` = '".$transactionId."'";
		 mysql_query($sql);
	}
	
	/*function getPicksBySport($sportId,$userId){
	    
        $sql = "select * from tbl_pick where SportName ='".$sportId."' AND PickStatus='Pending' AND IsDeleted='No'   AND FreePick=0    ORDER BY NFLPick ASC";
    	
    	$picks = SelectQry($sql);
    
    	$dateAry 	 = getPendingGroupedDatesNew($sportId,'');
    	
    	$res = array();
    
		
    	if(count($dateAry)>=1){ 
    		$res['keys'] = $dateAry;
    	}
    	
    	for($i=0;$i<count($picks);$i++)
    	{
    		
    		//$res['pickDate'] = 	$ResultArray[$i]['PickDate'];
    		$strdate 	= strtotime($picks[$i]['PickDate']);
    		$finaldate  = date('d-m-Y',$strdate);
    		$pickdate = date('Y-m-d', $strdate);
    		$weekname = GetWeekDetailsById('tbl_week', $picks[$i]['NflPick']);
    		$weekname = $weekname['name'];
    		if($picks[$i]['SportName'] == 1) {
    				$res[$weekname] = getNflPickDetailsByIdNotFree('tbl_pick',$picks[$i]['NflPick'],$sportId,$_REQUEST['date']);
    		} else {
    				$res[$finaldate]= getPendingPickDetailsByIdNotFree('tbl_pick',$pickdate,$sportId,$_REQUEST['date']);
    		}
    	}
    
    	//print_r($res);exit;
 	    
        $allData = array("is_allow" => "no","allpicks"=>$res);
        
	    $sql="SELECT * FROM tbl_user_subscription WHERE is_new_app_subscription='Y' and User = '".$userId."' and (Sport='0' or Sport = '".$sportId."' )";
		$results    =   FetchQryAsAssoc($sql);
		if(count($results) > 0) {
		    for($i=0;$i<count($results);$i++){
		        $currentDate = strtotime(date('Y-m-d H:i:s'));
                $date = $results[$i]['ExpiryDate']." 23:59:59";
                $userLastActivity = strtotime($date);
                $minutes = round($userLastActivity - $currentDate) / 60;
                if ($minutes > 0) {
                    $allData = array("is_allow" => "yes","allpicks"=>$res);
                }else{
                    $sql="DELETE FROM tbl_user_subscription WHERE `Id` = '".$results[$i]['Id']."'";	
		            mysql_query($sql);
                }
		    }
		}
		return $allData;
	}*/
	
	function getSportsIconBy($id) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		//$strfinaldate = strtotime($strDate);
		
		$sql="SELECT SportIcon FROM ".$table_config["sport"]."  WHERE Id = '".$id."' AND Status ='Active' AND IsDeleted ='No'";
			
		$results=SelectQry($sql);
		
		$sportImage = "";
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$sportImage =  SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
			}		
		} 
		return $sportImage;
	}
	
	function getAllSports($userId) {
		global $table_config,$global_config;
		
		updateSubscriptionPeriod($userId);
		
		$sql="SELECT * FROM ".$table_config["sport"]." WHERE IsDeleted='No'";
		$results=FetchQryAsAssoc($sql);
		if(count($results) > 0) {
			for($i=0;$i<count($results);$i++){
			    $results[$i]['SportIcon'] 	= SITEGLOBALUPLOADPATH.'sport/'.$results[$i]['SportIcon'];
				$results[$i]['thumb'] 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$results[$i]['thumb'];
				
			    $sql="SELECT * FROM tbl_pick WHERE IsDeleted='No' and FreePick='0' and SportName='".$results[$i]['Id']."' and PickStatus='Pending'";
		        $pickresults=FetchQryAsAssoc($sql);
			    $results[$i]['count'] = count($pickresults);
			}
		}
		
		$sql="SELECT * FROM tbl_pick WHERE IsDeleted='No' and FreePick='1' and PickStatus='Pending'";
		$freePickresults=FetchQryAsAssoc($sql);
		
		$sql = 'SELECT * FROM tbl_subscription WHERE Enabled="1"';
		$subscriptiondetail=FetchQryAsAssoc($sql);
		
		$allData = array("allsports"=>$results,"freepicks"=>count($freePickresults),"total_sbscription"=>count($subscriptiondetail),"user_subscription"=>getUserSubscriptions($userId));
		return $allData;

	}
	
	function getUserPicks($userId) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user_picks"]." WHERE User='".$userId."'";
		$results=FetchQryAsAssoc($sql);
		return array_unique(array_map(function($element){return $element['Pick'];}, $results)); //array_column($results, 'Pick');

	}
	function getUserDetails($userId) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE Id='".$userId."'";
		$results=SelectQry($sql);
		
		if(count($results>=1)){
		  $user['Id']				 = $results[0]['Id'];
		  $user['FullName']			 = $results[0]['FullName'];
		  $user['Password'] 		 = $results[0]['Password'];
		  $user['Email'] 	 		 = $results[0]['Email'];
		  $user['PhoneNumber'] 		 = $results[0]['PhoneNumber'];
		  $user['Birthday'] 		 = $results[0]['Birthday'];
		  $user['Gender'] 		     = $results[0]['Gender'];
		  $user['Photo'] 		     = SITEGLOBALUPLOADPATH.'userImage/'.$results[0]['Photo'];
		  $user['session'] 		     = $results[0]['session'];
		  $user['Facebooktoken']	 = $results[0]['Token'];
		  $user['TwitterToken']		 = $results[0]['TwitterToken'];
		  
		  $user['PickPush']			 = $results[0]['pick_push'];
		  $user['SportsPush']		 = $results[0]['sports_push'];
		  $user['FavoritesPush']	 = $results[0]['favorites_push'];
		  $user['PickMail']			 = $results[0]['pick_mail'];
		  $user['SportsMail']		 = $results[0]['sports_mail'];
		  $user['FavoritesMail']	 = $results[0]['favorites_mail'];

		}
		return $user;
	}

	function getsubscriptiondetails($productid)
	{
		$query = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$productid.'"';
		$res = SelectQry($query);
		return $res[0];
	}
	
	function getSubscriptionExpiryDate($subscriptionId,$userId)
	{
		$query = 'SELECT * FROM tbl_user_subscription WHERE User="'.$userId.'" and subscription_id="'.$subscriptionId.'"';
		$res = SelectQry($query);
		if(count($res) > 0){
		    return $res[0]['ExpiryDate'];
		}else{
		    return "";    
		}
		
	}

	function getsubscriptiondetailsbyuser($user)
	{
		$q1 = 'SELECT * FROM tbl_transactions WHERE User="'.$user.'"';
		$resu = SelectQry($q1);
		if(count($resu) > 0){
			$productid = $resu[0]["ProductId"];
			$query = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$productid.'"';
			$res = SelectQry($query);
			return $res[0]["Name"];
		}
		return "Free";
	}


	function getFavoritesBySport($userId,$sportId){
		global $table_config,$global_config;
		//get team id based on sport id 
		$sql		= "SELECT DISTINCT(VisitingTeam),SportName FROM ".$table_config["picks"]." WHERE SportName='".$sportId."'";
		$results	= SelectQry($sql);
		for($i=0;$i<count($results);$i++){
			$newRes[] = $results[$i]['VisitingTeam'];
		}
		$sql1		= "SELECT DISTINCT(HomeTeam),SportName FROM ".$table_config["picks"]." WHERE SportName='".$sportId."'";
		$results1	= SelectQry($sql1);
		for($j=0;$j<count($results1);$j++){
			$newRes[] = $results1[$j]['HomeTeam'];
		}
		
		if(count($newRes)>=1){
			$finalTeamAry  = array_values(array_filter(array_unique($newRes)));
		}
		
		$fromDB = getFavoritesByUser($userId);
		
		if(count($fromDB)>1){
			$res = array_intersect($finalTeamAry,$fromDB);
		}
		if(count($res)>=1){
			$strIds  = implode(",",$res);
			$teamAry = getTeamDetailsByStr($strIds);
		}else{
			$teamAry = array("status"=>"failed","message"=>"Team not found");	
		}
		return $teamAry;
	}
	
	function UpdateFavoritesForUser($userId,$strAry){
		global $table_config,$global_config;
	    $date = date('Y-m-d H:i:s');
		$updatesql = "UPDATE ".$table_config["favorites"]." SET `TeamId` = '".$strAry."',`LastUpdatedDate`='".$date."' WHERE `UserId` = '".$userId."'";	
		mysql_query($updatesql);
	}
	function DeleteFavoritesForUser($userId){
		global $table_config,$global_config;
		$sql="DELETE FROM ".$table_config["favorites"]."  WHERE `UserId` = '".$userId."'";	
		mysql_query($sql);
	}
	
	function getFavoritesByUser($userId){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["favorites"]." WHERE UserId='".$userId."'";
		$results=SelectQry($sql);
		if(count($results[0]['TeamId'])>=1){
				$returnAry = explode(",",$results[0]['TeamId']);
		}else{
		       $returnAry = array();
		}
		return $returnAry;
	}
	
	function getTeamDetailsByStr($strIds){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["team"]."  WHERE Id IN (".$strIds.") AND Status ='Active'";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['TeamName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'team/'.$result['TeamIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'team/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$ResultArray[] = array("Id"=>$id,"TeamName"=>$SportName, "TeamImage"=>$SportImage,"AddedDate"=>$AddedDate);
			}
		}else{
			$ResultArray = array("status"=>"failed","message"=>"Team not found");	
		}		
			
		return $ResultArray;	
	}
	
	function getFavorites($userId){
	  	global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["favorites"]." WHERE UserId='".$userId."'";
		$results=SelectQry($sql);
		if(count($results[0]['TeamId'])>=1){
				$strIds = $results[0]['TeamId'];
				$sql="SELECT * FROM ".$table_config["team"]."  WHERE Id IN (".$strIds.") AND Status ='Active'";
				$results=SelectQry($sql);
				if(count($results) > 0) {
					foreach($results as $result) {
						$id 			= $result['Id'];
						$SportName 		= $result['TeamName'];
						$SportImage 	= SITEGLOBALUPLOADPATH.'team/'.$result['TeamIcon'];
						$SportThumb 	= SITEGLOBALUPLOADPATH.'team/thumb/'.$result['thumb'];
						$AddedDate 		= $result['AddedDate'];
						$ResultArray[] = array("Id"=>$id,"TeamName"=>$SportName, "TeamImage"=>$SportImage,"AddedDate"=>$AddedDate);
					}
				}		
		}else{
			$ResultArray =array("status"=>"failed","message"=>"Team not found");
		}
		return $ResultArray;
	}
	function getTeam(){
		global $table_config,$global_config;			
		$sql="SELECT * FROM ".$table_config["team"]."  WHERE Status ='Active'";
		$results=SelectQry($sql);
			if(count($results) > 0) {
				foreach($results as $result) {
					$id 			= $result['Id'];
					$SportName 		= $result['TeamName'];
					$SportImage 	= SITEGLOBALUPLOADPATH.'team/'.$result['TeamIcon'];
					$SportThumb 	= SITEGLOBALUPLOADPATH.'team/thumb/'.$result['thumb'];
					$AddedDate 		= $result['AddedDate'];
					$ResultArray[] = array("Id"=>$id,"TeamName"=>$SportName, "TeamImage"=>$SportImage,"AddedDate"=>$AddedDate);
				}
			}else{
				$ResultArray = array('Details not found');	
			}
		return $ResultArray;
		}
	
	function updateFavorites($objArray,$Prefix,$type='') {
		global $table_config,$global_config;
		$strEmailCheckUser = CheckDataExists($table_config["favorites"],'UserId', $objArray['fa_UserId']);
		if($strEmailCheckUser == 0){
			$counter = 0;
			foreach($objArray as $key=>$value){
				$pos = strpos($key, $Prefix);
				if (!is_integer($pos)) {
				}else{
					$key = str_replace($Prefix,"",$key);
					$insertArray[$counter]["Field"] = $key;
					$insertArray[$counter]["Value"] = stripslashes($value);
					$counter++;
				}
			}
			
			$insert_id = doInsert($table_config["favorites"],$insertArray);
			if($insert_id) {
				$ResultArray = array("status"=>"success","message"=>"Favorites details inserted successfully");
			}
		} else {
				// getExisting details
				   $str 	= implode(",",getFavoritiesIds($objArray['fa_UserId']));
				   if($str){
				   		$resStr	= $str.",".$objArray['fa_TeamId'];
						$resStrAry = explode(",",$resStr);
						$resStr    = implode(",",array_unique($resStrAry));
				   }else{
				   		$resStr	= $objArray['fa_TeamId'];
				   }
				
				$date = date('Y-m-d H:i:s');
			    $updatesql = "UPDATE ".$table_config["favorites"]." SET `TeamId` = '".$resStr."',`LastUpdatedDate`='".$date."' WHERE `UserId` = '".$objArray['fa_UserId']."'";	
				mysql_query($updatesql);	
		  	   $ResultArray = array("status"=>"success","message"=>"Favorites details updated successfully");
		}	
		return $ResultArray;	
	}
	
	function array_merge_unique(array $array1 /* [, array $...] */) {
	  $result = array_flip(array_flip($array1));
	  foreach (array_slice(func_get_args(),1) as $arg) { 
		$result = 
		  array_flip(
			array_flip(
			  array_merge($result,$arg)));
	  } 
	  return $result;
}
	function getFavoritiesIds($user_id){
		global $table_config,$global_config;
		$sql="SELECT TeamId FROM ".$table_config["favorites"]." WHERE UserId='".$user_id."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
			return explode(",",$results[0]['TeamId']);
		}else{
			return 0;
		}
	}
	
	function insertTransactionDetails($objArray,$Prefix,$type='') {
		global $table_config,$global_config;
		 	
			$counter = 0;
			foreach($objArray as $key=>$value){
			
				
					$key = str_replace($Prefix,"",$key);
					$insertArray[$counter]["Field"] = $key;
					$insertArray[$counter]["Value"] = stripslashes($value);
					$counter++;
				
			}
 		 
			$insert_id = doInsert($table_config["transactions"],$insertArray);
	 
			
			if($insert_id) {
				$userSubscriptions  = getUserSubscriptions($objArray["User"]);
				$userPicks 		 = getUserPicks($objArray["User"]);
				$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully",
					 "User_Subscriptions"=>$userSubscriptions,
					 "User_Picks"=>$userPicks
				);
			}
		
		return $ResultArray;	
	}


	function insertsingleTransactionDetails($obj)
	{
		$updateddate = date("Y-m-d G:i:s");
		$sql = 'INSERT INTO tbl_user_picks(User, Pick, updatedAt) VALUES("'.$obj['user'].'", "'.$obj["pick"].'", "'.$updateddate.'")';
		mysql_query($sql);
		$userSubscriptions  = getUserSubscriptions($obj["user"]);
		$userPicks 		 = getUserPicks($obj["user"]);
		$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully",
				"User_Subscriptions"=>$userSubscriptions,
				"User_Picks"=>$userPicks
		);
		return $ResultArray;
	}
	
	function isTransactionAlreadyExistsForApple($user,$productId,$transactionId){
		$sql="SELECT * FROM tbl_transactions WHERE (User='".$user."' and ProductId = '".$productId."') or TransactionID = '".$transactionId."'";
		$results=SelectQry($sql);
		if(count($results) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
	function isTransactionAlreadyExists($user,$productId){
		$sql="SELECT * FROM tbl_transactions WHERE User='".$user."' and ProductId = '".$productId."'";
		$results=SelectQry($sql);
		if(count($results) > 0){
			return 1;
		}else{
			return 0;
		}
	}

	function addsubscription($objArray,$Prefix,$type='')
	{
		global $table_config,$global_config;
		 	
		$counter = 0;
		foreach($objArray as $key=>$value){
		
			
				$key = str_replace($Prefix,"",$key);
				$insertArray[$counter]["Field"] = $key;
				$insertArray[$counter]["Value"] = stripslashes($value);
				$counter++;
			
		}
		
		$insert_id = doInsert($table_config["transactions"],$insertArray);
	
		
		if($insert_id) {

			$sql1 = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$objArray["ProductId"].'" AND Enabled=1';
			$result=SelectQry($sql1);
			$sports = $result[0];
			$sportid = $sports["Sport"];
			$duration = $sports["Duration"];
			$fromdate = time();
			if($duration != "n/a"){
				$expiredate = date('Y-m-d', strtotime('+'.$duration.' day', $fromdate));
			}else{
				$expiredate = $sports["EndDate"];
			}

            $currentDate = strtotime(date('Y-m-d H:i:s'));
            $date = $expiredate." 23:59:59";
            $userLastActivity = strtotime($date);
            

			$sql = 'INSERT INTO tbl_user_subscription(User, Sport, ExpiryDate,is_new_app_subscription,expiry_duration,subscription_id) VALUES("'.$objArray["User"].'", "'.$sportid.'", "'.$expiredate.'","Y","'.round(abs($currentDate - $userLastActivity) / 60).'","'.$sports["Id"].'")';
			mysql_query($sql);

			$userSubscriptions  = getUserSubscriptions($objArray["User"]);
			$userPicks 		 = getUserPicks($objArray["User"]);
			$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully",
					"User_Subscriptions"=>$userSubscriptions,
					"User_Picks"=>$userPicks
			);
		}
	
	    return $ResultArray;
	}

    function cancelSubscription($userId,$productId,$subscriptionId){
	    $updatesql = 'UPDATE tbl_transactions SET `is_sbuscription_cancel` = "Y" WHERE User="'.$userId.'" and ProductId = "'.$productId.'" and subscription_id = "'.$subscriptionId.'"';
	    mysql_query($updatesql);
	}

	function insertLoginDetails($objArray,$Prefix,$type='') {
		global $table_config,$global_config;
		$strEmailCheckUser = CheckDataExists($table_config["user"],'Email', $objArray['userEmail']);
		
		if($strEmailCheckUser == 0){
			$counter = 0;
			foreach($objArray as $key=>$value){
				$pos = strpos($key, $Prefix);
				if (!is_integer($pos)) {
				}else{
					$key = str_replace($Prefix,"",$key);
					$insertArray[$counter]["Field"] = $key;
					$insertArray[$counter]["Value"] = stripslashes($value);
					$counter++;
				}
			}
			
			$insert_id = doInsert($table_config["user"],$insertArray);
			if($insert_id) {
				$user 		 = getUserDetails($insert_id);
				$ResultArray = array("status"=>"success","message"=>"user details inserted successfully","user"=>$user);
			}
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Email Address already exists");
		}	
		return $ResultArray;	
	}

	function checkLoginDetails($email='',$password='', $ip) {
		global $table_config,$global_config;
		if(!empty($email) && !empty($password)) {
			$sql="SELECT * FROM ".$table_config["user"]." WHERE Email='".$email."' AND Password='".$password."' AND Status='Active' AND IsDeleted='No'";
		} 
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			updateSessionValue($results[0]['Id']);
			$userDetails = getUserDetails($results[0]['Id']);

			$sql = 'UPDATE tbl_user SET ipaddr="'.$ip.'" WHERE Id="'.$results[0]['Id'].'"';
			mysql_query($sql);

			$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Normal","user"=>$userDetails);
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Invalid Login details","type"=>"Normal");
		}
		return $ResultArray;
	}
	
	function updateSessionValue($user_id){
		global $table_config,$global_config;
		$sessionId  = md5(uniqid(microtime()));
		$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."' WHERE `Id` = '".$user_id."'";	
		mysql_query($updatesql);
	}
	function checkUserById($tbl_name,$Id){
		$sql="SELECT * from ".$tbl_name." where Id='".$Id."'";
		$result=SelectQry($sql);
		
		if($result) {
			return 1;
		} else {
			return 0;
		}
	}

	function checkUserBySessionId($tbl_name,$Id){
		$sql="SELECT * from ".$tbl_name." where SessionId='".$Id."'";
		$result=SelectQry($sql);
		return $result;
	}

	function getGlobalSettingsValue() {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["settings"];
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 	  	   = $result['Id'];
				if($result['URLShortening'] == 'Enable'){
					$strUrlShortening = 'Yes';
				} else {
					$strUrlShortening = 'No';
				}
				if($strUrlShortening == 'Yes'){
					$username	   = $result['BitlyUsername'];
					$password 	   = $result['BitlyPassword'];
				} else {
					$username	   = '';
					$password 	   = '';
				}
				$ResultArray[] = array('Id'=>$id,'URLShortening'=>$strUrlShortening,'Bit ly Username'=>$username,'Bit ly Password'=>$password);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}

	
	function getSportsDetails($id,$strDate) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
		if(isset($id) && empty($strDate)) {
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$id."' AND Status ='Active' AND IsDeleted ='No'";
		} else if(isset($id) && !empty($strDate)) {
			//$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$objArray['id']."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND Status ='Active'";
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$id."' AND ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."'))  AND IsDeleted ='No' AND Status ='Active'";
			//exit;
		} else {	
			$sql="SELECT * FROM ".$table_config["sport"]." WHERE Status ='Active' AND IsDeleted ='No'";
		}
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getSportsDetailsForPicks($id,$strDate) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
		if(isset($id) && empty($strDate)) {
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$id."' AND Status ='Active' AND IsDeleted ='No'";
		} else if(isset($id) && !empty($strDate)) {
			//$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$objArray['id']."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND Status ='Active'";
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$id."' AND ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."'))  AND IsDeleted ='No' AND Status ='Active'";
			//exit;
		} else {	
			$sql="SELECT * FROM ".$table_config["sport"]." WHERE Status ='Active' AND IsDeleted ='No'";
		}
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getSportsDetailsForPicksWithoutDate($id,$strDate) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
		$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$id."' AND Status ='Active' AND IsDeleted ='No'";
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}	
	
	function getSportsDetailsByDate($objArray) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		//$strdate  = strtotime($objArray['date']);
		//$strdate1 = date("Y-m-d H:i:s",strtotime('+5 hours 30 minutes',strtotime($objArray['date'])));
		$strdate  = $objArray['date'];
		$finaldate = strtotime($strdate1);
		$sql="SELECT * FROM ".$table_config["sport"]." WHERE ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."')) AND IsDeleted='No' ";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			$ResultArray = getMainSportsDetails($objArray);
		}else {
			$ResultArray = array("message"=>"No records found");
		}
		
		/*if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}*/
		return $ResultArray;
	}	
	
	function checkFbLoginDetails($username,$facebookid,$email='',$birthday,$gender,$strfbimage='') {
		global $table_config,$global_config;
		if(preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email)){
			if (!empty($facebookid)) {
				$sql="SELECT * FROM ".$table_config["user"]." WHERE Token='".$facebookid."' AND Status='Active' AND IsDeleted='No'";
			}
			$results=SelectQry($sql);
			
			if(count($results) > 0) {
				$sessionId        =  md5(uniqid(microtime()));
				$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$strfbimage."' WHERE `Id` = '".$results[0]['Id']."'";	
				mysql_query($updatesql);
				$userDetails = getUserDetails($results[0]['Id']);
				$ResultArray = array("status"=>"success","message"=>"Facebook login successfully","type"=>"Facebook","user"=>$userDetails);
			} else {
				$sessionId =  md5(uniqid(microtime()));
				$addedDate = date('Y-m-d H:i:s');
				$strEmailCheckUser = CheckDataExists($table_config["user"],'Email', $email);
				if($strEmailCheckUser == 0){
					$sql = "Insert into ".$table_config["user"]." ( `FullName`, `Email`,`Birthday`, `Gender`,`Photo`,`AddedDate`,`session`,`Token` ) Values ('".$username."', '".$email."', '".$birthday."','".$gender."', '".$strfbimage."','".$addedDate."','".$sessionId."','".$facebookid."')";
					mysql_query($sql);
					$lastInsertId = mysql_insert_id();
					$userDetailsNew = getUserDetails($lastInsertId);
					$ResultArray = array("status"=>"success","message"=>"Facebook login successfully","type"=>"Facebook","user"=>$userDetailsNew);
				} else {
					$sessionId        =  md5(uniqid(microtime()));
					$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$strfbimage."',`Token` ='".$facebookid."' WHERE `Email` = '".$email."'";	
					mysql_query($updatesql);
					$userDetails = getUserDetailsByEmail($email);
					$ResultArray = array("status"=>"success","message"=>"Facebook login successfully","type"=>"Facebook","user"=>$userDetails);
				}
			}
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Email Address is not valid","type"=>"Facebook");
		}
		return $ResultArray;
	}
	function checkTwitterLoginDetails($username,$twitterid,$email='',$birthday,$gender,$strfbimage='') {
		global $table_config,$global_config;
			if (!empty($twitterid)) {
				$sql="SELECT * FROM ".$table_config["user"]." WHERE TwitterToken='".$twitterid."' AND Status='Active' AND IsDeleted='No'";
			}
			$results=SelectQry($sql);
			
			
			if(count($results) > 0) {
				$sessionId        =  md5(uniqid(microtime()));
				$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$strfbimage."' WHERE `Id` = '".$results[0]['Id']."'";	
				mysql_query($updatesql);
				$userDetails = getUserDetails($results[0]['Id']);
				
				$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Twitter","user"=>$userDetails);
			} else {
				$sessionId =  md5(uniqid(microtime()));
				$addedDate = date('Y-m-d H:i:s');
				$strEmailCheckUser = 0; //CheckDataExists($table_config["user"],'Email', $email);
				
				if($strEmailCheckUser == 0){
					$sql = "Insert into ".$table_config["user"]." ( `FullName`, `Email`,`Birthday`, `Gender`,`Photo`,`AddedDate`,`session`,`TwitterToken` ) Values ('".$username."', '".$email."', '".$birthday."','".$gender."', '".$strfbimage."','".$addedDate."','".$sessionId."','".$twitterid."')";
					mysql_query($sql);
					$lastInsertId = mysql_insert_id();
					$userDetailsNew = getUserDetails($lastInsertId);
					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Twitter","user"=>$userDetailsNew);
				} else {
					$ResultArray = array("status"=>"failed","message"=>"Eamil Address already exist","type"=>"Twitter");
				}
			}
		return $ResultArray;
	}
	
	function checkInstagramLoginDetails($username,$instagramid,$email='',$birthday,$gender,$instagramimage='') {
		global $table_config,$global_config;
			if (!empty($instagramid)) {
				$sql="SELECT * FROM ".$table_config["user"]." WHERE InstagramToken='".$instagramid."' AND Status='Active' AND IsDeleted='No'";
			}
			$results=SelectQry($sql);
			
			if(count($results) > 0) {
				$sessionId        =  md5(uniqid(microtime()));
				$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$instagramimage."' WHERE `Id` = '".$results[0]['Id']."'";	
				mysql_query($updatesql);
				$userDetails = getUserDetails($results[0]['Id']);
				
				$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Instagram","user"=>$userDetails);
			} else {
				$sessionId =  md5(uniqid(microtime()));
				$addedDate = date('Y-m-d H:i:s');
				$strEmailCheckUser = 0; //CheckDataExists($table_config["user"],'Email', $email);
				
				
				if($strEmailCheckUser == 0){
					$sql = "Insert into ".$table_config["user"]." ( `FullName`, `Email`,`Birthday`, `Gender`,`Photo`,`AddedDate`,`session`,`InstagramToken` ) Values ('".$username."', '".$email."', '".$birthday."','".$gender."', '".$instagramimage."','".$addedDate."','".$sessionId."','".$instagramid."')";
					mysql_query($sql);
					 $msg = "Thank you for downloading Pick Plug.\n We look forward to helping you make money!\n If you have any questions or concerns, please feel free to email us at anytimes!\n Cheers,\n Pick Plug Team";
	                send_Email($email,"Hello", $msg);
					$lastInsertId = mysql_insert_id();
					$userDetailsNew = getUserDetails($lastInsertId);
					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Instagram","user"=>$userDetailsNew);
				} else {
					$ResultArray = array("status"=>"failed","message"=>"Eamil Address already exist","type"=>"Instagram");
				}
			}
		return $ResultArray;
	}
	
function doUploadFbThumbImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$thumbWidth='',$thumbHeight='') {
		global $global_config, $table_config;
		$file = $fileArray;
		$destpath	=  $strFilePath;
		$thumbpath   =  $destpath.'thumb/';
		if($file!=''){
			$filename =basename($fileArray);
			$fileExt = substr($filename,-4,4);
			$DBFilename = substr($filename,0,-4);
			//$filename=strtotime(date('Y-m-d H:i:s a')).$fileExt;
			$filename=date('YmdHis').$fileExt;
			
			if($filename!=''){
				@unlink($destpath.$filename);
				@unlink($thumbpath.$filename);
			}
			
			copy($file,$destpath.$filename);
			
			$strImageProperties = getimagesize($file);
				if($thumbWidth != ''){
					if($strImageProperties[0]>$thumbWidth){
						FinalCrop($destpath.$filename,$thumbpath.$filename,$thumbWidth,$thumbHeight);	
					}else{
						copy($file,$thumbpath.$filename);
					}
				}	
			//updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);
		}
		return $filename;
	}
	function getPicksDetails($tbl_name,$sportid)
	{
		global $global_config, $table_config;
		if($sportid==1) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY NflPick  ORDER BY NflPick ASC ";
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY DATE( PickDate )  ORDER BY PickDate ASC ";
		}
		$results=SelectQry($sql);

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$sportname 			= $result['SportName'];
				$pickdate 			= date('Y-m-d',strtotime($result['PickDate']));
				$nflpick 			= $result['NflPick'];

				

				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportname,"PickDate"=>$pickdate,"NflPick"=>$nflpick);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getPickDetailsBySportId($tbl_name,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		$strfinaldate = strtotime($strDate);
		
		if($sid==1){
			$orderby ='WeekDate';
		}else{
			$orderby ='PickDate';
		}
		
		if(empty($strDate)) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE  SportName=".$sid." AND PickStatus!='Pending' AND IsDeleted = 'No' ORDER BY $orderby DESC LIMIT 10";
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE  SportName=".$sid." AND PickStatus!='Pending' AND IsDeleted = 'No' ORDER BY $orderby DESC LIMIT 10";
			//$sql="SELECT * FROM  ".$tbl_name." WHERE  SportName=".$sid." AND PickStatus!='Pending' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND IsDeleted = 'No' ORDER BY PickDate DESC LIMIT 10";
		}
		//echo $sql; exit;
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				
				if($sid==1){
					$result['PickDate'] = $result['WeekDate'];
				}
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($result['PickDate']));
				$pickTime				= date('h:i A',strtotime($pickdate));
				
				$weekdate 				= strtotime($result['WeekDate']);
				$weekdate 				= date('d-m-Y H:i:s',$weekdate);
				$weekTime				= date('h:i A',strtotime($weekdate));
				
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				$PickAnalysis 			= replace($result['PickAnalysis']);
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($result['AddedDate']) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				if(!empty($strDate)) {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"PickdateNew"=>$pickdateNew,"pickTime"=>$pickTime,"WeekDate"=>$weekdate,"WeekTime"=>$weekTime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"PickdateNew"=>$pickdateNew,"pickTime"=>$pickTime,"WeekDate"=>$weekdate,"WeekTime"=>$weekTime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	function getgivenDateStatusChangedPicksCnt($sid,$strfinaldate,$type=''){
		if($type=='Pending'){
			$sql="SELECT COUNT(Id) as tot FROM  tbl_pick WHERE ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."'))  AND SportName=".$sid." AND IsDeleted = 'Yes' AND PickStatus='Pending'  ORDER BY PickDate ASC";
		}else{
			$sql="SELECT COUNT(Id) as tot FROM  tbl_pick WHERE ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."'))  AND SportName=".$sid." AND IsDeleted = 'Yes' AND PickStatus!='Pending'  ORDER BY PickDate ASC";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function checkActivePicksAvailabe($sid){
		 global $global_config, $table_config;
		 $tbl_name = $table_config['picks'];
 		 $sql="SELECT COUNT(Id) as tot FROM  ".$tbl_name." WHERE ";
 		 if ($sid > -1 ) $sql .= " SportName=".$sid." AND ";
 		 $sql .=" IsDeleted = 'No' AND PickStatus='Pending' ORDER BY PickDate ASC";
		 $results=SelectQry($sql);
	 	 return $results[0]['tot'];
	}
	
	function getPendingPickDetailsByIdNotFree($tbl_name,$date,$sid,$strdate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strdate);
		$strfinaldate = $strdate;
		if(empty($strdate)) {
		    if ($sid =='-1' ){
		        $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND IsDeleted = 'No' AND FreePick=1 AND PickStatus='Pending'   ORDER BY PickDate ASC";
		    }else{
		        $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND SportName=".$sid." AND IsDeleted = 'No' AND FreePick=0 AND PickStatus='Pending'   ORDER BY PickDate ASC";
		    }
			 
			// $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending' ORDER BY PickDate ASC";
		} else {
			 $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND SportName=".$sid." AND IsDeleted = 'No' AND FreePick=0 AND PickStatus='Pending'  ORDER BY PickDate ASC";
			// $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending' ORDER BY PickDate ASC";
		}
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 			= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				
				if(!empty($strdate)) { 
					$ResultArray[]  = array("FreePick"=>$result["FreePick"],
					"Id"=>$id,"sportImage"=>getSportsIconBy($sportid),"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("FreePick"=>$result["FreePick"],
					"Id"=>$id,"sportImage"=>getSportsIconBy($sportid),"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
				
			}		
		} else {
			$ResultArray = "";
		}
		return $ResultArray;
	}
	
	function getPendingPickDetailsById($tbl_name,$date,$sid,$strdate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strdate);
		$strfinaldate = $strdate;
		if(empty($strdate)) {
			 $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending'   ORDER BY PickDate ASC";
			// $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending' ORDER BY PickDate ASC";
		} else {
			 $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending'  ORDER BY PickDate ASC";
			// $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending' ORDER BY PickDate ASC";
		}
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 			= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				
				if(!empty($strdate)) { 
					$ResultArray[]  = array("FreePick"=>$result["FreePick"],
					"Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("FreePick"=>$result["FreePick"],
					"Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
				
			}		
		} else {
			$ResultArray = "";
		}
		return $ResultArray;
	}
	
	function getPickDetailsById($tbl_name,$date,$sid,$strdate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strdate);
		$strfinaldate = $strdate;
		if(empty($strdate)) {
			 $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' ORDER BY PickDate ASC";
		} else {
			 $sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' ORDER BY PickDate ASC";
			//$sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."')) AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted='No' ORDER BY PickDate ASC";
		}
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 			= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				
				if(!empty($strdate)) { 
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
			}		
		} else {
			$ResultArray = "";
		}
		return $ResultArray;
	}
	
	function getNflPickDetailsByIdNotFree($tbl_name,$pick,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
		if(empty($strDate)) {
		    if ($sid != '-1'){
		        $sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND IsDeleted = 'No' AND FreePick=0 AND PickStatus='Pending' ORDER BY NflPick ASC";
		    }else{
		        $sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND IsDeleted = 'No' AND FreePick=1 AND PickStatus='Pending' ORDER BY NflPick ASC";
		    }
			
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND IsDeleted = 'No'  AND FreePick=0 AND PickStatus='Pending' ORDER BY NflPick ASC";
			//$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) ORDER BY NflPick ASC";
			//$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."')) AND IsDeleted='No' ORDER BY NflPick ASC";
		}
		
		//echo $sql;  exit;
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$weeknames 				= GetWeekDetailsById($table_config['week'], $result['NflPick']);
				$weekname					= $weeknames['name'];
				$startdate				= $weeknames['startdate'];
				$enddate				= $weeknames['enddate'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				
				$weekdate 				= strtotime($result['WeekDate']);
				$weekdate 				= date('d-m-Y H:i:s',$weekdate);
				$weektime				= date('h:i A',strtotime($weekdate));
				
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 		    = $result['ModifiedDate'];
				$AddedDate 		   		= $result['AddedDate'];
				$isdeleted              = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($result['AddedDate']) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[]  = array("Id"=>$id,"sportImage"=>getSportsIconBy($sportid),"SportId"=>$sportid,"Week"=>$weekname,"StartDate"=>$startdate,"EndDate"=>$enddate,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"WeekDate"=>$weekdate,"WeekTime"=>$weektime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,
				"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus,
				 "ModifiedDate"=>$ModifiedDate,"AddedDate"=>$AddedDate,
				 "HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails,
				 "FreePick"=>$result['FreePick']
				 );
			}		
		} /*else {
			$ResultArray[] = array("message"=>"No record found");
		}*/
		return $ResultArray;
	}
	
	function getNflPickDetailsById($tbl_name,$pick,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
		if(empty($strDate)) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending' ORDER BY NflPick ASC";
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND IsDeleted = 'No' AND PickStatus='Pending' ORDER BY NflPick ASC";
			//$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) ORDER BY NflPick ASC";
			//$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."')) AND IsDeleted='No' ORDER BY NflPick ASC";
		}
		
		//echo $sql;  exit;
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$weeknames 				= GetWeekDetailsById($table_config['week'], $result['NflPick']);
				$weekname					= $weeknames['name'];
				$startdate				= $weeknames['startdate'];
				$enddate				= $weeknames['enddate'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				
				$weekdate 				= strtotime($result['WeekDate']);
				$weekdate 				= date('d-m-Y H:i:s',$weekdate);
				$weektime				= date('h:i A',strtotime($weekdate));
				
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 		    = $result['ModifiedDate'];
				$AddedDate 		   		= $result['AddedDate'];
				$isdeleted              = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($result['AddedDate']) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"Week"=>$weekname,"StartDate"=>$startdate,"EndDate"=>$enddate,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"WeekDate"=>$weekdate,"WeekTime"=>$weektime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,
				"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus,
				 "ModifiedDate"=>$ModifiedDate,"AddedDate"=>$AddedDate,
				 "HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails,
				 "FreePick"=>$result['FreePick']
				 );
			}		
		} /*else {
			$ResultArray[] = array("message"=>"No record found");
		}*/
		return $ResultArray;
	}
	
	function getNflPickDetailsByIdWithDate($tbl_name,$pick,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
		if(empty($strDate)) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND IsDeleted = 'No' ORDER BY NflPick ASC";
		} else {
			//$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) ORDER BY NflPick ASC";
			$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((date(AddedDate) >= '".$strfinaldate."') OR (date(ModifiedDate) >= '".$strfinaldate."') OR IsDeleted='Yes') ORDER BY NflPick ASC";
		}
		
		//echo $sql;  exit;
		$results=SelectQry($sql);
		if(count($results) > 0) {
			return getNflPickDetailsByIdWithDateForModify($tbl_name,$pick,$sid,$strDate);
		}
		
		return $ResultArray;
	}
	
	
	function getNflPickDetailsByIdWithDateForModify($tbl_name,$pick,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strfinaldate = strtotime($strDate);
		$strfinaldate = $strDate;
			$sql="SELECT * FROM  ".$tbl_name." WHERE SportName=".$sid." AND IsDeleted = 'No' ORDER BY NflPick ASC";
		
		//echo $sql;  exit;
		$results=FetchQryAsAssoc($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$weeknames 				= GetWeekDetailsById($table_config['week'], $result['NflPick']);
				$weekname					= $weeknames['name'];
				$startdate				= $weeknames['startdate'];
				$enddate				= $weeknames['enddate'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				
				$weekdate 				= strtotime($result['WeekDate']);
				$weekdate 				= date('d-m-Y H:i:s',$weekdate);
				$weektime				= date('h:i A',strtotime($weekdate));
				
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 		    = $result['ModifiedDate'];
				$AddedDate 		   		= $result['AddedDate'];
				$isdeleted              = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($result['AddedDate']) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"Week"=>$weekname,"StartDate"=>$startdate,"EndDate"=>$enddate,
				"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,
				"WeekDate"=>$weekdate,"WeekTime"=>$weektime,"VisitingTeam"=>$VisitingTeam,
				"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,
				"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,
				"AddedDate"=>$AddedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails,
				"FreePick"=>$result['FreePick']);
			}		
		} /*else {
			$ResultArray[] = array("message"=>"No record found");
		}*/
		return $ResultArray;
	}

	
	function getTeamDetails($id){
		global $global_config, $table_config;
		$sql="SELECT * FROM  ".$table_config['team']." WHERE Id='".$id."'";
		$results=SelectQry($sql);
		if(count($results)>=1){
			$TeamName = $results[0]['TeamName'];
			$TeamIcon = SITEGLOBALUPLOADPATH.'team/'.$results[0]['TeamIcon'];
			$details = array('TeamName'=>$TeamName,'TeamIcon'=>$TeamIcon);
		}
		return $details;
	}
	
	
	
	function getBetDetails(){
		global $table_config,$global_config,$countrylist;
		$sql="SELECT * FROM ".$table_config["bet"]." WHERE Status ='Active' ORDER BY Id DESC";
		$results=SelectQry($sql);
		return $results;

	}
   function getBetDetailsByCountry($country,$strdate){
   		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$strdate = strtotime($strdate);
		$strdate = $strdate;
		
		if(!empty($country)) {
			if($country == "CANADA") {
				$countryid="1";
			} elseif($country == "USA") {
				$countryid="2";
			} else {
				$countryid =3;
			}
			if($countryid!=0){
			$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$countryid."' AND Status ='Active' AND IsDeleted='No' ORDER BY Position ASC";
			$results=SelectQry($sql);
			}
			//echo $sql; exit;
		} 
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= $result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$position		= $result['Position'];
				$isdeleted = $result['IsDeleted'];
				
				/*if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}*/
				
				if(!empty($result['Description'])) { 
					$BetDescription  = "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
					$BetDescription .= replace($result['Description']);
					$BetDescription .= '</body></html>';
				} else {
				$BetDescription = '';
				}
				
				$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "BetDescription"=>$BetDescription, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Position"=>$position);
			}		
		} else {
				$ResultArray = array("No records found");
		}
		return $ResultArray;
	  
	}
	
   function getBetDetailsByCountryWithDate($country,$strdate){
   		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$strdate = strtotime($strdate);
		$strdate = $strdate;
		
		if(!empty($country)) {
			if($country == "CANADA") {
				$countryid="1";
			} elseif($country == "USA") {
				$countryid="2";
			} else {
				$countryid =3;
			}
			if($countryid!=0){
			$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$countryid."' AND ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."') OR IsDeleted='Yes' ) AND Status ='Active' ORDER BY Id DESC";
			$results=SelectQry($sql);
			}
			//echo $sql; exit;
		} 
		if(count($results) > 0) {
				$ResultArray = getBetDetailsByCountry($country,$strdate);
		} else {
				$ResultArray = array("No records found");
		}
		
		/*if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= $result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$position		= $result['Position'];
				$isdeleted = $result['IsDeleted'];
				
				
				if(!empty($result['Description'])) { 
					$BetDescription  = "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
					$BetDescription .= replace($result['Description']);
					$BetDescription .= '</body></html>';
				} else {
				$BetDescription = '';
				}
				
				$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "BetDescription"=>$BetDescription, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Position"=>$position);
			}		
		} else {
				$ResultArray = array("No records found");
		}*/
		return $ResultArray;
	  
	}
	
	 function getBetDetailsByCountryID($country){
		global $table_config,$global_config,$countrylist;
		if($_REQUEST['date']){
			$strdate = $_REQUEST['date'];
			$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active' AND IsDeleted='No' ORDER BY Position ASC";
		}else{
			$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active' AND IsDeleted='No' ORDER BY Position ASC";
		}
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= $result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$position		= $result['Position'];
				$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "AddedDate"=>$AddedDate,"Position"=>$position);
			}		
		} else {
				if($_REQUEST['date']){
					$total			 = dogetTotalBets1($country);
					$checkAllDeleted = dogetAllDeletedBets1($country);
					if($total>=1){
						if($total == $checkAllDeleted){
							$ResultArray=array("All deleted");
						}
					}else{
						$ResultArray = array("No records found");
					}
				}else{
					$ResultArray = array("No records found");
				}
		}
		return $ResultArray;
	  
	}
	
	 function getBetDetailsByDate($objArray,$country){
	 	//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active'";
		//$strdate  = strtotime($strdate);
		$strdate  = $objArray['date'];
		$ResultArray =array();
		//$sql="SELECT * FROM ".$table_config["bet"]." WHERE ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) AND Country = '".$country."'  ORDER BY Id DESC";
		if(!empty($country)) {
			$sql="SELECT * FROM ".$table_config["bet"]." WHERE ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."'))  AND Country = '".$country."' ORDER BY Id DESC";
		} else {
			$sql="SELECT * FROM ".$table_config["bet"]." WHERE ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."'))  ORDER BY Id DESC";
		}
		
		$results=SelectQry($sql);
		
		//printArray($results);
		/*if(count($results) > 0) {
			foreach($results as $res) {
			$ResultArray = getBetDetailsByCountry($res['Country'],$objArray['date']);
			}
		} else {
			$ResultArray = array("No records found");
		}*/
		return count($results);
		/*if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= SITEGLOBALUPLOADPATH.'bet/'.$result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				echo $Country; exit;
				$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
				
			}		
		} else {
				$ResultArray = array("No records found");
		}*/
		//return $ResultArray;
	  
	}
	
	 function getBetDetailsByDateMore($strdate,$country){
	 	//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active'";
		$strdate  = strtotime($strdate);
		$ResultArray =array();
		$sql="SELECT * FROM ".$table_config["bet"]." WHERE Country = '".$country."'  ORDER BY ModifiedDate DESC LIMIT 0,1";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= SITEGLOBALUPLOADPATH.'bet/'.$result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				//echo $Country; exit;
				$ResultArray = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
			}		
		} else {
				//$ResultArray = array("No records found");
		}
		return $ResultArray;
	  
	}
	
	
	function GetWeekDetailsById($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
	
	function GetWeekDetailsByIdNew($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
	
	function getGroupedDates($spotId){
		$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		$strResult = SelectQry($sql);
		for($i=0;$i<count($strResult);$i++){
			$date = date('d-m-Y',strtotime($strResult[$i]['PickDate']));
			$type = getDateType($date);
			$fres[] = array('date'=>$date,'type'=>$type);
		}
		return $fres;
	}
	function getDateType($passDate){
		$curr	   = date('Y-m-d');
		if( strtotime($passDate) >= strtotime($curr) ) {
			return "future";			
		}else{
			return "past";
		}
	}
	function checkWeekDate($weekId){
		$sql = "select * from tbl_week WHERE Id ='".$weekId."' ";
		$strResult = SelectQry($sql);
	    $finalAry  = $strResult[0];
		$startDate = $finalAry['startdate'];
		$endDate   = $finalAry['enddate'];
		$curr	   = date('Y-m-d');
		if(strtotime($endDate)>=strtotime($curr)){
			return 'future';
		}else{
			return 'past';
		}
	
	}
	function getWeekDates($weekId){
		$sql = "select startdate,enddate from tbl_week WHERE Id ='".$weekId."' ";
		$strResult = SelectQry($sql);
		$finalAry['startdate'] = $strResult[0]['startdate'] ;
		$finalAry['enddate']   = $strResult[0]['enddate'] ;
		return $finalAry;
	}
	function getWeekIdsByName($name){
		$sql = "select * from tbl_week WHERE name ='".$name."' ";
		$strResult = SelectQry($sql);
		return $strResult[0]['Id'];
	}
	function getGroupedWeeks($spotId){
		global $table_config,$global_config,$countrylist;
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$strResult = SelectQry($sql);
		for($i=0;$i<count($strResult);$i++){
			$date ='';
			$nameAry = GetWeekDetailsById($table_config['week'],$strResult[$i]['NFLPick']);
			$date    = $nameAry['name'];
			$type    = checkWeekDate($strResult[$i]['NFLPick']);
			$NewRes  = getWeekDates($strResult[$i]['NFLPick']);
			$Sdate    = $NewRes['startdate'];
			$Edate    = $NewRes['enddate'];
			$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate);
		}
		
		return $fres;
	}
	
	function getGroupedDatesNew($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		//$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND DATE(PickDate) >= CURDATE() AND  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		$strfinaldate = strtotime($strdate);
		if(empty($strdate)) {
			 $sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND  UNIX_TIMESTAMP(PickDate) >= UNIX_TIMESTAMP(NOW()) AND IsDeleted='No' GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		} else {
			$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND  ((UNIX_TIMESTAMP(AddedDate) >= '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) >= '".$strfinaldate."'))  AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND IsDeleted='No'  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		}
		
		
		$strResult = SelectQry($sql);
		
		if(count($strResult)>=1 && $_REQUEST['date']!=''){
			 $sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND  UNIX_TIMESTAMP(PickDate) >= UNIX_TIMESTAMP(NOW()) AND IsDeleted='No' GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
			 $strResult = SelectQry($sql);
		}
		
		for($i=0;$i<count($strResult);$i++){
			$date = date('d-m-Y',strtotime($strResult[$i]['PickDate']));
			$type = getDateType($date);
			if($i==0){
				$type='present';
			}
			$fres[] = array('date'=>$date,'type'=>$type);
		}
		return $fres;
	}	
	
	function getPendingGroupedDatesNew($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		//$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND DATE(PickDate) >= CURDATE() AND  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		$strfinaldate = strtotime($strdate);
		if(empty($strdate)) {
			$sql = "select PickDate from tbl_pick where ";
			if ($spotId > -1) $sql = $sql."SportName ='".$spotId."' AND ";
			$sql .= "IsDeleted='No' AND PickStatus='Pending'  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		} else {
			$sql = "select PickDate from tbl_pick where ";
			if ($spotId > -1) $sql = $sql."SportName ='".$spotId."' AND ";
			$sql .= "  ((UNIX_TIMESTAMP(PickDate) >= '".$strfinaldate."') ) AND IsDeleted='No' AND PickStatus='Pending'   GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		}
		$strResult = SelectQry($sql);
		

		
		if(count($strResult)>=1 && $_REQUEST['date']!=''){
			 $sql = "select PickDate from tbl_pick where ";
			if ($spotId > -1) $sql = $sql."SportName ='".$spotId."' AND ";
			$sql .= " IsDeleted='No' AND PickStatus='Pending' GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
			 $strResult = SelectQry($sql);
		}
		
		
		for($i=0;$i<count($strResult);$i++){
			$date = date('d-m-Y',strtotime($strResult[$i]['PickDate']));
			$type = getDateType($date);
			if($i==0){
				$type='present';
			}
			$fres[] = array("date"=>$date,"type"=>$type);
		}
		
 
		return $fres;
	}

	function getFreePendingGroupedDatesNew($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		//$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND DATE(PickDate) >= CURDATE() AND  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		$strfinaldate = strtotime($strdate);
		if(empty($strdate)) {
			$sql = "select PickDate from tbl_pick where ";
			if ($spotId > -1) $sql = $sql."FreePick=1 AND ";
			$sql .= "IsDeleted='No' AND PickStatus='Pending'  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		} else {
			$sql = "select PickDate from tbl_pick where ";
			if ($spotId > -1) $sql = $sql."FreePick=1 AND ";
			$sql .= "  ((UNIX_TIMESTAMP(PickDate) >= '".$strfinaldate."') ) AND IsDeleted='No' AND PickStatus='Pending'   GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		}
		$strResult = SelectQry($sql);
		

		
		if(count($strResult)>=1 && $_REQUEST['date']!=''){
			 $sql = "select PickDate from tbl_pick where ";
			if ($spotId > -1) $sql = $sql."FreePick=1 AND ";
			$sql .= " IsDeleted='No' AND PickStatus='Pending' GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
			 $strResult = SelectQry($sql);
		}
		
		
		for($i=0;$i<count($strResult);$i++){
			$date = date('d-m-Y',strtotime($strResult[$i]['PickDate']));
			$type = getDateType($date);
			if($i==0){
				$type='present';
			}
			$fres[] = array("date"=>$date,"type"=>$type);
		}
		
 
		return $fres;
	}



	function getPicksDetailsNew($tbl_name,$sportid,$weekIds='',$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strdate  = strtotime($strDate);
		$strdate  = $strDate;
		if($sportid==1) {
			if($weekIds && empty($strdate)){
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) AND IsDeleted='No'  GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if($weekIds && !empty($strdate)) {
				//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) AND ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."')) AND IsDeleted='No' GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if(empty($weekIds) && !empty($strdate)) {
				//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."')) AND IsDeleted='No' GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else{
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND IsDeleted='No'   GROUP BY NflPick  ORDER BY NflPick ASC ";
			}
		} else if(!empty($strDate)) {
			//$sql="SELECT * FROM ".$tbl_name." WHERE SportName='".$sportid."' AND  ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) ORDER BY PickDate";
			$sql="SELECT * FROM ".$tbl_name." WHERE ";
			if ($sportid > -1) $sql=$sql."SportName='".$sportid."' AND ";
			$sql=$sql." ((date(PickDate) >= '".$strdate."') ) AND IsDeleted='No'   AND PickStatus='Pending' ORDER BY PickDate";
		} else {
			$sql="SELECT * FROM ".$tbl_name." WHERE ";
			if ($sportid > -1) $sql=$sql."SportName='".$sportid."' AND ";
			$sql=$sql." IsDeleted='No'  AND PickStatus='Pending' GROUP BY DATE(PickDate)  ORDER BY PickDate ASC ";
		}
		
		$results=SelectQry($sql);
		if(count($results)>=1 && $_REQUEST['date']!=''){
	   	    $sql="SELECT * FROM  ".$tbl_name." WHERE ";
	   	    if ($sportid > -1) $sql .=" SportName='".$sportid."' AND ";
	   	    $sql .=" IsDeleted='No' AND PickStatus='Pending' GROUP BY DATE(PickDate)  ORDER BY PickDate ASC ";	
			$results=SelectQry($sql);
		}
		

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$sportname 			= $result['SportName'];
				$pickdate 			= date('Y-m-d',strtotime($result['PickDate']));
				$nflpick 			= $result['NflPick'];

				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportname,"PickDate"=>$pickdate,
				"NflPick"=>$nflpick,
				"FreePick"=>$result['FreePick']
				);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found", 
									"sql"=>$sql
								);
		}
		return $ResultArray;
	}

	function getFreePicksDetailsNew($tbl_name,$sportid,$weekIds='',$strDate)
	{
		
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strdate  = strtotime($strDate);
		$strdate  = $strDate;
		if($sportid==1) {
			if($weekIds && empty($strdate)){
				$sql="SELECT * FROM  ".$tbl_name." WHERE FreePick=1 AND NflPick IN($weekIds) AND IsDeleted='No'  GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if($weekIds && !empty($strdate)) {
				//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE FreePick=1 AND NflPick IN($weekIds) AND ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."')) AND IsDeleted='No' GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if(empty($weekIds) && !empty($strdate)) {
				//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE FreePick=1 AND ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."')) AND IsDeleted='No' GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else{
				$sql="SELECT * FROM  ".$tbl_name." WHERE FreePick=1 AND IsDeleted='No'   GROUP BY NflPick  ORDER BY NflPick ASC ";
			}
		} else if(!empty($strDate)) {
			//$sql="SELECT * FROM ".$tbl_name." WHERE SportName='".$sportid."' AND  ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) ORDER BY PickDate";
			$sql="SELECT * FROM ".$tbl_name." WHERE ";
			if ($sportid > -1) $sql=$sql."FreePick=1 AND ";
			$sql=$sql." ((date(PickDate) >= '".$strdate."') ) AND IsDeleted='No'   AND PickStatus='Pending' ORDER BY PickDate";
		} else {
			$sql="SELECT * FROM ".$tbl_name." WHERE ";
			if ($sportid > -1) $sql=$sql."FreePick=1 AND ";
			$sql=$sql." IsDeleted='No'  AND PickStatus='Pending' GROUP BY DATE(PickDate)  ORDER BY PickDate ASC ";
		}
		
		$results=SelectQry($sql);
		if(count($results)>=1 && $_REQUEST['date']!=''){
	   	    $sql="SELECT * FROM  ".$tbl_name." WHERE ";
	   	    if ($sportid > -1) $sql .="FreePick=1 AND ";
	   	    $sql .=" IsDeleted='No' AND PickStatus='Pending' GROUP BY DATE(PickDate)  ORDER BY PickDate ASC ";	
			$results=SelectQry($sql);
		}
		

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$sportname 			= $result['SportName'];
				$pickdate 			= date('Y-m-d',strtotime($result['PickDate']));
				$nflpick 			= $result['NflPick'];

				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportname,"PickDate"=>$pickdate,
				"NflPick"=>$nflpick,
				"FreePick"=>$result['FreePick']
				);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found", 
									"sql"=>$sql
								);
		}
		return $ResultArray;
	}
	
	function getPicksDetailsNewWithDate($tbl_name,$sportid,$weekIds='',$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		//$strdate  = strtotime($strDate);
		$strdate  = $strDate;
		if($sportid==1) {
			if($weekIds && empty($strdate)){
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if($weekIds && !empty($strdate)) {
				//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if(empty($weekIds) && !empty($strdate)) {
				//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else{
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY NflPick  ORDER BY NflPick ASC ";
			}
		} else if(!empty($strDate)) {
			//$sql="SELECT * FROM ".$tbl_name." WHERE SportName='".$sportid."' AND  ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) ORDER BY PickDate";
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) GROUP BY NflPick  ORDER BY NflPick ASC ";
		} else {
			//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND DATE(PickDate) >= CURDATE() GROUP BY DATE( PickDate )  ORDER BY PickDate ASC ";
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) GROUP BY NflPick  ORDER BY NflPick ASC ";
		}
		//echo $sql; exit;
		$results=SelectQry($sql);

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$sportname 			= $result['SportName'];
				$pickdate 			= date('Y-m-d',strtotime($result['PickDate']));
				$nflpick 			= $result['NflPick'];

				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportname,"PickDate"=>$pickdate,
				"NflPick"=>$nflpick,
				"FreePick"=>$result['FreePick']
				);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getGroupedWeeksNewWithoutDate($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$strfinalDate = strtotime($strdate);
		$strfinalDate = $strdate;
		/*if(empty($strdate)) {
			$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' GROUP By NFLPick  ORDER BY NFLPick ASC";
		} else {
			$sql = "select NFLPick, AddedDate, ModifiedDate, IsDeleted from tbl_pick where SportName ='".$spotId."' AND ((date(AddedDate) >= '".$strfinalDate."') OR (date(ModifiedDate) >= '".$strfinalDate."')) AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		}*/
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		//echo $sql;
		$strResult = SelectQry($sql);
		$k=0;
		
		for($i=0;$i<count($strResult);$i++){
			if (checkWeekDate($strResult[$i]['NFLPick'])!='') {
				$date ='';
				$nameAry = GetWeekDetailsById($table_config['week'],$strResult[$i]['NFLPick']);
				$date    = $nameAry['name'];
				$type    = checkWeekDate($strResult[$i]['NFLPick']);
				$NewRes  = getWeekDates($strResult[$i]['NFLPick']);
				$Sdate    = $NewRes['startdate'];
				$Edate    = $NewRes['enddate'];
				/*if($k==0){
					$type='present';
				}*/
				$AddedDate = $strResult[$i]['AddedDate'];
				$ModifiedDate = $strResult[$i]['ModifiedDate'];
				$isdeleted = $strResult[$i]['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate);
				$k++;
			}
		}
		return $fres;
	}
	
	function getGroupedWeeksNew($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$strfinalDate = strtotime($strdate);
		$strfinalDate = $strdate;
		if(empty($strdate)) {
			$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."'  AND IsDeleted='No'  GROUP By NFLPick  ORDER BY NFLPick ASC";
		} else {
			//$sql = "select NFLPick, AddedDate, ModifiedDate, IsDeleted from tbl_pick where SportName ='".$spotId."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinalDate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinalDate."')) GROUP By NFLPick  ORDER BY NFLPick ASC";
			$sql = "select NFLPick, AddedDate, ModifiedDate, IsDeleted from tbl_pick where SportName ='".$spotId."' AND ((date(AddedDate) >= '".$strfinalDate."') OR (date(ModifiedDate) >= '".$strfinalDate."')) AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		}
		//echo $sql;
		$strResult = SelectQry($sql);
		$k=0;
		if(count($strResult) > 0) {
			//return getGroupedWeeksNewForModify($spotId);
			$test = getGroupedWeeksNewWithoutDate($spotId,$strdate);
			return $test;
		}
		/*for($i=0;$i<count($strResult);$i++){
			if (checkWeekDate($strResult[$i]['NFLPick']) == 'future') {
				$date ='';
				$nameAry = GetWeekDetailsById($table_config['week'],$strResult[$i]['NFLPick']);
				$date    = $nameAry['name'];
				$type    = checkWeekDate($strResult[$i]['NFLPick']);
				$NewRes  = getWeekDates($strResult[$i]['NFLPick']);
				$Sdate    = $NewRes['startdate'];
				$Edate    = $NewRes['enddate'];
				if($k==0){
					$type='present';
				}
				$AddedDate = $strResult[$i]['AddedDate'];
				$ModifiedDate = $strResult[$i]['ModifiedDate'];
				$isdeleted = $strResult[$i]['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate);
				$k++;
			}
		}*/
		//return $fres;
	}
	
	function getGroupedWeeksNewForModify($spotId){
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$strfinalDate = strtotime($strdate);
		$strfinalDate = $strdate;
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' GROUP By NFLPick  ORDER BY NFLPick ASC";
		//echo $sql;
		$strResult = SelectQry($sql);
		$k=0;
		for($i=0;$i<count($strResult);$i++){
			if (checkWeekDate($strResult[$i]['NFLPick']) == 'future') {
				$date ='';
				$nameAry = GetWeekDetailsById($table_config['week'],$strResult[$i]['NFLPick']);
				$date    = $nameAry['name'];
				$type    = checkWeekDate($strResult[$i]['NFLPick']);
				$NewRes  = getWeekDates($strResult[$i]['NFLPick']);
				$Sdate    = $NewRes['startdate'];
				$Edate    = $NewRes['enddate'];
				if($k==0){
					$type='present';
				}
				$AddedDate = $strResult[$i]['AddedDate'];
				$ModifiedDate = $strResult[$i]['ModifiedDate'];
				$isdeleted = $strResult[$i]['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate);
				$k++;
			}
		}
		
		
		return $fres;
	}
	
		function getCurrentSportsDetails() {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		$strfinaldate = strtotime($strDate);
		$sql="SELECT * FROM ".$table_config["sport"]." WHERE Status ='Active' AND IsDeleted ='No'";
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				if($id==1){
					$res = getNFLcountDateBase($id);
					$count = count($res);
				}else{
					$res = getOtherSportscountDateBase($id);
					$count = count($res);
				}
				if($count==0){
					$count = '';
				}
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"count"=>$count);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	function getSubscriptions()  {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["subscription"]." WHERE enabled = 1";
		$results=FetchQryAsAssoc($sql);
		return $results;		
	}
	
	function getSubscriptionsByUser($userId)  {
		
		global $table_config,$global_config;
		 
		if ($userId) {
			$user_subscriptions  = getUserSubscriptions($userId);
			$user_picks  = getUserPicks($userId);
		}else{
			$user_subscriptions = array();	
			$user_picks = array();
		}
			
		return array("Subscriptions"=>getSubscriptions(),
		 "User_Subscriptions"=>$user_subscriptions,
		 "User_Picks"=>$user_picks
		 );		
	}
	

	function getMainSportsDetails($objArray,$strDate='') {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		$strfinaldate = strtotime($strDate);
		if(isset($objArray['id']) && empty($strDate)) {
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$objArray['id']."' AND Status ='Active' AND IsDeleted ='No' ";
		} else if(isset($objArray['id']) && !empty($strDate)) {
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$objArray['id']."' AND ((date(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND Status ='Active' ";
		} else {	
			$sql="SELECT * FROM ".$table_config["sport"]." WHERE Status ='Active' AND IsDeleted ='No' ";
		}
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				$count = '';
				if($id==1){
					$res = getNFLcount($id);
					$count = count($res);
				}else{
					$res = getOtherSportscount($id);
					$count = count($res);
				}
				// if($count==0){
// 				//	$count = '';
// 				//}
				
				$freePicksCount = '';
				if($id==1){
					$res = getNFLFreePicksCount($id);
					$freePicksCount = count($res);
				}else{
					$res = getOtherSportsFreePicksCount($id);
					$freePicksCount = count($res);
				}
				//if($count==0){
				//	$freePicksCount = '';
				//}

				$sql = "select * from tbl_pick where SportName ='".$id."' AND PickStatus='Pending' AND IsDeleted='No'   AND FreePick=0    ORDER BY NFLPick ASC";
				
				$picks = SelectQry($sql);

				$dateAry 	 = getPendingGroupedDatesNew($id,$_REQUEST['date']);
				
				$res = array();

				if(count($dateAry)>=1){ 
					$res['keys'] = $dateAry;
				}
				
				for($i=0;$i<count($picks);$i++)
				{
					
					//$res['pickDate'] = 	$ResultArray[$i]['PickDate'];
					$strdate 	= strtotime($picks[$i]['PickDate']);
					$finaldate  = date('d-m-Y',$strdate);
					$pickdate = date('Y-m-d', $strdate);
					$weekname = GetWeekDetailsById($table_config['week'], $picks[$i]['NflPick']);
					$weekname = $weekname['name'];
					if($picks[$i]['SportName']==1) {
							$res[$weekname] = getNflPickDetailsById($table_config['picks'],$picks[$i]['NflPick'],$id,$_REQUEST['date']);
					} else {
							$res[$finaldate]= getPendingPickDetailsById($table_config['picks'],$pickdate,$id,$_REQUEST['date']);
					}
				}

				//print_r($res);exit;
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,
				"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, 
				"AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,
				"count"=>$count, "freePicksCount"=>$freePicksCount, "Ranking" => $result['Ranking'], "picks" => $res);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	function getNFLcount($spotId){
		global $table_config,$global_config,$countrylist;
		//$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No'  AND FreePick=0  ORDER BY NFLPick ASC";
		$res = SelectQry($sql);
		return $res;
	}
	function getNFLFreePicksCount($spotId){
		global $table_config,$global_config,$countrylist;
		//$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' AND FreePick=1 ORDER BY NFLPick ASC";
		$res = SelectQry($sql);
		return $res;
	}

	function getOtherSportscount($spotId){
		global $table_config,$global_config,$countrylist;
		//$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No'   AND FreePick=0    ORDER BY NFLPick ASC";
		$res = SelectQry($sql);
		return $res;
	}
	function getOtherSportsFreePicksCount($spotId){
		global $table_config,$global_config,$countrylist;
		//$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' AND FreePick=1 ORDER BY NFLPick ASC";
		$res = SelectQry($sql);
		return $res;
	}
	function getNFLcountDateBase($spotId){
		global $table_config,$global_config,$countrylist;
		//$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No'    ORDER BY NFLPick ASC";
		$res = SelectQry($sql);
		return $res;
	}
	function getOtherSportscountDateBase($spotId){
		global $table_config,$global_config,$countrylist;
		//$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' AND PickStatus='Pending' AND IsDeleted='No'    ORDER BY NFLPick ASC";
		$res = SelectQry($sql);
		return $res;
	}
	
	function dogetAllDeleted($sportId){
		$sql = "select COUNT(Id) as tot from tbl_pick where SportName ='".$sportId."' AND IsDeleted='Yes'";
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function dogetTotal($sportId){
		$sql = "select COUNT(Id) as tot from tbl_pick where SportName ='".$sportId."'";
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	
	function dogetAllDeletedSports($date=''){
		if($date){
			$sql = "select COUNT(Id) as tot from tbl_sport where  ((date(AddedDate) >= '".$date."') OR (date(ModifiedDate) >= '".$date."')) AND IsDeleted='Yes'";
		}else{
			$sql = "select COUNT(Id) as tot from tbl_sport where  IsDeleted='Yes'";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function dogetTotalSports($date=''){
		if($date){
			$sql = "select COUNT(Id) as tot from tbl_sport where  ((date(AddedDate) >= '".$date."') OR (date(ModifiedDate) >= '".$date."')) AND IsDeleted='Yes'";
		}else{
			$sql = "select COUNT(Id) as tot from tbl_sport";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	
	function dogetAllDeletedBets($country){
		if($country == "CANADA") {
				$countryid="1";
			} elseif($country == "USA") {
				$countryid="2";
			} else {
				$countryid =3;
			}
		if($countryid){
			$sql = "select COUNT(Id) as tot from tbl_bets where Country='".$countryid."' AND IsDeleted='Yes'";
		}else{	
			$sql = "select COUNT(Id) as tot from tbl_bets where  IsDeleted='Yes'";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function dogetTotalBets($country){
		   if($country == "CANADA") {
				$countryid="1";
			} elseif($country == "USA") {
				$countryid="2";
			} else {
				$countryid =3;
			}
		if($countryid){
			$sql = "select COUNT(Id) as tot from tbl_bets where Country='".$countryid."' AND IsDeleted='Yes'";
		}else{		
			$sql = "select COUNT(Id) as tot from tbl_bets";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}	
	
	function dogetAllDeletedBets1($countryid){
		if($countryid){
			$sql = "select COUNT(Id) as tot from tbl_bets where Country='".$countryid."' AND IsDeleted='Yes'";
		}else{	
			$sql = "select COUNT(Id) as tot from tbl_bets where  IsDeleted='Yes'";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function dogetTotalBets1($countryid){
		  
		if($countryid){
			$sql = "select COUNT(Id) as tot from tbl_bets where Country='".$countryid."' AND IsDeleted='Yes'";
		}else{		
			$sql = "select COUNT(Id) as tot from tbl_bets";
		}
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function dogetPendingTotal($sportId='',$date=''){
		$sql = "select COUNT(Id) as tot from tbl_pick where SportName ='".$sportId."' AND PickStatus='Pending'";
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function dogetPendingTotalDeleted($sportId,$date=''){
		$sql = "select COUNT(Id) as tot from tbl_pick where SportName ='".$sportId."' AND PickStatus='Pending' AND IsDeleted='Yes'";
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}
	function validatePicksAndriod(){
		$strdate = $_REQUEST['date'];
		$sql="SELECT COUNT(Id) as tot FROM  tbl_pick WHERE ((date(AddedDate) >= '".$strdate."') OR (date(ModifiedDate) >= '".$strdate."')) AND IsDeleted='No' ORDER BY NflPick ASC ";
		$results=SelectQry($sql);
		return $results[0]['tot'];
	}

	function deletesubscription($trid, $user, $sid)
	{
	    $q1 = 'SELECT * FROM tbl_transactions WHERE Id="'.$trid.'"';
	    $resTrans    =   SelectQry($q1);
	    
		if(count($resTrans) > 0) {
		    for($i=0;$i<count($resTrans);$i++){
		        $transId = $resTrans[$i]["Id"];
		        $paymentType = $resTrans[$i]["payment_type"];
		        $isSubCancel = $resTrans[$i]["is_sbuscription_cancel"];
		        $paypalSubsId = $resTrans[$i]["subscription_id"];
		        $productId  = $resTrans[$i]["ProductId"];
		        //echo $productId;
            	$query = 'SELECT * FROM tbl_subscription WHERE ProductId="'.$productId.'"';
    			$resSubs = SelectQry($query);
    			//print_r($resSubs);
	            //exit;
    			if(count($resSubs) > 0){
    			    $subsId = $resSubs[0]["Id"];
    			    $sql="SELECT * FROM tbl_user_subscription WHERE is_new_app_subscription='Y' and User = '".$user."' and subscription_id = '".$subsId."'";
            		$results    =   FetchQryAsAssoc($sql);
            		if(count($results) > 0) {
            		    for($j=0;$j<count($results);$j++){
            		        deleteUserSubsciption($transId,$results[$j]['Id']);
            			}
    				}
		    	}
			}
    	}
    	
		/*$sql1 = 'DELETE FROM tbl_transactions WHERE Id="'.$trid.'"';
		mysql_query($sql1);

		$sql2 = 'DELETE FROM tbl_user_subscription WHERE User="'.$user.'" AND Sport="'.$sid.'"';
		mysql_query($sql2);*/
		return 1;
	}

	function addusersubscription($user, $sport, $expirydate)
	{
		$query = 'INSERT INTO tbl_user_subscription(User, Sport, ExpiryDate) VALUES("'.$user.'", "'.$sport.'", "'.$expirydate.'")';
		mysql_query($query);
		return 1;
	}

	function addusertransaction($user, $productid)
	{
		$purchasedate = date("Y-m-d");
		$updatedon = date("Y-m-d G:i:s");
		$query = 'INSERT INTO tbl_transactions(User, ProductId, PurchasedDate, updatedAt) VALUES("'.$user.'", "'.$productid.'", "'.$purchasedate.'", "'.$updatedon.'")';
		mysql_query($query);
		return 1;
	}

	function updatedevicetoken($deviceid, $device)
	{
		$select = 'SELECT * FROM tbl_deviceids WHERE deviceid="'.$deviceid.'"';
		$results=SelectQry($select);
		if(count($results)==0){
			$createddate = date("Y-m-d G:i:s");
			$query = 'INSERT INTO tbl_deviceids(deviceid,device,updatedat) VALUES("'.$deviceid.'","'.$device.'", "'.$createddate.'")';
			mysql_query($query);
		}
		$ResultArray = array("status" => "success", "message"=>"Device has been added");
		return $ResultArray;
	}

	function getalldevicetokens()
	{
		$qry = 'SELECT * FROM tbl_deviceids WHERE deviceid != "null"';
		$results = SelectQry($qry);
		return $results;
	}

	function gettimeinterval()
	{
		$query = 'SELECT time_interval from tbl_admin WHERE Id=7';
		$result = SelectQry($query);
		return $result[0];
	}

	function updatetimeinterval($interval, $price)
	{
		$query = 'UPDATE tbl_admin SET time_interval="'.$interval.'", packageprice="'.$price.'" WHERE Id=7';
		mysql_query($query);
		return 1;
	}

	function checkforsubscription($user)
	{
		$query = 'SELECT * FROM tbl_user_subscription WHERE User='.$user;
		$res = SelectQry($query);
		$main = count($res);

		$picks = 'SELECT * FROM tbl_user_picks WHERE User='.$user;
		$res = SelectQry($picks);
		$pickscount = count($res);
		if($pickscount >= 1 && $main == 0){
			return true;
		}
		return false;
	}

	function checklastalert($user)
	{
		$query = 'SELECT * FROM tbl_alertupdates WHERE user = '.$user." ORDER BY updatedat DESC limit 1";
		$res = SelectQry($query);
		if(count($res) >= 1){
			return $res[0];
		}else{
			return array();
		}
	}

	function getintervals()
	{
		$query = 'SELECT * FROM tbl_admin WHERE Id=7';
		$res = SelectQry($query);
		return $res[0]["time_interval"];
	}

	function addalertupdate($id)
	{
		$updatedtime = time();
		$query = 'INSERT INTO tbl_alertupdates(user, updatedat) VALUES("'.$id.'", "'.$updatedtime.'")';
		mysql_query($query);
		return 1;
	}

	function checkfortheofferprice()
	{
		$query = 'SELECT packageprice FROM tbl_admin WHERE Id=7';
		$res = SelectQry($query);
		return $res[0]["packageprice"];
	}

	function loguseragent($post)
	{
		$query = 'SELECT * FROM tbl_user WHERE ipaddr="'.$post["ipaddress"].'"';
		$res = SelectQry($query);
		if(count($res) > 0){
			$user = $res[0]["Id"];
			$updatetime = time();
			$q1 = 'SELECT * FROM tbl_userlogs WHERE user='.$user." ORDER BY updatedon DESC limit 1";
			$result = SelectQry($q1);
			if(count($result) > 0){
				$updated = $result[0]["updatedon"];
				$diff = time()-$updated;
				if($diff > 15*60){
					$sq2 = 'INSERT INTO tbl_userlogs(devicemake, devicemodel, deviceos, devicebrowser, user, updatedon) VALUES("'.$post["device"].'", "'.$post["model"].'", "'.$post["os"].'", "'.$post["browser"].'","'.$user.'", "'.$updatetime.'")';
					mysql_query($sq2);
				}
			}else{
				$sq2 = 'INSERT INTO tbl_userlogs(devicemake, devicemodel, deviceos, devicebrowser, user, updatedon) VALUES("'.$post["device"].'", "'.$post["model"].'", "'.$post["os"].'", "'.$post["browser"].'","'.$user.'", "'.$updatetime.'")';
				mysql_query($sq2);
			}
		}
	}

	function loguseragentandroid($post, $browser)
	{

		$user = $post["user"];
		$updatetime = time();
		$q1 = 'SELECT * FROM tbl_userlogs WHERE user='.$user." ORDER BY updatedon DESC limit 1";
		$result = SelectQry($q1);
		if(count($result) > 0){
			$updated = $result[0]["updatedon"];
			$diff = time()-$updated;
			if($diff > 15*60){
				$sq2 = 'INSERT INTO tbl_userlogs(devicemake, devicemodel, deviceos, devicebrowser, user, updatedon) VALUES("'.$post["device"].'", "'.$post["model"].'", "'.$post["os"].'", "'.$browser.'","'.$user.'", "'.$updatetime.'")';
				mysql_query($sq2);
			}
		}else{
			$sq2 = 'INSERT INTO tbl_userlogs(devicemake, devicemodel, deviceos, devicebrowser, user, updatedon) VALUES("'.$post["device"].'", "'.$post["model"].'", "'.$post["os"].'", "'.$browser.'","'.$user.'", "'.$updatetime.'")';
			mysql_query($sq2);
		}
		echo json_encode(array("status" => "success"));
		exit;
	}

	function getBrowser() 
	{ 
		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
		$bname = 'Unknown';
		$platform = 'Unknown';
		$version= "";

		//First get the platform?
		if (preg_match('/linux/i', $u_agent)) {
			$platform = 'linux';
		}
		elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
			$platform = 'mac';
		}
		elseif (preg_match('/windows|win32/i', $u_agent)) {
			$platform = 'windows';
		}
		
		// Next get the name of the useragent yes seperately and for good reason
		if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
		{ 
			$bname = 'Internet Explorer'; 
			$ub = "MSIE"; 
		} 
		elseif(preg_match('/Firefox/i',$u_agent)) 
		{ 
			$bname = 'Mozilla Firefox'; 
			$ub = "Firefox"; 
		} 
		elseif(preg_match('/Chrome/i',$u_agent)) 
		{ 
			$bname = 'Google Chrome'; 
			$ub = "Chrome"; 
		} 
		elseif(preg_match('/Safari/i',$u_agent)) 
		{ 
			$bname = 'Apple Safari'; 
			$ub = "Safari"; 
		} 
		elseif(preg_match('/Opera/i',$u_agent)) 
		{ 
			$bname = 'Opera'; 
			$ub = "Opera"; 
		} 
		elseif(preg_match('/Netscape/i',$u_agent)) 
		{ 
			$bname = 'Netscape'; 
			$ub = "Netscape"; 
		} 
		
		// finally get the correct version number
		$known = array('Version', $ub, 'other');
		$pattern = '#(?<browser>' . join('|', $known) .
		')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
		if (!preg_match_all($pattern, $u_agent, $matches)) {
			// we have no matching number just continue
		}
		
		// see how many we have
		$i = count($matches['browser']);
		if ($i != 1) {
			//we will have two since we are not using 'other' argument yet
			//see if version is before or after the name
			if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
				$version= $matches['version'][0];
			}
			else {
				$version= $matches['version'][1];
			}
		}
		else {
			$version= $matches['version'][0];
		}
		
		// check if we have a number
		if ($version==null || $version=="") {$version="?";}
		
		return array(
			'userAgent' => $u_agent,
			'name'      => $bname,
			'version'   => $version,
			'platform'  => $platform,
			'pattern'    => $pattern
		);
	}

	function getuserlogs()
	{
		$query = "SELECT * FROM tbl_userlogs ORDER BY updatedon DESC";
		$res = SelectQry($query);
		return $res;
	}

	function forgetpassword($email)
	{
		$query = 'SELECT * FROM tbl_user WHERE Email="'.$email.'"';
		$res = SelectQry($query);
		
		if(count($res) > 0){
			$subject = "Pick Plug Password Recovery Email";
			$message = "Your Password is ".$res[0]["Password"];
			mail($email, $subject, $message);
			$ResultArray = array("status"=>"success","message"=>"Password has been sent to your registered email");
		}else{
			$ResultArray = array("status"=>"error","message"=>"email not exist");
		}
		return $ResultArray;
	} 
		

?>
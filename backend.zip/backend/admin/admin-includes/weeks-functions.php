<?php

	function getAllDetails($tbl_name)	{
		$sql="SELECT * FROM $tbl_name";
		$strResult = SelectQry($sql);
		return $strResult;
	}
	
	function GetAllDetailsById($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
	
	function CheckPicksDataExists($TableName,$ColumnName,$Value,$Field='',$Ident='') {
		if($TableName && $ColumnName && $Value)	
		{
			if($TableName && $ColumnName && $Ident)	
				$where = " Where ".$ColumnName ."  ='". addslashes($Value) . "' and ".$Field."='".$Ident."'";
			else
				$where = " Where ".$ColumnName ." ='". addslashes($Value) . "'";
		}
		$strSql    = "Select Count(*) as Cnt from ".$TableName.$where;
		$Data  	   = SelectQry($strSql);
		return $Data[0][0];
	}
	/* update  details */
	function updateDetails($objArray,$Prefix,$tbl_name,$id) {
		global $global_config;
		$where="WHERE Id='".$id."'";
		$ID=UpdateInfoToDB($objArray,$Prefix,$tbl_name,$where);	
		return $ID;
	}
	
	function getWeekDetails($tbl_name) {
		$sql = "select * from ".$tbl_name." where Id ='1'";
		$strResult = SelectQry($sql);
		return $strResult[0];
	}
	
	
	function insertWeekDetails($tbl_name,$objArray) {
		//printArray($objArray); exit;
		for($m=1;$m<=17;$m++) {
			$weekname = "Week".$m;
			$startdate = $objArray['week'.$m.'_start_date'];
			$enddate = $objArray['week'.$m.'_end_date'];
			$sql = "UPDATE ".$tbl_name." SET `name` = '".$weekname."', `startdate` = '".$startdate."', `enddate` = '".$enddate."' WHERE `Id` = '".$m."'";
			ExecuteQry($sql);
		}	
		$sql1 = "UPDATE ".$tbl_name." SET `name` = 'Wild Card', `startdate` = '".$objArray['wildcard_start_date']."', `enddate` = '".$objArray['wildcard_end_date']."' WHERE `Id` = '18'";
		ExecuteQry($sql1);
		
		$sql2 = "UPDATE ".$tbl_name." SET `name` = 'Divisional', `startdate` = '".$objArray['divisional_start_date']."', `enddate` = '".$objArray['divisional_end_date']."' WHERE `Id` = '19'";
		ExecuteQry($sql2);
		
		$sql3 = "UPDATE ".$tbl_name." SET `name` = 'Championship', `startdate` = '".$objArray['championship_start_date']."', `enddate` = '".$objArray['championship_end_date']."' WHERE `Id` = '20'";
		ExecuteQry($sql3);
		
		$sql4 = "UPDATE ".$tbl_name." SET `name` = 'Pro Bowl', `startdate` = '".$objArray['probowl_start_date']."', `enddate` = '".$objArray['probowl_end_date']."' WHERE `Id` = '21'";
		ExecuteQry($sql4);
		
		$sql5 = "UPDATE ".$tbl_name." SET `name` = 'Super Bowl', `startdate` = '".$objArray['superbowl_start_date']."', `enddate` = '".$objArray['superbowl_end_date']."' WHERE `Id` = '22'";
		ExecuteQry($sql5);
		
		return 1;
	}
	
	function getWeeksDetails($tbl_name,$j) {
		$sql = "select * from ".$tbl_name." where Id ='".$j."'";
		$strResult = SelectQry($sql);
		return $strResult[0];
	}
	

?>
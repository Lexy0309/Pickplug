<?php

	$table_config["admin"]  		  = "tbl_admin";

	$table_config["loginhistory"]  	  = "tbl_login_history";

	$table_config["user"]		  	  = "tbl_user";

	$table_config["sport"]		  	  = "tbl_sport";

	$table_config["team"]		  	  = "tbl_teams";

	$table_config["picks"]		  	  = "tbl_pick";

	$table_config["bet"]		  	  = "tbl_bets";
	$table_config["favorites"]		  	  = "tbl_favorites";
	$table_config["weeks"]		  	  = "tbl_weeks";
	$table_config["week"]		  	  = "tbl_week";
    $table_config["subscription"]     = "tbl_subscription";
    $table_config["transactions"]     = "tbl_transactions";
	$table_config["user_subscription"] = "tbl_user_subscription";
	$table_config["user_picks"]        = "tbl_user_picks";
?>
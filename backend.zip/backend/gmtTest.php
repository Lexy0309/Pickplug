<?php
  $date = '2013-12-20 22:22:40';
  echo $res = date_default_timezone_get();
  echo "<br>";
  echo date('Y-m-d H:i:s');
  echo "<br>";
  
  /*date_default_timezone_set('Asia/Calcutta');
  echo date('Y-m-d H:i:s', strtotime($date));
 echo date('Y-m-d H:i:s');*/


  //date_default_timezone_set('Asia/Calcutta');
  //date_default_timezone_set('UTC');
  echo "<br>";
  //echo gmdate('Y-m-d H:i:s',strtotime($date));
?>
<?php
	include("../includes/common.php");
 	include('pushFunctions.php');
 
	$type 		 = 'dev';
	$message 	 = 'giazzasports push test by ragu';
	//$deviceToken = '344eafc93f8910a2f51efe821528bde71842a738735f7bd23b51cd3134cff862';
	
	$deviceToken = '52ce72ce6002fd277ff5132f8d0b3f7de3a0a323311e4c387c73d58cd2e3fc73';
	
	if($_REQUEST['type']){
	$type = $_REQUEST['type'];
	}
	
	if($_REQUEST['message']){
	$message = $_REQUEST['message'];
	}
	
	if($_REQUEST['deviceToken']){
	$deviceToken = $_REQUEST['deviceToken'];
	}
	
	pushTest($deviceToken,$message,$type);
	
		
?>
<?PHP
	/*include("../includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");*/
/**
* @category Apple Push Notification Service using PHP & MySQL
* @package EasyAPNs
*/

//include('../functions.php');
require_once('Apns/class_APNS.php');
require_once('Apns/class_DbConnect.php');
// CREATE DATABASE OBJECT ( MAKE SURE TO CHANGE LOGIN INFO )

//$db = new DbConnect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

$db = new DbConnect('localhost', 'propicks_giazza ', 'GiazzaApp852', 'propicks_giazzaapp');
$db->show_errors();
// FETCH $_GET OR CRON ARGUMENTS TO AUTOMATE TASKS
$args = (!empty($_GET)) ? $_GET:array('task'=>$argv[1]);
$apns = new APNS($db, $args);
// CREATE APNS OBJECT, WITH DATABASE OBJECT AND ARGUMENTS
//$apns = new APNS($db, $args);
?>
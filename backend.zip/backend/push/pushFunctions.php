<?php
	function doSendMessage($data) {
		$strTodayDate	=	date('Y-m-d');
		$message		=	$data;
		$sql = "INSERT INTO tbl_messages SET Message = '" .$message . "', AddedDate = '".$strTodayDate."'";
		$strMessageID = mysql_query($sql);
		return $strMessageID;
	}
			
	function UpdateMessageStatus($strIdent) {
		mysql_query("UPDATE tbl_messages SET Status = 'Completed' WHERE Ident = '".(int)$strIdent."'");
	}
					
	function doGetAllUserDetails() {
		$query = mysql_query("SELECT * FROM tbl_apns_devices");
		while($arr = mysql_fetch_array($query)) {
			$user_data[] = $arr["devicetoken"];
			$user_data['type'][] = $arr["type"];
		}
		return $user_data;
	}
	
	function DataMessageCnt($strMessageID,$type) {
		//echo "SELECT count(*) as TotalCnt from tbl_messages_device Where MessageId = '".$strMessageID."' AND Status = 'Completed'" ;
		$query = mysql_query("SELECT count(*) as TotalCnt from tbl_messages_device Where MessageId = '".$strMessageID."' AND Status = 'Completed' AND deviceType = '".$type."' ");
		$results = mysql_fetch_array($query);
		return $results[0]['TotalCnt'];
	}
	
	function DataExistsMessage($Message){
		$sql = "SELECT Ident from tbl_messages Where Message = '".$Message."'";
		$result = mysql_query($sql);
		$results = mysql_fetch_array($result);
		if($results)
			return $results[0]['Ident'];
		else
			return 0;	
	}
	
	function DataExistsSendMessage($strMessageID,$deviceToken){
		$query = mysql_query("SELECT count(*) as TotalCnt from tbl_messages_device Where MessageId = '".$strMessageID."' AND Devicetoken = '".$deviceToken."' AND Status = 'Completed'");
		$results = mysql_fetch_array($result);
		return $results[0]['TotalCnt'];
	}
			
	function InsertMessageDevices($strDeviceToken,$strMessageID,$type) {
		$strTodayDate	=	date('Y-m-d');
		mysql_query("INSERT INTO tbl_messages_device SET MessageId = '" .$strMessageID . "', Devicetoken = '".$strDeviceToken."', Status = 'Completed', SendDate = '".$strTodayDate."', deviceType = '".$type."'");
	}
	
		function doSendNotificationMessage($deviceToken,$message) {
			if(!empty($deviceToken) && !empty($message)){
				$absPath = '/home/websolut/public_html/tenerife/push/';
				
			   	$pass = 'tenerife'; // ragu need to add pharse
				$message = str_replace("+", " ",$message);
			
				//$badge = '';	
				$sound = 'default';
				
				$body = array();
				$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			
				if ($badge)
					$body['aps']['badge'] = $badge;
			
				if ($sound)
					$body['aps']['sound'] = $sound;
						
				$ctx = stream_context_create();
					stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
				stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			
				// assume the private key passphase was removed.
				// stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
					$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);
				// for production change the server to ssl://gateway.push.apple.com:2195
			
				/*if (!$fp) {
					print "Failed to connect $err $errstr\n";
					return;
				}
				else {
					print "Connection OK\n";
				}*/
			
				$payload = json_encode($body);
				//echo $deviceToken; exit;
				$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
				
			
				//print $payload;
			
				fwrite($fp, $msg);
				fclose($fp);
			
				stream_context_set_option($ctx, 'ssl', 'verify_peer', false); 
					$fp = stream_socket_client('ssl://feedback.push.apple.com:2196', $error,$errorString, 100, (STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT), $ctx);
		
			}
	}	
	
		
	function doSendNotificationMessageOld($deviceToken,$message) {
		//echo $messageView; exit;
		//echo  ABSPATH.'api/push/apnspro.pem';
		if(!empty($deviceToken) && !empty($message)){
			$pass = 'tenerife';
			$message = str_replace("+", " ",stripslashes($message));
			
		
			//$badge = '';	
			$sound = 'default';
			
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
		
			//if($messageView=="normal") {
				//$body['aps']['content-available'] = "";
			//} else {
				$body['aps']['content-available'] = "1";
			//}

			if ($badge)
				$body['aps']['badge'] = $badge;
		
			if ($sound)
				$body['aps']['sound'] = $sound;
				
							
			$ctx = stream_context_create();
				stream_context_set_option($ctx, 'ssl', 'local_cert', '/opt/lampp/htdocs/up4boxing/api/push/apnspro.pem');
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
		
			// assume the private key passphase was removed.
			// stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
		
			//$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			// for production change the server to ssl://gateway.push.apple.com:2195
			
			
			//echo $fp; exit;	
		
			if (!$fp) {
				print "Failed to connect $err $errstr\n";
				return;
			}
			else {
				print "Connection OK\n";
			}
		    
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
		
			//print $payload;
		
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
        		$msg = 'Message not delivered' . PHP_EOL;
   			} else {
		        $msg = 'Message successfully delivered' . PHP_EOL;
		    }
			global $j;
			$j++;
			fclose($fp);
		
			stream_context_set_option($ctx, 'ssl', 'verify_peer', false); 
			//if($type == 'dev') {
				//$fp = stream_socket_client('ssl://feedback.sandbox.push.apple.com:2196', $error,$errorString, 100, (STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT), $ctx);
			//} else {
				$fp = stream_socket_client('ssl://feedback.push.apple.com:2196', $error,$errorString, 100, (STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT), $ctx);
			//}
	
		}
	}	
	
	function doSendAndroidNotification($message) {
		$apiKey = "AIzaSyDeLXQnbRfKKUZMp2nnPKkqq9UgCRQjT34";
		// TODO Here, list all the regId of the database
		$selectRegId = "SELECT * FROM tbl_androidRegId";
		$result = SelectQry($selectRegId);
		
			$regID = array();
			foreach($result as $res) {
				$regID[] = $res['regId'];
			}
		   $registrationIDs = $regID;
	
			$url = 'https://android.googleapis.com/gcm/send';
			
			$fields = array(
							'registration_ids'  => $registrationIDs,
							'data'              => array( "message" => $message ),
							);
			
			$headers = array(
								'Authorization: key=' . $apiKey,
								'Content-Type: application/json'
							);
			
			// Open connection
			$ch = curl_init();
			
			// Set the url, number of POST vars, POST data
			curl_setopt( $ch, CURLOPT_URL, $url );
			
			curl_setopt( $ch, CURLOPT_POST, true );
			curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			
			curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );
			
			// Execute post
			$result = curl_exec($ch);
			
			// Close connection
			curl_close($ch);
			
			$resAry = json_decode($result);
			//print '<pre>'; print_r($resAry->results); print '</pre>';
			$responseAry = $resAry->results;
			$combine = array_combine($registrationIDs,$responseAry); 
			//echo '<pre>'; print_r($combine);
			return $combine;
		} 

	
	function doSendNotificationMessageNew($deviceToken,$type='',$message='') {
		$absPath = $_SERVER['DOCUMENT_ROOT'].'/app/admin/push/';
		if($type==''){
			$type ='pro';
		}
		if(!empty($message)){
			//echo $deviceToken;
			//echo '<br />';
			//echo $message;
			//echo $type;
			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
			$ctx = stream_context_create();
				//stream_context_set_option($ctx, 'ssl', 'local_cert', ABSPATH.'api/push/apnspro.pem');
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			if($type == 'dev') {
				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			} else {
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
			//print $payload;
			//print $deviceToken."<BR>";
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			fclose($fp);
			}
			//echo $msg;
	}	
	
	function doSendNotificationMessageCron($deviceToken,$type='',$message='') {
		$absPath = $_SERVER['DOCUMENT_ROOT'].'/app/admin/push/';
		if($type==''){
			$type ='pro';
		}
		if(!empty($message)){
			//echo $deviceToken;
			//echo '<br />';
			//echo $message;
			//echo $type;
			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
			$ctx = stream_context_create();
				//stream_context_set_option($ctx, 'ssl', 'local_cert', ABSPATH.'api/push/apnspro.pem');
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			if($type == 'dev') {
				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			} else {
				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
			/*if (!$fp) {
					print "Failed to connect $err $errstr\n";
					return;
			}else {
					print "Connection OK\n";
			}*/
			
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
			//print $payload;
			//print $deviceToken."<BR>";
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			fclose($fp);
			}
	
		
	}		


	function pushTest($deviceToken,$message,$type=''){
		$absPath = $_SERVER['DOCUMENT_ROOT'].'/app/admin/push/';
		if($type==''){
			$type = 'dev';
		}
		if(!empty($message)){

			echo $deviceToken;
			echo '<br />';
			echo $message;
			echo $type;
			$pass = 'giazzasports';
			$message = str_replace("+", " ",stripslashes($message));
				//$badge = '';	
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => array('body' => $message,'action-loc-key' => 'See'));
			if($messageView=="normal") {
				$body['aps']['content-available'] = "";
			} else {
				$body['aps']['content-available'] = "1";
			}
			if ($badge)
				$body['aps']['badge'] = $badge;
			if ($sound)
				$body['aps']['sound'] = $sound;
			$ctx = stream_context_create();
				//stream_context_set_option($ctx, 'ssl', 'local_cert', ABSPATH.'api/push/apnspro.pem');
			if($type == 'dev') {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnsdev.pem');
			} else {
				stream_context_set_option($ctx, 'ssl', 'local_cert', $absPath.'apnspro.pem');
			}
			stream_context_set_option($ctx, 'ssl', 'passphrase', $pass);
			
			if($type == 'dev') {

				$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	

			} else {

				$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);	
			}
	
			if (!$fp) {
					print "Failed to connect $err $errstr\n";
					return;
			}else {
					print "Connection OK\n";
			}
			
			$payload = json_encode($body);
			$msg = chr(0) . pack("n",32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n",strlen($payload)) . $payload;
			print $msg; echo '<br>'; 
			//print $payload;
			//print $deviceToken."<BR>";
			$res = fwrite($fp, $msg, strlen($msg));
			if (!$res) {
				$msg = 'Message not delivered' . PHP_EOL;
			} else {
				$msg = 'Message successfully delivered' . PHP_EOL;
			}	
			
			print $msg;

			fclose($fp);
			}
	}
?>

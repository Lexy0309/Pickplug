<?php
include("../includes/common.php");
include(SITEADMININCLUDEPATH."main-tables.php");
include(SITEADMININCLUDEPATH."common-functions.php");
if(isset($_REQUEST['regId']) && $_REQUEST['regId'] != '') {
	$sql = "Select count(*) as cnt from ".$table_config["androidRegId"]." where regId = '".$_REQUEST['regId']."'";
	$checkDuplicate = Selectqry($sql);
	if($checkDuplicate[0]['cnt']==0){
		$sql = "Insert into ".$table_config["androidRegId"]." (`regId`) Values ('".$_REQUEST['regId']."')";
		ExecuteQry($sql);
		$insertId = mysql_insert_id();
		if($insertId){
			$ResultArray = array("success"=>true, "message"=>"Device registered successfully");
		} else {
			$ResultArray = array("success"=>false, "message"=>"Insertion error");
		}
	} else {
		$ResultArray = array("success"=>false, "message"=>"Already inserted");
	}
} else {
	$ResultArray = array("success"=>false, "message"=>"No devices entered");
}
displayResult3($ResultArray);
?>
<?php
include("../admin/includes/common.php");
require_once(SITEADMININCLUDEPATH."common-functions.php");
include(SITEADMININCLUDEPATH."api-functions.php");


    $appleData      =   file_get_contents('php://input');
    $id 	        =  insertAppleLog('',$appleData);
    $sql            = "select * from apple_subscription_log order by posted_date desc limit 1";
    $resTrans    =   SelectQry($sql);
	if(count($resTrans) > 0) {
	     $log_array		=  json_decode($resTrans[0]['log']);
	     $transaction_Id = $log_array->latest_receipt_info->original_transaction_id;
	     $productId = $log_array->latest_receipt_info->product_id;
	     
	     if ($log_array->notification_type == "CANCEL") {
		    $updatesql = 'UPDATE tbl_transactions SET `is_sbuscription_cancel` = "Y" WHERE TransactionID="'.$transaction_Id.'" and ProductId = "'.$productId.'" and payment_type = "Apple"';
		    //echo $updatesql;
    	    mysql_query($updatesql);
	    
	     }else if ($log_array->notification_type == "RENEWAL" && $log_array->auto_renew_status == "true") {
	         updateAppleSubscriptionExpiryPeriod($transactionId,$productId);
	     }
	     
	    // echo $log_array->notification_type;
    }
   
	
		

		

?>
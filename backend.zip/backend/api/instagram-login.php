<?php 



	include("../admin/includes/common.php");



	require_once(SITEADMININCLUDEPATH."common-functions.php");



	include(SITEADMININCLUDEPATH."api-functions.php");	



	$arr['userPassword'] 		= isset($_REQUEST['password']) ? $_REQUEST['password']:'';



	$arr['userFullName'] 		= isset($_REQUEST['fullname']) ? $_REQUEST['fullname']:'';



	$arr['userToken'] 			= $_REQUEST['token'];



	$arr['userEmail'] 			= $_REQUEST['email'];



	$arr['fbimage'] 			= $_REQUEST['image'];



	$arr['userBirthday'] 		= $_REQUEST['birthday'];



	$arr['userGender'] 			= $_REQUEST['gender'];



	$error ='';



	if((!empty($arr['Email'])) || !empty($arr['userToken']) ){



		$strfbimage = basename($arr['fbimage'] );



		/*if(!empty($img)) {



			$orgfile = $img;



			$newfile = $global_config["SiteLocalUploadPath"].'userImage/'.basename($img);



			copy($orgfile,$newfile);



			$sql = "UPDATE ";



			mysql_query();



		}*/



		$instagramimage = doUploadFbThumbImages($arr['fbimage'],'',$objArray,'tbl_user',$global_config["SiteLocalUploadPath"].'userImage/','thumb','302','302');



		



		$ResultArray = checkInstagramLoginDetails($arr['userFullName'],$arr['userToken'],$arr['userEmail'],$arr['userBirthday'],$arr['userGender'],$instagramimage); 	  



	} else{



		$ResultArray = array("status"=>"failed","message"=>"username and password empty","type"=>"Instagram");			



	}

	

	//printArray($ResultArray);

    displayResult($ResultArray,'Login');



?>
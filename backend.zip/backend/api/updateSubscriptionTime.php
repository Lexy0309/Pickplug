<?php
    include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");
	

 
	 updateSubscriptionExpiryTime();
	


?>


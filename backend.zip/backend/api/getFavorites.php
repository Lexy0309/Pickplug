<?php
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");	
	$error ='';
	$user_session 		= isset($_REQUEST['sessionid']) ? $_REQUEST['sessionid']:'';
	if($user_session){
		$arr['fa_UserId']       = getUserIdFromSession($user_session);
		if($arr['fa_UserId']==0){
			$error = "User session is invalide";
		}	
	}else{
	      $error = " Enter user session id";
	}
	
	if($error=='') {
		if($_REQUEST['sportid']){
			$ResultArray =  getFavoritesBySport($arr['fa_UserId'],$_REQUEST['sportid']);
		}else{
			$ResultArray =  getFavorites($arr['fa_UserId']);
		}
	} else{
		$ResultArray = array("status"=>"failed","message"=>$error);			
	}
	displayResult($ResultArray,'getfavorites');

?>
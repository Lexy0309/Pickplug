<?php 
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");	
	$arr['userPassword'] 		= isset($_REQUEST['password']) ? $_REQUEST['password']:'';
	$arr['Email'] 				= $_REQUEST['email'];
	$error ='';
	if(!empty($arr['Email']) && (!empty($arr['userPassword']))) {
		$ResultArray = checkLoginDetails($arr['Email'],$arr['userPassword']); 
	} else{
		$ResultArray = array("status"=>"failed","message"=>"username and password empty","type"=>"Normal");			
	}
	displayResult($ResultArray,'Login');

?>
<?php 
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	
	$arr = array();
	$arr['PurchasedDate'] 		    = date('Y-m-d');//$_REQUEST['date'];
	$arr['ProductId'] 				= $_REQUEST['productId'];
	$arr['User'] 				    = $_REQUEST['user'];
	$arr['Pick'] 				    = 0;//$_REQUEST['pick'];
	$arr['TransactionID'] 		    = $_REQUEST['transaction_id'];
	$arr['payment_type'] 		    = 'Apple';
	
	mail(getUserEmailById($_REQUEST['user']),"Welcome","You are now new user of PicksApp");
	
	$error ='';
	
	if(!empty($arr['User']) 
	&& !empty($arr['ProductId'])
	&& !empty($arr['PurchasedDate'])
	) {
 
        if($_REQUEST['productId'] == "com.pickplug.monthly_auto_renew_subscription" || $_REQUEST['productId'] == "com.pickplug.yearly_renew"){
            $arr['subscription_id'] =  $_REQUEST['transaction_id'];
        }
        if (isTransactionAlreadyExistsForApple($_REQUEST['user'],$_REQUEST['productId'],$_REQUEST['transaction_id']) == '0'){
            $ResultArray =  addsubscription($arr,'' ); 
        }else{
            $userSubscriptions  = getUserSubscriptions($arr['User']);
			$userPicks 		 = getUserPicks($arr['User']);
			$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully",
					"User_Subscriptions"=>$userSubscriptions,
					"User_Picks"=>$userPicks
			);
        }
	    
		
	} else{
		$ResultArray = array("status"=>"failed","message"=>"user, product id or date is empty","type"=>"Normal");			
	}
	
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>
<?php 
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	
	$arr = array();
	$arr['ProductId_list'] 			= $_REQUEST['productId_list'];
    $arr['User'] 				    = getUserIdByEmail($_REQUEST['user_email']);   


    if(!empty($arr['User']) && !empty($arr['ProductId'])){
        updateSubscription_android($arr);
    }
    
    
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');
?>
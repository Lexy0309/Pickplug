<?php

    include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");

    $user = $_REQUEST["user"];

    echo json_encode(array("response" => "1", "Message" => "Your subscription has been restored"));
    exit;

<?php 
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	
	$arr = array();
	$arr['purchasedate'] 		    = $_REQUEST['purchasedate'];
	$arr['user'] 				    = $_REQUEST['user'];
	$arr['pick'] 				    = $_REQUEST['pick'];

	$error ='';
	
	if(!empty($arr['user']) 
	&& !empty($arr['pick'])
	&& !empty($arr['purchasedate'])
	
	) {
 
	    
		$ResultArray =  insertsingleTransactionDetails($arr,'' ); 
	} else{
		$ResultArray = array("status"=>"failed","message"=>"user, product id or date is empty","type"=>"Normal");			
	}
	
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>
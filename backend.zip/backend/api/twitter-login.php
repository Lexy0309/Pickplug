<?php 

	include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");	

	$arr['userPassword'] 		= isset($_REQUEST['password']) ? $_REQUEST['password']:'';

	$arr['userFullName'] 		= isset($_REQUEST['fullname']) ? $_REQUEST['fullname']:'';

	$arr['userToken'] 			= $_REQUEST['token'];

	$arr['userEmail'] 			= $_REQUEST['email'];

	$arr['fbimage'] 			= $_REQUEST['fbimage'];

	$arr['userBirthday'] 		= $_REQUEST['birthday'];

	$arr['userGender'] 			= $_REQUEST['gender'];

	$error ='';

	if(!empty($arr['userToken']) ){

		$strfbimage = basename($arr['fbimage'] );

		/*if(!empty($img)) {

			$orgfile = $img;

			$newfile = $global_config["SiteLocalUploadPath"].'userImage/'.basename($img);

			copy($orgfile,$newfile);

			$sql = "UPDATE ";

			mysql_query();

		}*/
		/*if($strfbimage){
			$arr['fbimage'] = 'http://'.$arr['fbimage'];
		}*/
		$strfbimage = doUploadFbThumbImages($arr['fbimage'],'',$objArray,'tbl_user',$global_config["SiteLocalUploadPath"].'userImage/','thumb','302','302');
		$ResultArray = checkTwitterLoginDetails($arr['userFullName'],$arr['userToken'],$arr['userEmail'],$arr['userBirthday'],$arr['userGender'],$strfbimage); 	  

	} else{

		$ResultArray = array("status"=>"failed","message"=>"username and password empty","type"=>"Twitter");			

	}

	

	displayResult($ResultArray,'Login');

?>
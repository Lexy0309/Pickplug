<?php

    include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");

	$arr['userFullName'] 		= isset($_REQUEST['fullname']) ? $_REQUEST['fullname']:'';
	$arr['userPhoneNumber'] 	= isset($_REQUEST['phone']) ? $_REQUEST['phone']:'';
	$arr['userGender']      	= isset($_REQUEST['gender']) ? $_REQUEST['gender']:'';
	$arr['userEmail'] 		    = isset($_REQUEST['email']) ? $_REQUEST['email']:'';
	$arr['userBirthday']	    = isset($_REQUEST['birthday']) ? $_REQUEST['birthday']:'';
	$arr['userId']	    		= isset($_REQUEST['user_id']) ? $_REQUEST['user_id']:'';





    	$filename 		= '';
        if(isset($_FILES['photo']['name'])){	
	  	    $filename 		= $_FILES['photo']['name'];
	  	    $fileExt = pathinfo($filename, PATHINFO_EXTENSION);
			//$fileExt 		= substr($filename,-4,4);
			$filename		= date('YmdHis').".".$fileExt;
			$target_path	= UPLOADLOCALPATH.'userImage/'.$filename;
			
			if(move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)){

					$thumbPath 	  = UPLOADLOCALPATH.'userImage/thumb/'.$filename;
					$strImageProperties = getimagesize($target_path);
					  if($strImageProperties[0]>$userImageResizeW){
						 createthumb($target_path,$thumbPath,$userImageResizeW,$userImageResizeH);
					  }else{
					    copy($target_path,$thumbPath); 
					  }
			}
		}
		$arr['userPhoto'] = $filename;	



	$error ='';

	if($arr['userId'] == ""){
		$error = "Please login again";
	}
	else if($arr['userFullName']=='') {
		$error = "Full Name should not be empty";
	} 
	else if($arr['userEmail']=='') {
		$error = "Email address should not be empty";
	}
	else if($arr['userEmail']!='' && !preg_match('/[a-z||0-9]@[a-z||0-9].[a-z]/', $arr['userEmail'])) {
		$error = "Invalid email address";
	}

	if($error != ''){
		$ResultArray = array("status"=>"failed","message"=>$error);	
	}else{
	   	$ResultArray = updateProfile($arr['userId'],$arr);

	}	 	

    header('Content-Type: application/json');
	displayResult($ResultArray,'Results');
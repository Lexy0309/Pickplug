<?php
    include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	if(isset($_REQUEST['Country']))
	{
		 //$ResultArray = getBetDetailsByCountry($_REQUEST['Country'],$_REQUEST['date']);
		 if(empty($_REQUEST['date'])) {
			 $ResultArray = getBetDetailsByCountry($_REQUEST['Country'],$_REQUEST['date']);
		 } else {
			 $ResultArray = getBetDetailsByCountryWithDate($_REQUEST['Country'],$_REQUEST['date']);
		 }
	} else if(!empty($_REQUEST['date'])) {
		for($i=1;$i<=count($countrylist);$i++){
			$val = $countrylist[$i];
			$res = getBetDetailsByDate($_REQUEST,$i);
			if($res > 0) {
					$ResultArray[$val]= getBetDetailsByCountryID($i);
				}else{
					$ResultArray[$val]= getBetDetailsByCountryID($i);
					//check if deleted in that date
					//$ResultArray[$val]= array("No records found");
				}
			}
	} else {
		for($i=1;$i<=count($countrylist);$i++){
			$val = $countrylist[$i];
			$ResultArray[$val]= getBetDetailsByCountryID($i);
		}
	}
	
	
	if($ResultArray[0]=='No records found'){
		if($_REQUEST['date']){
			$total			 = dogetTotalBets($_REQUEST['Country']);
			$checkAllDeleted = dogetAllDeletedBets($_REQUEST['Country']);
			if($total>=1){
				if($total == $checkAllDeleted){
					$ResultArray=array("All deleted");
				}
			}
		}
		echo  json_encode($ResultArray);
		exit;
	}else{
		//printArray($ResultArray);
		displayResult($ResultArray,'Bets');

	}

?>




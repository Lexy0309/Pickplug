<?php 

	include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");	

	$arr['userPassword'] 		= isset($_REQUEST['password']) ? $_REQUEST['password']:'';

	$arr['userFacebookId'] 		= $_REQUEST['facebookId'];

	$arr['Email'] 				= $_REQUEST['email'];

	$arr['latitude'] 			= $_REQUEST['CurrentLatitude'];

	$arr['longitude'] 			= $_REQUEST['CurrentLongitude'];

	$error ='';

	if((!empty($arr['Email'])) || !empty($arr['userFacebookId']) ){

		$strfbimage = basename($img);

		/*if(!empty($img)) {

			$orgfile = $img;

			$newfile = $global_config["SiteLocalUploadPath"].'userImage/'.basename($img);

			copy($orgfile,$newfile);

			$sql = "UPDATE ";

			mysql_query();

		}*/

		$ResultArray = checkLoginDetails($arr['userUserName'],$arr['userPassword'],$arr['userFacebookId'],$arr['Email'],$arr['AddedDate'],$strfbimage); 	  

	} else{

		$ResultArray = array("status"=>"failed","message"=>"username and password empty");			

	}

	displayResult($ResultArray,'Login');

?>
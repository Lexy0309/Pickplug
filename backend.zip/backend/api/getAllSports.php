<?php
    include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");
	

 
	 $ResultArray = getAllSports($_REQUEST['user_id']);
	
	
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>


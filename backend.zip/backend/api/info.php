<?php 
	echo date('Y-m-d H:i:s');
	
	echo "<br>";

	echo date_default_timezone_get();
	
	/*echo ConvertGMTToLocalTimezone();
	
	function ConvertGMTToLocalTimezone('2014-01-30',"America/Chicago")
	{
    $system_timezone = date_default_timezone_get();

    date_default_timezone_set("GMT");
    $gmt = date("Y-m-d h:i:s A");

    $local_timezone = $timezoneRequired;
    date_default_timezone_set($local_timezone);
    $local = date("Y-m-d h:i:s A");

    date_default_timezone_set($system_timezone);
    $diff = (strtotime($local) - strtotime($gmt));

    $date = new DateTime($gmttime);
    $date->modify("+$diff seconds");
    $timestamp = $date->format("m-d-Y H:i:s");
    return $timestamp;
	}*/

?>
<?php 

	include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

    include(SITEADMININCLUDEPATH."api-functions.php");	
    

    $arr['user_name'] = isset($_REQUEST['user_name']) ? $_REQUEST['user_name']:'';
    $arr['user_email'] = isset($_REQUEST['user_email']) ? $_REQUEST['user_email']:'';
    $arr['last_updated'] = isset($_REQUEST['last_updated']) ? $_REQUEST['last_updated']:'';
    $arr['last_updated'] = date('Y-m-d H:i:s',$arr['last_updated']);
    
    if(!empty($arr['user_email']) && !empty($arr['user_name']) ){
        if (addUserAppLog($arr)) {
            displayResult(array("status"=>"success","message"=>"success"));
        }
        else {
            displayResult(array("status"=>"failed","message"=>"error while writing db"));
        }
    }else{

        displayResult(array("status"=>"failed","message"=>"username and password empty"));
    }
	
	?>
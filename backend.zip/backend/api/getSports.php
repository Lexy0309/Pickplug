<?php
    include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");
	
	if(empty($_REQUEST['date'])) {
		$ResultArray = getMainSportsDetails($_REQUEST);
	} else {
	    $ResultArray = getSportsDetailsByDate($_REQUEST);
		if($_REQUEST['date']){
			$total			= dogetTotalSports($_REQUEST['date']);
			if($total>=1){
				$ResultArray = getCurrentSportsDetails();	
			}
		}
		
		if($ResultArray['message'] == 'No records found'){
			global $table_config;
			$total			 = dogetTotalSports($_REQUEST['date']);
			$checkAllDeleted = dogetAllDeletedSports($_REQUEST['date']);
			if($total>=1){
				if($total == $checkAllDeleted){
					$ResultArray=array("All deleted");
				}
			}
		} 
		
	}
	displayResult($ResultArray,'Sports');

?>


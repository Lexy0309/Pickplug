<?php

	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	$sportID=$_GET['SportId'];
	$res  = getSportsDetailsForPicks($sportID,$_REQUEST['date']);
	$res2 = getSportsDetailsForPicksWithoutDate($sportID,$_REQUEST['date']);
	
	//echo count($res); exit;
	
	if($ResultArray['PickDetails']['message']!='No records found') {
		$ResultArray['SportDetails'] = $res2;
	} else {
		$ResultArray['SportDetails'] = $res;
	}
	/*if($res['message']!='No records found'){
		$ResultArray['PickDetails'] = getPickDetailsBySportId($table_config['picks'],$sportID,$_REQUEST['date']);
		if($ResultArray['PickDetails']['message']=='No records found'){
			$ResultArray = array("message"=>"No records found");
		}
	}else{
	 	$ResultArray = array("message"=>"No records found");
	}*/
	
	$ResultArray['PickDetails'] = getPickDetailsBySportId($table_config['picks'],$sportID,$_REQUEST['date']);
	/*if($ResultArray['PickDetails']['message']=='No records found') {
		$ResultArray = array("No records found");
	}*/
	//displayResult($ResultArray,'Picks');
	if($ResultArray['PickDetails']['message']=='No records found' && $_REQUEST['date']!=''){
		$type ='Win';
		$tot = getgivenDateStatusChangedPicksCnt($_GET['SportId'],$_REQUEST['date'],$type);
		if($tot>=1){
			$ResultArray['PickDetails']=array("All deleted");
		}
		$total			 = dogetTotal($_GET['SportId']);
		$checkAllDeleted = dogetAllDeleted($_GET['SportId']);
		if($total>=1){
			if($total == $checkAllDeleted){
				$ResultArray['PickDetails']=array("All deleted");
			}
		}
	}	
	displayResult($ResultArray,'Picks');

?>
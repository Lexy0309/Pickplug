<?php
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");	
	$error ='';
	$user_session 		= isset($_REQUEST['sessionid']) ? $_REQUEST['sessionid']:'';
	if($user_session){
		$arr['fa_UserId']       = getUserIdFromSession($user_session);
		if($arr['fa_UserId']==0){
			$error = "User session is invalide";
		}	
	}else{
	      $error = " Enter user session id";
	}
	
	if($error=='') {
		 $existingTeamIds = getFavoritiesIds($arr['fa_UserId']);
		 //$_REQUEST['teamids'] = '["\3\"]';
		 if($_REQUEST['teamids']!='' && $_REQUEST['teamids']!='[]'){
		 	$teamIds 			= explode(",",arrayTostr($_REQUEST['teamids']));
			// $teamIds = $_REQUEST['teamids'];
			 $diffAry = array_diff($existingTeamIds,$teamIds);
			 if(count($diffAry)>=1){
			 	$strAry = implode(",",$diffAry);
			 	UpdateFavoritesForUser($arr['fa_UserId'],$strAry);
			 }else{
			 	DeleteFavoritesForUser($arr['fa_UserId']);
			 }
			 $ResultArray = array("status"=>"success","message"=>'Deleted successfully');	
		  }
	} else{
		$ResultArray = array("status"=>"failed","message"=>$error);			
	}
	displayResult($ResultArray,'setfavorites');

function arrayTostr($strAry){
		$json = $strAry;
		$sAry = array('[',']','"');
		$rAry = array('','','');
		$res  = stripslashes(str_replace($sAry,$rAry,$json));
		return $res;
	}
?>
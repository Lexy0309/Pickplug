
<html>
    <head>
        <script type="text/javascript" src="ua-parser.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    </head>
    <body>
        <form method="POST" id="agentform" action="http://propicksapp.com/app/api/loguseragent.php">
            <input type="hidden" name="device" id="device" />
            <input type="hidden" name="model" id="model" />
            <input type="hidden" name="os" id="os" />
            <input type="hidden" name="browser" id="browser" />
            <input type="hidden" name="ipaddress" id="ipaddress" value="<?php echo $_GET['ip']; ?>" />
        </form>
    </body>

    <script type="text/javascript">
        var parser = new UAParser();
        var agents = parser.getResult();
        
        var device = agents.device.vendor;
        var model = agents.device.model;
        var os = agents.os.name+" "+agents.os.version;
        var browser = agents.browser.name+" "+agents.browser.major;
        var ipaddress = "<?php echo $_GET['ip']; ?>";
        $.ajax({
            url:"http://propicksapp.com/app/api/loguseragent.php",
            method:"POST",
            data:{device:device, model:model, os:os, browser:browser, ipaddress:ipaddress}
        }).done(function(response){

        });
    </script>
</html>
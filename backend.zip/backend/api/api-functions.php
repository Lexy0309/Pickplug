<?php


    function isValidPassword($userId,$oldPassword){
		$valid = true;

		$sql = 'SELECT * FROM tbl_users WHERE Id= "'.$userId.'" AND Password= "'.$oldPassword.'"';
		if(mysql_affected_rows($sql1) > 0){
				$valid = true;
		}else{
			$valid = false;
		}
		return $valid;
	}



	function updateUserPassword($userId,$newPassword){
		$updatesql = "UPDATE tbl_users SET `Password` = '".$newPassword."' WHERE `UserId` = '".$userId."'";	
		mysql_query($updatesql);
		$ResultArray = array("status" => "success", "message"=>"Password Change Successfully");
		return $ResultArray;
	}
	


	function getLoginDetails($username,$password) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE Username='".$username."' AND Password='".$password."' AND Published='Yes' AND IsDeleted='No'";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			$ResultArray = array("status"=>"success","message"=>"Login Success");
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Invalid username and password");
		}
		return $ResultArray;
	}
	function getUserIdFromSession($session){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE session='".$session."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
			return $results[0]['Id'];
		}else{
			return 0;
		}
	}
	
	
	function getUserDetailsByEmail($email) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE Email='".$email."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
		  $user['Id']				 = $results[0]['Id'];
		  $user['FullName']			 = $results[0]['FullName'];
		  $user['Password'] 		 = $results[0]['Password'];
		  $user['Email'] 	 		 = $results[0]['Email'];
		  $user['PhoneNumber'] 		 = $results[0]['PhoneNumber'];
		  $user['Birthday'] 		 = $results[0]['Birthday'];
		  $user['Gender'] 		     = $results[0]['Gender'];
		  $user['Photo'] 		     = SITEGLOBALUPLOADPATH.'userImage/'.$results[0]['Photo'];
		  $user['session'] 		     = $results[0]['session'];
		  $user['Facebooktoken']	 = $results[0]['Token'];
		  $user['TwitterToken']		 = $results[0]['TwitterToken'];
		  $user['PickPush']			 = $results[0]['pick_push'];
		  $user['SportsPush']		 = $results[0]['sports_push'];
		  $user['FavoritesPush']	 = $results[0]['favorites_push'];
		  $user['PickMail']			 = $results[0]['pick_mail'];
		  $user['SportsMail']		 = $results[0]['sports_mail'];
		  $user['FavoritesMail']	 = $results[0]['favorites_mail'];
		  
		}
		return $user;
	}
	
	function getUserDetails($userId) {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["user"]." WHERE Id='".$userId."'";
		$results=SelectQry($sql);
		
		if(count($results>=1)){
		  $user['Id']				 = $results[0]['Id'];
		  $user['FullName']			 = $results[0]['FullName'];
		  $user['Password'] 		 = $results[0]['Password'];
		  $user['Email'] 	 		 = $results[0]['Email'];
		  $user['PhoneNumber'] 		 = $results[0]['PhoneNumber'];
		  $user['Birthday'] 		 = $results[0]['Birthday'];
		  $user['Gender'] 		     = $results[0]['Gender'];
		  $user['Photo'] 		     = SITEGLOBALUPLOADPATH.'userImage/'.$results[0]['Photo'];
		  $user['session'] 		     = $results[0]['session'];
		  $user['Facebooktoken']	 = $results[0]['Token'];
		  $user['TwitterToken']		 = $results[0]['TwitterToken'];
		  
		  $user['PickPush']			 = $results[0]['pick_push'];
		  $user['SportsPush']		 = $results[0]['sports_push'];
		  $user['FavoritesPush']	 = $results[0]['favorites_push'];
		  $user['PickMail']			 = $results[0]['pick_mail'];
		  $user['SportsMail']		 = $results[0]['sports_mail'];
		  $user['FavoritesMail']	 = $results[0]['favorites_mail'];

		}
		return $user;
	}
	function getFavoritesBySport($userId,$sportId){
		global $table_config,$global_config;
		//get team id based on sport id 
		$sql		= "SELECT DISTINCT(VisitingTeam),SportName FROM ".$table_config["picks"]." WHERE SportName='".$sportId."'";
		$results	= SelectQry($sql);
		for($i=0;$i<count($results);$i++){
			$newRes[] = $results[$i]['VisitingTeam'];
		}
		$sql1		= "SELECT DISTINCT(HomeTeam),SportName FROM ".$table_config["picks"]." WHERE SportName='".$sportId."'";
		$results1	= SelectQry($sql1);
		for($j=0;$j<count($results1);$j++){
			$newRes[] = $results1[$j]['HomeTeam'];
		}
		
		if(count($newRes)>=1){
			$finalTeamAry  = array_values(array_filter(array_unique($newRes)));
		}
		
		$fromDB = getFavoritesByUser($userId);
		
		if(count($fromDB)>1){
			$res = array_intersect($finalTeamAry,$fromDB);
		}
		if(count($res)>=1){
			$strIds  = implode(",",$res);
			$teamAry = getTeamDetailsByStr($strIds);
		}else{
			$teamAry = array("status"=>"failed","message"=>"Team not found");	
		}
		return $teamAry;
	}
	
	function UpdateFavoritesForUser($userId,$strAry){
		global $table_config,$global_config;
	    $date = date('Y-m-d H:i:s');
		$updatesql = "UPDATE ".$table_config["favorites"]." SET `TeamId` = '".$strAry."',`LastUpdatedDate`='".$date."' WHERE `UserId` = '".$userId."'";	
		mysql_query($updatesql);
	}
	function DeleteFavoritesForUser($userId){
		global $table_config,$global_config;
		$sql="DELETE FROM ".$table_config["favorites"]."  WHERE `UserId` = '".$userId."'";	
		mysql_query($sql);
	}
	
	function getFavoritesByUser($userId){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["favorites"]." WHERE UserId='".$userId."'";
		$results=SelectQry($sql);
		if(count($results[0]['TeamId'])>=1){
				$returnAry = explode(",",$results[0]['TeamId']);
		}else{
		       $returnAry = array();
		}
		return $returnAry;
	}
	
	function getTeamDetailsByStr($strIds){
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["team"]."  WHERE Id IN (".$strIds.") AND Status ='Active'";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['TeamName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'team/'.$result['TeamIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'team/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$ResultArray[] = array("Id"=>$id,"TeamName"=>$SportName, "TeamImage"=>$SportImage,"AddedDate"=>$AddedDate);
			}
		}else{
			$ResultArray = array("status"=>"failed","message"=>"Team not found");	
		}		
			
		return $ResultArray;	
	}
	
	function getFavorites($userId){
	  	global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["favorites"]." WHERE UserId='".$userId."'";
		$results=SelectQry($sql);
		if(count($results[0]['TeamId'])>=1){
				$strIds = $results[0]['TeamId'];
				$sql="SELECT * FROM ".$table_config["team"]."  WHERE Id IN (".$strIds.") AND Status ='Active'";
				$results=SelectQry($sql);
				if(count($results) > 0) {
					foreach($results as $result) {
						$id 			= $result['Id'];
						$SportName 		= $result['TeamName'];
						$SportImage 	= SITEGLOBALUPLOADPATH.'team/'.$result['TeamIcon'];
						$SportThumb 	= SITEGLOBALUPLOADPATH.'team/thumb/'.$result['thumb'];
						$AddedDate 		= $result['AddedDate'];
						$ResultArray[] = array("Id"=>$id,"TeamName"=>$SportName, "TeamImage"=>$SportImage,"AddedDate"=>$AddedDate);
					}
				}		
		}else{
			$ResultArray =array("status"=>"failed","message"=>"Team not found");
		}
		return $ResultArray;
	}
	function getTeam(){
		global $table_config,$global_config;			
		$sql="SELECT * FROM ".$table_config["team"]."  WHERE Status ='Active'";
		$results=SelectQry($sql);
			if(count($results) > 0) {
				foreach($results as $result) {
					$id 			= $result['Id'];
					$SportName 		= $result['TeamName'];
					$SportImage 	= SITEGLOBALUPLOADPATH.'team/'.$result['TeamIcon'];
					$SportThumb 	= SITEGLOBALUPLOADPATH.'team/thumb/'.$result['thumb'];
					$AddedDate 		= $result['AddedDate'];
					$ResultArray[] = array("Id"=>$id,"TeamName"=>$SportName, "TeamImage"=>$SportImage,"AddedDate"=>$AddedDate);
				}
			}else{
				$ResultArray = array('Details not found');	
			}
		return $ResultArray;
		}
	
	function updateFavorites($objArray,$Prefix,$type='') {
		global $table_config,$global_config;
		$strEmailCheckUser = CheckDataExists($table_config["favorites"],'UserId', $objArray['fa_UserId']);
		if($strEmailCheckUser == 0){
			$counter = 0;
			foreach($objArray as $key=>$value){
				$pos = strpos($key, $Prefix);
				if (!is_integer($pos)) {
				}else{
					$key = str_replace($Prefix,"",$key);
					$insertArray[$counter]["Field"] = $key;
					$insertArray[$counter]["Value"] = stripslashes($value);
					$counter++;
				}
			}
			
			$insert_id = doInsert($table_config["favorites"],$insertArray);
			if($insert_id) {
				$ResultArray = array("status"=>"success","message"=>"Favorites details inserted successfully");
			}
		} else {
				// getExisting details
				   $str 	= implode(",",getFavoritiesIds($objArray['fa_UserId']));
				   if($str){
				   		$resStr	= $str.",".$objArray['fa_TeamId'];
						$resStrAry = explode(",",$resStr);
						$resStr    = implode(",",array_unique($resStrAry));
				   }else{
				   		$resStr	= $objArray['fa_TeamId'];
				   }
				
				$date = date('Y-m-d H:i:s');
			    $updatesql = "UPDATE ".$table_config["favorites"]." SET `TeamId` = '".$resStr."',`LastUpdatedDate`='".$date."' WHERE `UserId` = '".$objArray['fa_UserId']."'";	
				mysql_query($updatesql);	
		  	   $ResultArray = array("status"=>"success","message"=>"Favorites details updated successfully");
		}	
		return $ResultArray;	
	}
	
	function array_merge_unique(array $array1 /* [, array $...] */) {
	  $result = array_flip(array_flip($array1));
	  foreach (array_slice(func_get_args(),1) as $arg) { 
		$result = 
		  array_flip(
			array_flip(
			  array_merge($result,$arg)));
	  } 
	  return $result;
}
	function getFavoritiesIds($user_id){
		global $table_config,$global_config;
		$sql="SELECT TeamId FROM ".$table_config["favorites"]." WHERE UserId='".$user_id."'";
		$results=SelectQry($sql);
		if(count($results>=1)){
			return explode(",",$results[0]['TeamId']);
		}else{
			return 0;
		}
	}
	
	function insertTransactionDetails($objArray,$Prefix,$type='') {
		global $table_config,$global_config;
		 
			foreach($objArray as $key=>$value){
				$pos = strpos($key, $Prefix);
				if (!is_integer($pos)) {
				}else{
					$key = str_replace($Prefix,"",$key);
					$insertArray[$counter]["Field"] = $key;
					$insertArray[$counter]["Value"] = stripslashes($value);
					$counter++;
				}
			}
						print_r($insertArray);
			$insert_id = doInsert($table_config["transactions"],$insertArray);
			if($insert_id) {
				$user 		 = getUserSubscriptions($objArray["User"]);
				$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully","user"=>$user);
			}
		
		return $ResultArray;	
	}
	fu

	function insertLoginDetails($objArray,$Prefix,$type='') {
		global $table_config,$global_config;
		$strEmailCheckUser = CheckDataExists($table_config["user"],'Email', $objArray['userEmail']);
		
		if($strEmailCheckUser == 0){
			$counter = 0;
			foreach($objArray as $key=>$value){
				$pos = strpos($key, $Prefix);
				if (!is_integer($pos)) {
				}else{
					$key = str_replace($Prefix,"",$key);
					$insertArray[$counter]["Field"] = $key;
					$insertArray[$counter]["Value"] = stripslashes($value);
					$counter++;
				}
			}
			
			$insert_id = doInsert($table_config["user"],$insertArray);
			if($insert_id) {
				$user 		 = getUserDetails($insert_id);
				$ResultArray = array("status"=>"success","message"=>"user details inserted successfully","user"=>$user);
			}
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Email Address already exists");
		}	
		return $ResultArray;	
	}

	function checkLoginDetails($email='',$password='') {
		global $table_config,$global_config;
		if(!empty($email) && !empty($password)) {
			$sql="SELECT * FROM ".$table_config["user"]." WHERE Email='".$email."' AND Password='".$password."' AND Status='Active' AND IsDeleted='No'";
		} 
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			updateSessionValue($results[0]['Id']);
			$userDetails = getUserDetails($results[0]['Id']);
			$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Normal","user"=>$userDetails);
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Invalid Login details","type"=>"Normal");
		}
		return $ResultArray;
	}
	
	function updateSessionValue($user_id){
		global $table_config,$global_config;
		$sessionId  = md5(uniqid(microtime()));
		$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."' WHERE `Id` = '".$user_id."'";	
		mysql_query($updatesql);
	}
	function checkUserById($tbl_name,$Id){
		$sql="SELECT * from ".$tbl_name." where Id='".$Id."'";
		$result=SelectQry($sql);
		
		if($result) {
			return 1;
		} else {
			return 0;
		}
	}
	
	function getUserEmailById($id) {
	    $sql="SELECT * from tbl_user where Id='".$Id."'";
		$result=SelectQry($sql);
		if ($result) {
		    $_result=$result[0];
		    return $_result['Email'];
		}
		else {
		    return "";
		}
	}

	function checkUserBySessionId($tbl_name,$Id){
		$sql="SELECT * from ".$tbl_name." where SessionId='".$Id."'";
		$result=SelectQry($sql);
		return $result;
	}

	function getGlobalSettingsValue() {
		global $table_config,$global_config;
		$sql="SELECT * FROM ".$table_config["settings"];
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 	  	   = $result['Id'];
				if($result['URLShortening'] == 'Enable'){
					$strUrlShortening = 'Yes';
				} else {
					$strUrlShortening = 'No';
				}
				if($strUrlShortening == 'Yes'){
					$username	   = $result['BitlyUsername'];
					$password 	   = $result['BitlyPassword'];
				} else {
					$username	   = '';
					$password 	   = '';
				}
				$ResultArray[] = array('Id'=>$id,'URLShortening'=>$strUrlShortening,'Bit ly Username'=>$username,'Bit ly Password'=>$password);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}

	
	function getSportsDetails($objArray,$strDate) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		$strfinaldate = strtotime($strDate);
		if(isset($objArray['id']) && empty($strDate)) {
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$objArray['id']."' AND Status ='Active' AND IsDeleted ='No'";
		} else if(isset($objArray['id']) && !empty($strDate)) {
			$sql="SELECT * FROM ".$table_config["sport"]."  WHERE Id = '".$objArray['id']."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND Status ='Active'";
		} else {	
			$sql="SELECT * FROM ".$table_config["sport"]." WHERE Status ='Active' AND IsDeleted ='No'";
		}
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}	
	
	function getSportsDetailsByDate($objArray) {
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config;
		$strdate  = strtotime($objArray['date']);
		$strdate1 = date("Y-m-d H:i:s",strtotime('+5 hours 30 minutes',strtotime($objArray['date'])));
		$finaldate = strtotime($strdate1);
		$sql="SELECT * FROM ".$table_config["sport"]." WHERE ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."'))";
		$results=SelectQry($sql);
		
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$SportName 		= $result['SportName'];
				$SportImage 	= SITEGLOBALUPLOADPATH.'sport/'.$result['SportIcon'];
				$SportThumb 	= SITEGLOBALUPLOADPATH.'sport/thumb/'.$result['thumb'];
				$AddedDate 		= $result['AddedDate'];
				$RecordNo 		= $result['RecordNo'];
				$ModifiedDate 	= $result['ModifiedDate'];
				
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				$ResultArray[] = array("Id"=>$id,"SportName"=>$SportName,"RecordNo"=>$RecordNo, "SportImage"=>$SportImage, "SportThumb"=>$SportThumb, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}	
	
	function checkFbLoginDetails($username,$facebookid,$email='',$birthday,$gender,$strfbimage='') {
		global $table_config,$global_config;
		if(preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email)){
			if (!empty($facebookid)) {
				$sql="SELECT * FROM ".$table_config["user"]." WHERE Token='".$facebookid."' AND Status='Active' AND IsDeleted='No'";
			}
			$results=SelectQry($sql);
			
			if(count($results) > 0) {
				$sessionId        =  md5(uniqid(microtime()));
				$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$strfbimage."' WHERE `Id` = '".$results[0]['Id']."'";	
				mysql_query($updatesql);
				$userDetails = getUserDetails($results[0]['Id']);
				$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Facebook","user"=>$userDetails);
			} else {
				$sessionId =  md5(uniqid(microtime()));
				$addedDate = date('Y-m-d H:i:s');
				$strEmailCheckUser = CheckDataExists($table_config["user"],'Email', $email);
				if($strEmailCheckUser == 0){
					$sql = "Insert into ".$table_config["user"]." ( `FullName`, `Email`,`Birthday`, `Gender`,`Photo`,`AddedDate`,`session`,`Token` ) Values ('".$username."', '".$email."', '".$birthday."','".$gender."', '".$strfbimage."','".$addedDate."','".$sessionId."','".$facebookid."')";
					mysql_query($sql);
					$lastInsertId = mysql_insert_id();
					$userDetailsNew = getUserDetails($lastInsertId);
					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Facebook","user"=>$userDetailsNew);
				} else {
					$sessionId        =  md5(uniqid(microtime()));
					$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$strfbimage."',`Token` ='".$facebookid."' WHERE `Email` = '".$email."'";	
					mysql_query($updatesql);
					$userDetails = getUserDetailsByEmail($email);
					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Facebook","user"=>$userDetails);
				}
			}
		} else {
			$ResultArray = array("status"=>"failed","message"=>"Email Address is not valid","type"=>"Facebook");
		}
		return $ResultArray;
	}
	function checkTwitterLoginDetails($username,$twitterid,$email='',$birthday,$gender,$strfbimage='') {
		global $table_config,$global_config;
			if (!empty($twitterid)) {
				$sql="SELECT * FROM ".$table_config["user"]." WHERE TwitterToken='".$twitterid."' AND Status='Active' AND IsDeleted='No'";
			}
			$results=SelectQry($sql);
			
			
			if(count($results) > 0) {
				$sessionId        =  md5(uniqid(microtime()));
				$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$strfbimage."' WHERE `Id` = '".$results[0]['Id']."'";	
				mysql_query($updatesql);
				$userDetails = getUserDetails($results[0]['Id']);
				
				$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Twitter","user"=>$userDetails);
			} else {
				$sessionId =  md5(uniqid(microtime()));
				$addedDate = date('Y-m-d H:i:s');
				$strEmailCheckUser = 0; //CheckDataExists($table_config["user"],'Email', $email);
				
				if($strEmailCheckUser == 0){
					$sql = "Insert into ".$table_config["user"]." ( `FullName`, `Email`,`Birthday`, `Gender`,`Photo`,`AddedDate`,`session`,`TwitterToken` ) Values ('".$username."', '".$email."', '".$birthday."','".$gender."', '".$strfbimage."','".$addedDate."','".$sessionId."','".$twitterid."')";
					mysql_query($sql);
					$lastInsertId = mysql_insert_id();
					$userDetailsNew = getUserDetails($lastInsertId);
					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Twitter","user"=>$userDetailsNew);
				} else {
					$ResultArray = array("status"=>"failed","message"=>"Eamil Address already exist","type"=>"Twitter");
				}
			}
		return $ResultArray;
	}
	
	function checkInstagramLoginDetails($username,$instagramid,$email='',$birthday,$gender,$instagramimage='') {
		global $table_config,$global_config;
			if (!empty($instagramid)) {
				$sql="SELECT * FROM ".$table_config["user"]." WHERE InstagramToken='".$instagramid."' AND Status='Active' AND IsDeleted='No'";
			}
			$results=SelectQry($sql);
			
			if(count($results) > 0) {
				$sessionId        =  md5(uniqid(microtime()));
				$updatesql = "UPDATE ".$table_config["user"]." SET `session` = '".$sessionId."',`Email`='".$email."',`Birthday` ='".$birthday."', `Gender` = '".$gender."', `Photo` = '".$instagramimage."' WHERE `Id` = '".$results[0]['Id']."'";	
				mysql_query($updatesql);
				$userDetails = getUserDetails($results[0]['Id']);
				
				$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Instagram","user"=>$userDetails);
			} else {
				$sessionId =  md5(uniqid(microtime()));
				$addedDate = date('Y-m-d H:i:s');
				$strEmailCheckUser = 0; //CheckDataExists($table_config["user"],'Email', $email);
				
				if($strEmailCheckUser == 0){
					$sql = "Insert into ".$table_config["user"]." ( `FullName`, `Email`,`Birthday`, `Gender`,`Photo`,`AddedDate`,`session`,`InstagramToken` ) Values ('".$username."', '".$email."', '".$birthday."','".$gender."', '".$instagramimage."','".$addedDate."','".$sessionId."','".$instagramid."')";
					mysql_query($sql);
					$lastInsertId = mysql_insert_id();
					$userDetailsNew = getUserDetails($lastInsertId);
					$ResultArray = array("status"=>"success","message"=>"user details logged in successfully","type"=>"Instagram","user"=>$userDetailsNew);
				} else {
					$ResultArray = array("status"=>"failed","message"=>"Eamil Address already exist","type"=>"Instagram");
				}
			}
		return $ResultArray;
	}
	
function doUploadFbThumbImages($fileArray,$ident,$objArray,$tblName,$strFilePath,$strFieldName,$thumbWidth='',$thumbHeight='') {
		global $global_config, $table_config;
		$file = $fileArray;
		$destpath	=  $strFilePath;
		$thumbpath   =  $destpath.'thumb/';
		if($file!=''){
			$filename =basename($fileArray);
			$fileExt = substr($filename,-4,4);
			$DBFilename = substr($filename,0,-4);
			//$filename=strtotime(date('Y-m-d H:i:s a')).$fileExt;
			$filename=date('YmdHis').$fileExt;
			
			if($filename!=''){
				@unlink($destpath.$filename);
				@unlink($thumbpath.$filename);
			}
			
			copy($file,$destpath.$filename);
			
			$strImageProperties = getimagesize($file);
				if($thumbWidth != ''){
					if($strImageProperties[0]>$thumbWidth){
						FinalCrop($destpath.$filename,$thumbpath.$filename,$thumbWidth,$thumbHeight);	
					}else{
						copy($file,$thumbpath.$filename);
					}
				}	
			//updateThumbImageStatus($ident,$tblName,$strFieldName,$filename);
		}
		return $filename;
	}
	function getPicksDetails($tbl_name,$sportid)
	{
		global $global_config, $table_config;
		if($sportid==1) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY NflPick  ORDER BY NflPick ASC ";
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY DATE( PickDate )  ORDER BY PickDate ASC ";
		}
		$results=SelectQry($sql);

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$sportname 			= $result['SportName'];
				$pickdate 			= date('Y-m-d',strtotime($result['PickDate']));
				$nflpick 			= $result['NflPick'];

				

				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportname,"PickDate"=>$pickdate,"NflPick"=>$nflpick);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getPickDetailsBySportId($tbl_name,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		$strfinaldate = strtotime($strDate);
		if(empty($strDate)) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE  SportName=".$sid." AND PickStatus!='Pending' AND IsDeleted = 'No' ORDER BY PickDate DESC LIMIT 10";
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE  SportName=".$sid." AND PickStatus!='Pending' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) ORDER BY PickDate DESC LIMIT 10";
		}
		//echo $sql; exit;
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($result['PickDate']));
				$pickTime				= date('h:i A',strtotime($pickdate));
				
				$weekdate 				= strtotime($result['WeekDate']);
				$weekdate 				= date('d-m-Y H:i:s',$weekdate);
				$weekTime				= date('h:i A',strtotime($weekdate));
				
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				$PickAnalysis 			= replace($result['PickAnalysis']);
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($result['AddedDate']) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				if(!empty($strDate)) {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"PickdateNew"=>$pickdateNew,"pickTime"=>$pickTime,"WeekDate"=>$weekdate,"WeekTime"=>$weekTime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"PickdateNew"=>$pickdateNew,"pickTime"=>$pickTime,"WeekDate"=>$weekdate,"WeekTime"=>$weekTime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
			}		
		} else {
			$ResultArray = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getPickDetailsById($tbl_name,$date,$sid,$strdate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		$strfinaldate = strtotime($strdate);
		if(empty($strdate)) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." AND IsDeleted = 'No' ORDER BY PickDate ASC";
		} else {
			$sql="SELECT * FROM  ".$tbl_name." WHERE DATE(PickDate)='".$date."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) AND SportName=".$sid." ORDER BY PickDate ASC";
		}
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 			= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				
				if(!empty($strdate)) { 
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	
	function getNflPickDetailsById($tbl_name,$pick,$sid,$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		$strfinaldate = strtotime($strDate);
		if(empty($strDate)) {
			$sql="SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND IsDeleted = 'No' ORDER BY NflPick ASC";
		} else {
			$sql = "SELECT * FROM  ".$tbl_name." WHERE NflPick='".$pick."' AND SportName=".$sid." AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) ORDER BY NflPick ASC";
		}
		
		//echo $sql;  exit;
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 					= $result['Id'];
				$sportid 				= $result['SportName'];
				$weeknames 				= GetWeekDetailsById($table_config['week'], $result['NflPick']);
				$weekname					= $weeknames['name'];
				$startdate				= $weeknames['startdate'];
				$enddate				= $weeknames['enddate'];
				$pickdate 				= strtotime($result['PickDate']);
				$pickdate 				= date('d-m-Y H:i:s',$pickdate);
				$pickdateNew			= date('d-m-Y',strtotime($pickdate));
				$pickTime				= date('h:i A',strtotime($pickdate));
				$VisitingTeam 			= $result['VisitingTeam'];
				$HomeTeam	 			= $result['HomeTeam'];
				$PickTitle	 			= $result['PickTitle'];
				$PickRecord 			= $result['PickRecord'];
				$PickStatus 			= $result['PickStatus'];
				
				$weekdate 				= strtotime($result['WeekDate']);
				$weekdate 				= date('d-m-Y H:i:s',$weekdate);
				$weektime				= date('h:i A',strtotime($weekdate));
				
				$PickAnalysis			= "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
				$PickAnalysis 			.= replace($result['PickAnalysis']);
				$PickAnalysis 			.='</body></html>';
				$VisitingTeamDetails    = getTeamDetails($VisitingTeam);
				$HomeTeamDetails    	= getTeamDetails($HomeTeam);
				$ModifiedDate 		    = $result['ModifiedDate'];
				$AddedDate 		   		= $result['AddedDate'];
				$isdeleted              = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($result['AddedDate']) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				if(!empty($strDate)) {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"Week"=>$weekname,"StartDate"=>$startdate,"EndDate"=>$enddate,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"WeekDate"=>$weekdate,"WeekTime"=>$weektime, "VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"AddedDate"=>$AddedDate,"Status"=>$datestatus,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				} else {
					$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportid,"Week"=>$weekname,"StartDate"=>$startdate,"EndDate"=>$enddate,"PickDate"=>$pickdate,"pickTime"=>$pickTime,"pickdateNew"=>$pickdateNew,"WeekDate"=>$weekdate,"WeekTime"=>$weektime,"VisitingTeam"=>$VisitingTeam,"HomeTeam"=>$HomeTeam,"PickAnalysis"=>$PickAnalysis,"PickTitle"=>$PickTitle,"PickRecord"=>$PickRecord,"PickStatus"=>$PickStatus, "ModifiedDate"=>$ModifiedDate,"AddedDate"=>$AddedDate,"HomeTeamDetails"=>$HomeTeamDetails,"VisitingTeamDetails"=>$VisitingTeamDetails);
				}
			}		
		} /*else {
			$ResultArray[] = array("message"=>"No record found");
		}*/
		return $ResultArray;
	}
	
	function getTeamDetails($id){
		global $global_config, $table_config;
		$sql="SELECT * FROM  ".$table_config['team']." WHERE Id='".$id."'";
		$results=SelectQry($sql);
		if(count($results)>=1){
			$TeamName = $results[0]['TeamName'];
			$TeamIcon = SITEGLOBALUPLOADPATH.'team/'.$results[0]['TeamIcon'];
			$details = array('TeamName'=>$TeamName,'TeamIcon'=>$TeamIcon);
		}
		return $details;
	}
	
	
	
	function getBetDetails(){
		global $table_config,$global_config,$countrylist;
		$sql="SELECT * FROM ".$table_config["bet"]." WHERE Status ='Active' ORDER BY Id DESC";
		$results=SelectQry($sql);
		return $results;

	}
   function getBetDetailsByCountry($country,$strdate){
   		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		$strdate = strtotime($strdate);
		if(!empty($country)) {
			if($country == "CANADA") {
				$countryid="1";
			} elseif($country == "USA") {
				$countryid="2";
			} else {
				$countryid =3;
			}
			if($countryid!=0){
				 if(empty($strdate)) {
					 $sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$countryid."' AND Status ='Active' AND IsDeleted='No' ORDER BY Position ASC";
				 } else {
					 $sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$countryid."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) AND Status ='Active' ORDER BY Id DESC";
				 }
			$results=SelectQry($sql);
			}
		} 

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= $result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$position		= $result['Position'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				
				if(!empty($result['Description'])) { 
					$BetDescription  = "<html><head><link rel='stylesheet' type='text/css' href='".$global_config['SiteGlobalAdminPath']."css/wysiwyg-color.css' /></head><body>";
					$BetDescription .= replace($result['Description']);
					$BetDescription .= '</body></html>';
				} else {
				$BetDescription = '';
				}
				
				if(!empty($strdate)) {
					$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "BetDescription"=>$BetDescription, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
				} else {
					$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "BetDescription"=>$BetDescription, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Position"=>$position);
				}
			}		
		} else {
				$ResultArray = array("No records found");
		}
		return $ResultArray;
	  
	}
	
	 function getBetDetailsByCountryID($country){
		global $table_config,$global_config,$countrylist;
		$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active' AND IsDeleted='No' ORDER BY Position ASC";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= $result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$position		= $result['Position'];
				$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "AddedDate"=>$AddedDate,"Position"=>$position);
			}		
		} else {
				$ResultArray = array("No records found");
		}
		return $ResultArray;
	  
	}
	
	 function getBetDetailsByDate($strdate,$country){
	 	//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active'";
		$strdate  = strtotime($strdate);
		$ResultArray =array();
		$sql="SELECT * FROM ".$table_config["bet"]." WHERE ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) AND Country = '".$country."'  ORDER BY Id DESC";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= SITEGLOBALUPLOADPATH.'bet/'.$result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				//echo $Country; exit;
				$ResultArray[] = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
				
			}		
		} else {
				//$ResultArray = array("No records found");
		}
		return $ResultArray;
	  
	}
	
	 function getBetDetailsByDateMore($strdate,$country){
	 	//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		//$sql="SELECT * FROM ".$table_config["bet"]."  WHERE Country = '".$country."' AND Status ='Active'";
		$strdate  = strtotime($strdate);
		$ResultArray =array();
		$sql="SELECT * FROM ".$table_config["bet"]." WHERE Country = '".$country."'  ORDER BY ModifiedDate DESC LIMIT 0,1";
		$results=SelectQry($sql);
		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$CountryId 		= $result['Country'];
				$Country		= $countrylist[$CountryId];
				$BetName 		= $result['BetName'];
				$BetLogo 		= SITEGLOBALUPLOADPATH.'bet/'.$result['BetLogo'];
				$BetWebsite 	= SITEGLOBALUPLOADPATH.'bet/'.$result['BetWebsite'];
				$AddedDate 		= $result['AddedDate'];
				$ModifiedDate 	= $result['ModifiedDate'];
				$isdeleted = $result['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				//echo $Country; exit;
				$ResultArray = array("Id"=>$id,"Country"=>$Country, "BetName"=>$BetName, "BetLogo"=>$BetLogo,"BetWebsite"=>$BetWebsite, "AddedDate"=>$AddedDate, "ModifiedDate"=>$ModifiedDate,"Status"=>$datestatus);
			}		
		} else {
				//$ResultArray = array("No records found");
		}
		return $ResultArray;
	  
	}
	
	
	function GetWeekDetailsById($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
	
	function GetWeekDetailsByIdNew($tbl_name,$id){
		$sql = "select * from ".$tbl_name." where Id ='".$id."' ";
		$strResult = SelectQry($sql);
		return $strResult[0];
    }
	
	function getGroupedDates($spotId){
		$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		$strResult = SelectQry($sql);
		for($i=0;$i<count($strResult);$i++){
			$date = date('d-m-Y',strtotime($strResult[$i]['PickDate']));
			$type = getDateType($date);
			$fres[] = array('date'=>$date,'type'=>$type);
		}
		return $fres;
	}
	function getDateType($passDate){
		if( strtotime($passDate) > strtotime('now') ) {
			return "future";			
		}else{
			return "past";
		}
	}
	function checkWeekDate($weekId){
		$sql = "select * from tbl_week WHERE Id ='".$weekId."' ";
		$strResult = SelectQry($sql);
	    $finalAry  = $strResult[0];
		$startDate = $finalAry['startdate'];
		$endDate   = $finalAry['enddate'];
		if(strtotime($startDate)>=strtotime('now') && strtotime($endDate)>=strtotime('now')){
			return 'future';
		}else{
			return 'past';
		}
	
	}
	function getWeekDates($weekId){
		$sql = "select startdate,enddate from tbl_week WHERE Id ='".$weekId."' ";
		$strResult = SelectQry($sql);
		$finalAry['startdate'] = $strResult[0]['startdate'] ;
		$finalAry['enddate']   = $strResult[0]['enddate'] ;
		return $finalAry;
	}
	function getWeekIdsByName($name){
		$sql = "select * from tbl_week WHERE name ='".$name."' ";
		$strResult = SelectQry($sql);
		return $strResult[0]['Id'];
	}
	function getGroupedWeeks($spotId){
		global $table_config,$global_config,$countrylist;
		$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' GROUP By NFLPick  ORDER BY NFLPick ASC";
		$strResult = SelectQry($sql);
		for($i=0;$i<count($strResult);$i++){
			$date ='';
			$nameAry = GetWeekDetailsById($table_config['week'],$strResult[$i]['NFLPick']);
			$date    = $nameAry['name'];
			$type    = checkWeekDate($strResult[$i]['NFLPick']);
			$NewRes  = getWeekDates($strResult[$i]['NFLPick']);
			$Sdate    = $NewRes['startdate'];
			$Edate    = $NewRes['enddate'];
			$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate);
		}
		
		return $fres;
	}
	
	function getGroupedDatesNew($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		//$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND DATE(PickDate) >= CURDATE() AND  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		$strfinaldate = strtotime($strdate);
		if(empty($strdate)) {
			$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND  UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		} else {
			$sql = "select PickDate from tbl_pick where SportName ='".$spotId."' AND  ((UNIX_TIMESTAMP(AddedDate) > '".$strfinaldate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinaldate."')) AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW())  GROUP By DATE(PickDate)  ORDER BY PickDate ASC";
		}
		$strResult = SelectQry($sql);
		for($i=0;$i<count($strResult);$i++){
			$date = date('d-m-Y',strtotime($strResult[$i]['PickDate']));
			$type = getDateType($date);
			if($i==0){
				$type='present';
			}
			$fres[] = array('date'=>$date,'type'=>$type);
		}
		return $fres;
	}	
	function getPicksDetailsNew($tbl_name,$sportid,$weekIds='',$strDate)
	{
		//date_default_timezone_set('Asia/Calcutta');
		global $global_config, $table_config;
		$strdate  = strtotime($strDate);
		if($sportid==1) {
			if($weekIds && empty($strdate)){
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if($weekIds && !empty($strdate)) {
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND NflPick IN($weekIds) AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else if(empty($weekIds) && !empty($strdate)) {
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) GROUP BY NflPick  ORDER BY NflPick ASC ";
			} else{
				$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' GROUP BY NflPick  ORDER BY NflPick ASC ";
			}
		} else if(!empty($strDate)) {
			$sql="SELECT * FROM ".$tbl_name." WHERE SportName='".$sportid."' AND  ((UNIX_TIMESTAMP(AddedDate) > '".$strdate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strdate."')) ORDER BY PickDate";
		} else {
			//$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND DATE(PickDate) >= CURDATE() GROUP BY DATE( PickDate )  ORDER BY PickDate ASC ";
			$sql="SELECT * FROM  ".$tbl_name." WHERE SportName='".$sportid."' AND UNIX_TIMESTAMP(PickDate) > UNIX_TIMESTAMP(NOW()) GROUP BY DATE(PickDate)  ORDER BY PickDate ASC ";
		}
		
		$results=SelectQry($sql);

		if(count($results) > 0) {
			foreach($results as $result) {
				$id 			= $result['Id'];
				$sportname 			= $result['SportName'];
				$pickdate 			= date('Y-m-d',strtotime($result['PickDate']));
				$nflpick 			= $result['NflPick'];

				$ResultArray[]  = array("Id"=>$id,"SportId"=>$sportname,"PickDate"=>$pickdate,"NflPick"=>$nflpick);
			}		
		} else {
			$ResultArray[] = array("message"=>"No records found");
		}
		return $ResultArray;
	}
	function getGroupedWeeksNew($spotId,$strdate){
		//date_default_timezone_set('Asia/Calcutta');
		global $table_config,$global_config,$countrylist;
		$strfinalDate = strtotime($strdate);
		if(empty($strdate)) {
			$sql = "select NFLPick from tbl_pick where SportName ='".$spotId."' GROUP By NFLPick  ORDER BY NFLPick ASC";
		} else {
			$sql = "select NFLPick, AddedDate, ModifiedDate, IsDeleted from tbl_pick where SportName ='".$spotId."' AND ((UNIX_TIMESTAMP(AddedDate) > '".$strfinalDate."') OR (UNIX_TIMESTAMP(ModifiedDate) > '".$strfinalDate."')) GROUP By NFLPick  ORDER BY NFLPick ASC";
		}
		//echo $sql;  exit;
		$strResult = SelectQry($sql);
		$k=0;
		for($i=0;$i<count($strResult);$i++){
			if (checkWeekDate($strResult[$i]['NFLPick']) == 'future') {
				$date ='';
				$nameAry = GetWeekDetailsById($table_config['week'],$strResult[$i]['NFLPick']);
				$date    = $nameAry['name'];
				$type    = checkWeekDate($strResult[$i]['NFLPick']);
				$NewRes  = getWeekDates($strResult[$i]['NFLPick']);
				$Sdate    = $NewRes['startdate'];
				$Edate    = $NewRes['enddate'];
				if($k==0){
					$type='present';
				}
				$AddedDate = $strResult[$i]['AddedDate'];
				$ModifiedDate = $strResult[$i]['ModifiedDate'];
				$isdeleted = $strResult[$i]['IsDeleted'];
				
				if($isdeleted=='Yes') {
					$datestatus = "Deleted";
				} else {
					if(strtotime($AddedDate) > strtotime($ModifiedDate)) {
						$datestatus = "Added";
					} else {
						$datestatus = "Updated";
					}
				}
				if(!empty($strdate)) { 
					$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate,"Status"=>$datestatus);
				} else {
					$fres[]  = array('date'=>$date,'type'=>$type,'startDate'=>$Sdate,'endDate'=>$Edate);
				}
				$k++;
			}
		}
		//printArray($fres);
		return $fres;
	}
	
?>
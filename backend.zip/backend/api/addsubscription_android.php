<?php 


	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	$arr = array();
	$arr['PurchasedDate'] 		    = $_REQUEST['purchased_time'];
	$arr['ProductId'] 				= $_REQUEST['productId'];
	$arr['User'] 				    = getUserIdFromEmail($_REQUEST['user_email']);
	$arr['TransactionID'] 		    = $_REQUEST['transaction_id'];
	$arr['payment_type'] 		    = $_REQUEST['payment_type'];
    $arr['package_name']            = $_REQUEST['package_name'];
    $arr['purchased_token']         = $_REQUEST['purchased_token'];
    $arr['is_auto_renewing']        = $_REQUEST['is_auto_renewing'];
    $arr['user_google_account_email']= $_REQUEST['user_google_account_email'];
	
	$msg = "Thank you for subscribing to our premium picks!\n You now have access to our best picks that are extensively researched and played by our team of handicappers.\n Let's make $ together!\n If you have any questions or concerns, please feel free to email us at anytimes!\n Cheers,\n Pick Plug Team";
	send_Email(getUserEmailById($_arr['User']),"Hello,", $msg);
	$error ='';
	
	if(!empty($arr['User']) 
	&& !empty($arr['ProductId'])
	&& !empty($arr['PurchasedDate'])
	) {
        
        if (isTransactionAlreadyExistsForApple($arr['User'], $arr['ProductId'],$arr['TransactionID']) == '0'){
     
            $ResultArray =  addsubscription_android($arr); 
            // echo("transaction");
        }else{
            $userSubscriptions  = getUserSubscriptions($arr['User']);
			$userPicks 		 = getUserPicks($arr['User']);
			$ResultArray = array("status"=>"success","message"=>"transaction details inserted successfully",
					"User_Subscriptions"=>$userSubscriptions,
					"User_Picks"=>$userPicks
			);
        }
	    
		
	} else{
		$ResultArray = array("status"=>"failed","message"=>"user, product id or date is empty","type"=>"Normal");			
	}
	echo("result");
// 	var_dump($ResultArray);
// 	exit();
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>
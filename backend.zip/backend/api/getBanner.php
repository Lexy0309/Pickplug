<?php

    include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");

	$ResultArray = getBannerDetails($_REQUEST);

	/*if($ResultArray[0]['message']!='No records found'){

		for($i=0;$i<count($ResultArray);$i++){

			$ResultArray[$i][$ResultArray[$i]['BannerText']] = getBannerDetailsByText($ResultArray[$i]['BannerText']);

		}

	}*/

	printArray($ResultArray);

	displayResult($ResultArray,'Listing');

?>


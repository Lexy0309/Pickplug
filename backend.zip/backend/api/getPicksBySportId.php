<?php
    include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");
	

 
	 $ResultArray = getPicksBySport($_REQUEST['sport_id'],$_REQUEST['user_id']);
	
	
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>


<?php
   print_r($_REQUEST);
?>
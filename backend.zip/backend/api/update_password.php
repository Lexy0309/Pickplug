<?php

    include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");


	    $old_password = $_REQUEST["old_password"];
	    $new_password = $_REQUEST["new_password"];
	    $user_id	  = $_REQUEST["user_id"];




    	$error = "";	
    	if($old_password == ""){
			$error = "Please Enter Old Password";
    	}else if($new_password == ""){
			$error = "Please Enter New Password";
    	}else if($user_id == ""){
			$error = "Invalid User";
    	}

    	if($error == ""){
			if(isValidPassword($user_id,$old_password)){

				$ResultArray =updateUserPassword($user_id,$new_password);
			}else{
				$ResultArray = array("status"=>"failed","message"=>"Old Password Not Match");
			}
    	}else{
				$ResultArray = array("status"=>"failed","message"=>$error);	
    	}	

    header('Content-Type: application/json');
	displayResult($ResultArray,'Results');
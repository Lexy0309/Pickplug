<?php

    include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");

    $id = $_REQUEST["user"];

    $subscription = checkforsubscription($id);
    
    $offerprice = checkfortheofferprice();
    if($subscription == true){
        $lastcheck = checklastalert($id);
        if(count($lastcheck) != 0){
            $lastupdated = $lastcheck["updatedat"];
            $interval = getintervals();
            $split = explode(":", $interval);
            $total = ($split[0]*60*60)+($split[1]*60);
            $currenttime = time();
            $timeremain = $currenttime-$lastupdated;
            if($timeremain > $total){
                $addalert = addalertupdate($id);
                $ResultArray = array("status"=>"success", "offerprice" => $offerprice, "message"=>"showalert","type"=>"Normal");
            }else{
                $ResultArray = array("status"=>"error","message"=>"notneed","type"=>"Normal");
            }
        }else{
            $addalert = addalertupdate($id);
            $ResultArray = array("status"=>"success", "offerprice" => $offerprice, "message"=>"showalert","type"=>"Normal");
        }
        
    }else{
        $ResultArray = array("status"=>"error","message"=>"notneed","type"=>"Normal");
    }

    displayResult($ResultArray,'Alert');


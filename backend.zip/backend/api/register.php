<?php 
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	$arr['userFullName'] 		= isset($_REQUEST['fullname']) ? $_REQUEST['fullname']:'';
	$arr['userPassword'] 		= isset($_REQUEST['password']) ? $_REQUEST['password']:'';
	$arr['userPhoneNumber'] 	= isset($_REQUEST['phone']) ? $_REQUEST['phone']:'';
	$arr['userGender']      	= isset($_REQUEST['gender']) ? $_REQUEST['gender']:'';
	$arr['userEmail'] 		    = isset($_REQUEST['email']) ? $_REQUEST['email']:'';
	$arr['userAddedDate']	    = date("Y-m-d H:m:s");
	$arr['userBirthday']	    = isset($_REQUEST['birthday']) ? $_REQUEST['birthday']:'';
	$arr['usersession']	        = md5(uniqid(microtime()));
	$error ='';
	if($arr['userFullName']=='') {
		$error = "Full Name should not be empty";
	} 
	if($arr['userPassword']=='') {
		$error = "Password should not be empty";
	} 
	 if($arr['userEmail']=='') {
		$error = "Email address should not be empty";
	} 

	if($arr['userEmail']!='' && !preg_match('/[a-z||0-9]@[a-z||0-9].[a-z]/', $arr['userEmail'])) {
		$error = "Invalid email address";
	}  

	if($error) {
		$ResultArray = array("status"=>"failed","message"=>$error);	
	} else {
		 $filename 		= '';
		 if($_FILES['photo']['name']){	
	  	    $filename 		= $_FILES['photo']['name'];
			$fileExt 		= substr($filename,-4,4);
			$filename		= date('YmdHis').$fileExt;
			$target_path	= UPLOADLOCALPATH.'userImage/'.$filename;
			move_uploaded_file( $_FILES['photo']['name'], $target_path );
			//copy(UPLOADLOCALPATH.'/userImage/20130912090425.png',$target_path); 
			$thumbPath 	  = UPLOADLOCALPATH.'userImage/thumb/'.$filename;
			$strImageProperties = getimagesize($target_path);
			  if($strImageProperties[0]>$userImageResizeW){
				 createthumb($target_path,$thumbPath,$userImageResizeW,$userImageResizeH);
			  }else{
			    copy($target_path,$thumbPath); 
			  }
			}
		$arr['userPhoto'] = $filename;	
		$ResultArray 	  = insertLoginDetails($arr,'user',$type);
	}
	
	 $msg = "Thank you for downloading Pick Plug.\n We look forward to helping you make money!\n If you have any questions or concerns, please feel free to email us at anytimes!\n Cheers,\n Pick Plug Team";
	send_Email($_REQUEST['email'],"Hello", $msg);
	
	displayResult($ResultArray,'register');

?>
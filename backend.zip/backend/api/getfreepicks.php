<?php
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	$sportID=trim($_GET['SportId']);
	$res = array();
/*	if($sportID==1){
		if(empty($_REQUEST['date'])) {
			$weeks ='';
			$dateAry = getGroupedWeeksNewWithoutDate($sportID,$_REQUEST['date']);
			for($i=0;$i<count($dateAry);$i++){
				$weeks.= getWeekIdsByName($dateAry[$i]['date']).","; 	
			}
			
			if($weeks){
				$ResultArray = getPicksDetailsNew($table_config['picks'],$sportID,rtrim($weeks,","),$_REQUEST['date']);
				$res['keys'] = $dateAry;
			}else{
				$ResultArray[0]['message']='No records found';
			}
			
		} else {
			$weeks ='';
			$dateAry = getGroupedWeeksNew($sportID,$_REQUEST['date']);
			//printArray($ResultArray); exit;
			for($i=0;$i<count($dateAry);$i++){
				$weeks.= getWeekIdsByName($dateAry[$i]['date']).","; 	
			}
			if($weeks){
				$ResultArray = getPicksDetailsNewWithDate($table_config['picks'],$sportID,rtrim($weeks,","),$_REQUEST['date']);
				$res['keys'] = $dateAry;
			}else{
				$ResultArray[0]['message']='No records found';
			}
		}
	}
	else
	*/
	{
		$dateAry = array();
		$ResultArray = getFreePicksDetailsNew($table_config['picks'],$sportID,'',$_REQUEST['date']);
		
		$dateAry 	 = getFreePendingGroupedDatesNew($sportID,$_REQUEST['date']);
		
 
		 
			
		if(count($dateAry)>=1){ 
			$res['keys'] = $dateAry;
		}else{
			$ResultArray[0]['message']='No records found';
		}
	}
 
	if($ResultArray[0]['message']!='No records found'){
		for($i=0;$i<count($ResultArray);$i++)
		{
			//$res['pickDate'] = 	$ResultArray[$i]['PickDate'];
			$strdate 	= strtotime($ResultArray[$i]['PickDate']);
			$finaldate  = date('d-m-Y',$strdate);
			$weekname = GetWeekDetailsById($table_config['week'], $ResultArray[$i]['NflPick']);
			$weekname = $weekname['name'];
			if($sportID==1) {
					$res[$weekname] = getNflPickDetailsById($table_config['picks'],$ResultArray[$i]['NflPick'],$ResultArray[$i]['SportId'],$_REQUEST['date']);
			} else {
					$res[$finaldate]= getPendingPickDetailsById($table_config['picks'],$ResultArray[$i]['PickDate'],$ResultArray[$i]['SportId'],$_REQUEST['date']);
			}
		}
	}	
	else
	{
		$res=array("No Records Found");
	}
	
 
	
	if($res[0]=='No Records Found' 
// 	&& $_REQUEST['date']!=''
	){ 
		$type ='Pending';
		$total			 = dogetPendingTotal($_GET['SportId'],$type);
		$checkAllDeleted = dogetPendingTotalDeleted($_GET['SportId'],$type);
		if($total>=1){
			if($total == $checkAllDeleted){
				$res=array("All deleted");
			}
		}
		
		if($_GET['SportId']==1){
			$check = getGroupedWeeksNewWithoutDate($sportID,$_REQUEST['date']);
		}else{
			$check = checkActivePicksAvailabe($_GET['SportId']);
		}
		if($check=='0' || $check==''){
			$res=array("All deleted");
		}
	}
	$ans['Picks'] = $res;
	echo json_encode($ans);
	//displayResult($res,'Picks');



?>
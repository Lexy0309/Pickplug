<?php 
	include("../admin/includes/common.php");
	require_once(SITEADMININCLUDEPATH."common-functions.php");
	include(SITEADMININCLUDEPATH."api-functions.php");
	
	$arr = array();
	$arr['PurchasedDate'] 		    = $_REQUEST['date'];
	$arr['ProductId'] 				= $_REQUEST['productId'];
	$arr['User'] 				    = $_REQUEST['user'];
	$arr['Pick'] 				    = $_REQUEST['pick'];

	$error ='';
	
	if(!empty($arr['User']) 
	&& !empty($arr['ProductId'])
	&& !empty($arr['PurchasedDate'])
	
	) {
 
	    
		$ResultArray =  insertTransactionDetails($arr,'' ); 
	} else{
		$ResultArray = array("status"=>"failed","message"=>"user, product id or date is empty","type"=>"Normal");			
	}
	
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>
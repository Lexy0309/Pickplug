<?php
    include("../admin/includes/common.php");

	require_once(SITEADMININCLUDEPATH."common-functions.php");

	include(SITEADMININCLUDEPATH."api-functions.php");
	

 
	 $ResultArray = getFreePicks();
	
	
	header('Content-Type: application/json');
	displayResult($ResultArray,'Results');

?>

